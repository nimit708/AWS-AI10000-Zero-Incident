"""
Main Lambda handler for incident ingestion and processing.

This handler receives events from CloudWatch or API Gateway, validates and normalizes them,
queries the Bedrock AI Agent, routes based on confidence, and creates incident records.
"""
import json
import logging
from typing import Dict, Any, Optional
from datetime import datetime, timezone

from src.utils.validation import validate_event
from src.utils.normalization import normalize_event
from src.services.bedrock_agent_service import BedrockAgentService
from src.services.routing_service import RoutingService
from src.services.dynamodb_service import DynamoDBService
from src.services.sns_service import SNSService
from src.services.ai_agent_executor import AIAgentExecutor
from src.services.pattern_matcher import PatternMatcher
from src.models import IncidentEvent, IncidentRecord
from config import (
    BEDROCK_AGENT_MODEL,
    BEDROCK_EMBEDDING_MODEL,
    CONFIDENCE_THRESHOLD,
    AWS_REGION,
    SNS_SUMMARY_TOPIC_ARN,
    SNS_URGENT_TOPIC_ARN,
    INCIDENT_TABLE_NAME,
    RESOURCE_LOCK_TABLE_NAME,
    KNOWLEDGE_BASE_BUCKET
)

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)


class IngestionHandler:
    """
    Main handler for incident ingestion and processing.
    
    Orchestrates the complete incident processing flow:
    1. Event validation and normalization
    2. Bedrock AI Agent query
    3. Confidence-based routing
    4. Incident record creation
    5. Remediation execution or Step Functions invocation
    """

    def __init__(
        self,
        region_name: str = AWS_REGION,
        confidence_threshold: float = CONFIDENCE_THRESHOLD
    ):
        """
        Initialize ingestion handler with all required services.
        
        Args:
            region_name: AWS region
            confidence_threshold: Confidence threshold for routing
        """
        self.region_name = region_name
        self.confidence_threshold = confidence_threshold
        
        # Initialize services
        self.bedrock_service = BedrockAgentService(
            agent_model=BEDROCK_AGENT_MODEL,
            embedding_model=BEDROCK_EMBEDDING_MODEL,
            region_name=region_name,
            confidence_threshold=confidence_threshold
        )
        self.routing_service = RoutingService(confidence_threshold=confidence_threshold)
        self.dynamodb_service = DynamoDBService(
            table_name=INCIDENT_TABLE_NAME,
            region_name=region_name
        )
        self.sns_service = SNSService(
            summary_topic_arn=SNS_SUMMARY_TOPIC_ARN,
            urgent_topic_arn=SNS_URGENT_TOPIC_ARN,
            region_name=region_name
        )
        self.ai_executor = AIAgentExecutor(region_name=region_name)
        self.pattern_matcher = PatternMatcher()

    def process_event(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process incoming event through the complete incident management flow.
        
        Requirements:
        - 1.1: Accept events from CloudWatch and API Gateway
        - 1.2: Process events in real-time
        - 1.3: Validate event structure
        - 1.4: Extract required fields
        - 1.5: Normalize events to IncidentEvent
        - 2.1: Query Bedrock AI Agent
        
        Args:
            event: Raw event from CloudWatch or API Gateway
            
        Returns:
            Dict with processing result
        """
        start_time = datetime.now(timezone.utc)
        
        try:
            # Step 1: Validate event (Requirement 1.3)
            logger.info("Validating incoming event")
            validation_result = validate_event(event)
            
            if not validation_result.valid:
                logger.error(f"Event validation failed: {validation_result.error}")
                return self._create_error_response(
                    status_code=400,
                    message="Invalid event structure",
                    details=validation_result.error
                )
            
            # Step 2: Normalize event (Requirement 1.5)
            logger.info("Normalizing event to IncidentEvent")
            incident = normalize_event(event)
            logger.info(f"Created incident: {incident.incident_id}, type: {incident.event_type}")
            
            # Step 3: Create initial incident record (Requirement 12.1)
            logger.info("Creating incident record in DynamoDB")
            incident_record = IncidentRecord.from_incident_event(incident)
            record_created = self.dynamodb_service.create_incident_record(incident_record)
            
            if not record_created:
                logger.warning("Failed to create incident record, continuing processing")
            
            # Step 4: Query Bedrock AI Agent (Requirement 2.1)
            logger.info("Querying Bedrock AI Agent for similar incidents")
            agent_response = self.bedrock_service.query_ai_agent(incident)
            logger.info(f"Agent response - Match: {agent_response.match_found}, Confidence: {agent_response.confidence}")
            
            # Step 5: Route based on confidence (Requirement 3.1)
            logger.info("Determining routing path")
            routing_decision = self.routing_service.route_incident(agent_response)
            logger.info(f"Routing decision: {routing_decision['path']}, Reason: {routing_decision['reason']}")
            
            # Step 6: Execute remediation based on path
            remediation_result = None
            
            if routing_decision['path'] == 'fast_path':
                # Fast path: AI Agent remediation (Requirement 3.2)
                logger.info("Executing fast path - AI Agent remediation")
                remediation_result = self.ai_executor.execute_remediation_steps(
                    incident,
                    agent_response
                )
                
            elif routing_decision['path'] == 'structured_path':
                # Structured path: Pattern matching and Step Functions (Requirement 4.1)
                logger.info("Executing structured path - Pattern matching")
                pattern = self.pattern_matcher.identify_pattern(incident)
                logger.info(f"Identified pattern: {pattern}")
                
                # For now, we'll invoke the appropriate remediation handler directly
                # In production, this would trigger Step Functions
                remediation_result = self._execute_structured_remediation(incident, pattern)
                
            elif routing_decision['path'] == 'escalation':
                # Escalation path: Send urgent alert (Requirement 3.6)
                logger.warning("Escalating incident - no remediation path found")
                self._handle_escalation(incident, routing_decision)
                remediation_result = None
            
            # Step 7: Update incident record with results
            if remediation_result:
                logger.info(f"Remediation result: Success={remediation_result.success}")
                self._update_incident_with_result(incident, remediation_result, routing_decision)
                
                # Step 8: Send notification
                if remediation_result.success:
                    self.sns_service.send_summary_notification(
                        incident_id=incident.incident_id,
                        event_type=incident.event_type,
                        severity=incident.severity,
                        remediation_summary=f"Resolved via {routing_decision['path']}",
                        actions_taken=remediation_result.actions_performed
                    )
            
            # Calculate processing time
            processing_time = (datetime.now(timezone.utc) - start_time).total_seconds()
            logger.info(f"Event processing completed in {processing_time:.2f}s")
            
            return self._create_success_response(
                incident_id=incident.incident_id,
                routing_path=routing_decision['path'],
                remediation_success=remediation_result.success if remediation_result else None,
                processing_time=processing_time
            )
            
        except Exception as e:
            logger.error(f"Unexpected error processing event: {e}", exc_info=True)
            return self._create_error_response(
                status_code=500,
                message="Internal processing error",
                details=str(e)
            )

    def _execute_structured_remediation(
        self,
        incident: IncidentEvent,
        pattern: str
    ) -> Optional[Any]:
        """
        Execute structured remediation based on pattern.
        
        In production, this would invoke Step Functions.
        For now, we invoke remediation handlers directly.
        
        Args:
            incident: IncidentEvent to remediate
            pattern: Identified pattern
            
        Returns:
            RemediationResult or None
        """
        try:
            # Get remediation handler for pattern
            handler_class = self.pattern_matcher.get_remediation_handler(pattern)
            
            if handler_class is None:
                logger.warning(f"No handler found for pattern: {pattern}")
                return None
            
            # Instantiate and execute handler
            handler = handler_class(region_name=self.region_name, dry_run=False)
            result = handler.remediate(incident)
            
            return result
            
        except Exception as e:
            logger.error(f"Error executing structured remediation: {e}")
            return None

    def _handle_escalation(
        self,
        incident: IncidentEvent,
        routing_decision: Dict[str, Any]
    ):
        """
        Handle incident escalation.
        
        Requirement 3.6: Escalate failed remediations
        Requirement 13.2: Send urgent alerts
        
        Args:
            incident: IncidentEvent to escalate
            routing_decision: Routing decision details
        """
        logger.warning(f"Escalating incident {incident.incident_id}")
        
        # Update incident status to escalated
        self.dynamodb_service.update_incident_status(
            incident_id=incident.incident_id,
            status='escalated',
            resolution_steps=[],
            confidence_score=0.0
        )
        
        # Send urgent alert
        self.sns_service.send_urgent_alert(
            incident_id=incident.incident_id,
            event_type=incident.event_type,
            severity=incident.severity,
            affected_resources=incident.affected_resources,
            reason=routing_decision.get('reason', 'Unknown'),
            incident_details=incident.metadata
        )

    def _update_incident_with_result(
        self,
        incident: IncidentEvent,
        remediation_result: Any,
        routing_decision: Dict[str, Any]
    ):
        """
        Update incident record with remediation results.
        
        Args:
            incident: IncidentEvent
            remediation_result: RemediationResult
            routing_decision: Routing decision details
        """
        try:
            status = 'resolved' if remediation_result.success else 'failed'
            
            self.dynamodb_service.update_incident_status(
                incident_id=incident.incident_id,
                status=status,
                resolution_steps=remediation_result.actions_performed,
                confidence_score=routing_decision.get('confidence', 0.0)
            )
            
        except Exception as e:
            logger.error(f"Error updating incident record: {e}")

    def _create_success_response(
        self,
        incident_id: str,
        routing_path: str,
        remediation_success: Optional[bool],
        processing_time: float
    ) -> Dict[str, Any]:
        """Create success response."""
        return {
            'statusCode': 200,
            'body': json.dumps({
                'success': True,
                'incident_id': incident_id,
                'routing_path': routing_path,
                'remediation_success': remediation_success,
                'processing_time_seconds': processing_time
            })
        }

    def _create_error_response(
        self,
        status_code: int,
        message: str,
        details: Any = None
    ) -> Dict[str, Any]:
        """Create error response."""
        return {
            'statusCode': status_code,
            'body': json.dumps({
                'success': False,
                'error': message,
                'details': details
            })
        }


# Global handler instance (reused across Lambda invocations)
_handler_instance = None


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    AWS Lambda handler function.
    
    This is the entry point for Lambda invocations from CloudWatch or API Gateway.
    
    Args:
        event: Event data from CloudWatch or API Gateway
        context: Lambda context object
        
    Returns:
        Response dict with statusCode and body
    """
    global _handler_instance
    
    # Initialize handler on first invocation (Lambda container reuse)
    if _handler_instance is None:
        logger.info("Initializing IngestionHandler")
        _handler_instance = IngestionHandler()
    
    # Log request ID for tracing
    request_id = context.aws_request_id if context else 'local'
    logger.info(f"Processing event - Request ID: {request_id}")
    
    # Process event
    return _handler_instance.process_event(event)
