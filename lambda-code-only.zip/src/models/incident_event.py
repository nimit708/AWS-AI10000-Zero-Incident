"""Incident event data models"""
from typing import Literal, Dict, Any, List
from pydantic import BaseModel, Field, field_validator
from datetime import datetime
import uuid


class IncomingEvent(BaseModel):
    """Raw event from CloudWatch or API Gateway"""
    source: Literal['cloudwatch', 'api_gateway']
    timestamp: str
    raw_payload: Dict[str, Any]


class IncidentEvent(BaseModel):
    """Normalized incident event"""
    incident_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: str
    source: str
    event_type: str
    severity: Literal['low', 'medium', 'high', 'critical']
    affected_resources: List[str] = Field(min_length=1)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    raw_event: Dict[str, Any] = Field(default_factory=dict)

    @field_validator('timestamp')
    @classmethod
    def validate_timestamp(cls, v: str) -> str:
        """Validate ISO 8601 timestamp format"""
        try:
            datetime.fromisoformat(v.replace('Z', '+00:00'))
            return v
        except ValueError:
            raise ValueError(f"Invalid ISO 8601 timestamp: {v}")

    @field_validator('incident_id')
    @classmethod
    def validate_uuid(cls, v: str) -> str:
        """Validate UUID format"""
        try:
            uuid.UUID(v)
            return v
        except ValueError:
            raise ValueError(f"Invalid UUID: {v}")

    @field_validator('event_type')
    @classmethod
    def validate_event_type(cls, v: str) -> str:
        """Validate event type is non-empty"""
        if not v or not v.strip():
            raise ValueError("event_type must be non-empty")
        return v
