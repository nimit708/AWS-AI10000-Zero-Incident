"""AI Agent remediation executor service"""
import logging
import json
from typing import Dict, Any, List, Optional
import boto3
from botocore.exceptions import ClientError
from src.models import IncidentEvent, AgentResponse, RemediationResult, ResolutionStep
from src.services.dynamodb_service import DynamoDBService
from src.services.knowledge_base_service import KnowledgeBaseService

logger = logging.getLogger(__name__)


class AIAgentExecutor:
    """
    Executor for AI Agent remediation recommendations.
    
    Executes high-confidence remediation steps from the AI Agent.
    """

    def __init__(self, region_name: str = 'us-east-1', incident_table_name: str = None):
        """
        Initialize AI Agent executor.
        
        Args:
            region_name: AWS region
            incident_table_name: DynamoDB incident table name
        """
        from config import INCIDENT_TABLE_NAME, KNOWLEDGE_BASE_BUCKET
        
        self.region_name = region_name
        self.lambda_client = boto3.client('lambda', region_name=region_name)
        self.dynamodb_service = DynamoDBService(
            table_name=incident_table_name or INCIDENT_TABLE_NAME,
            region_name=region_name
        )
        self.knowledge_base_service = KnowledgeBaseService(
            bucket_name=KNOWLEDGE_BASE_BUCKET,
            region_name=region_name
        )

    def execute_remediation_steps(
        self,
        incident: IncidentEvent,
        agent_response: AgentResponse
    ) -> RemediationResult:
        """
        Execute remediation steps from AI Agent response.
        
        Property 27: High-confidence remediation execution
        For high-confidence matches (≥ 0.85), execute remediation steps from agent.
        
        Args:
            incident: IncidentEvent to remediate
            agent_response: AgentResponse with remediation steps
            
        Returns:
            RemediationResult with execution status
        """
        start_time = self._get_current_time()
        actions_performed = []
        
        try:
            # Validate agent response has remediation steps
            if not agent_response.resolution_steps:
                return RemediationResult.create_failure(
                    error_message="No resolution steps provided by AI Agent",
                    resolution_time=self._calculate_duration(start_time),
                    actions_attempted=['Attempted to execute remediation']
                )
            
            actions_performed.append(f"Executing {len(agent_response.resolution_steps)} remediation steps")
            logger.info(f"Executing {len(agent_response.resolution_steps)} steps for incident {incident.incident_id}")
            
            # Execute each remediation step
            step_results = []
            for i, step in enumerate(agent_response.resolution_steps, 1):
                logger.info(f"Executing step {i}/{len(agent_response.resolution_steps)}: {step.action}")
                
                step_result = self._execute_single_step(step, incident)
                step_results.append(step_result)
                
                if step_result['success']:
                    actions_performed.append(f"Step {i}: {step.action} - Success")
                else:
                    actions_performed.append(f"Step {i}: {step.action} - Failed: {step_result.get('error')}")
                    
                    # Handle failure
                    failure_handled = self.handle_remediation_failure(
                        incident,
                        agent_response,
                        step_result,
                        i
                    )
                    
                    if not failure_handled:
                        # Critical failure, stop execution
                        return RemediationResult.create_failure(
                            error_message=f"Step {i} failed: {step_result.get('error')}",
                            resolution_time=self._calculate_duration(start_time),
                            actions_attempted=actions_performed
                        )
            
            # All steps succeeded
            actions_performed.append("All remediation steps completed successfully")
            
            # Update Knowledge Base and DynamoDB
            update_success = self.update_knowledge_base_and_dynamodb(
                incident,
                agent_response,
                step_results
            )
            
            if update_success:
                actions_performed.append("Updated Knowledge Base and DynamoDB")
            
            return RemediationResult.create_success(
                actions=actions_performed,
                resolution_time=self._calculate_duration(start_time),
                new_state={
                    'steps_executed': len(step_results),
                    'steps_succeeded': sum(1 for r in step_results if r['success']),
                    'agent_confidence': agent_response.confidence,
                    'matched_incident': agent_response.matched_incident
                }
            )
            
        except Exception as e:
            logger.error(f"Unexpected error during remediation execution: {e}")
            return RemediationResult.create_failure(
                error_message=f"Execution error: {str(e)}",
                resolution_time=self._calculate_duration(start_time),
                actions_attempted=actions_performed
            )

    def _execute_single_step(
        self,
        step: 'ResolutionStep',
        incident: IncidentEvent
    ) -> Dict[str, Any]:
        """
        Execute a single remediation step.
        
        Args:
            step: ResolutionStep from agent
            incident: IncidentEvent context
            
        Returns:
            Dict with execution result
        """
        action_type = step.action
        
        try:
            if action_type == 'aws_api_call':
                # Execute AWS API call
                return self.invoke_aws_api(step, incident)
            
            elif action_type == 'invoke_lambda':
                # Invoke Lambda function
                return self.invoke_lambda(step, incident)
            
            elif action_type == 'wait':
                # Wait step (simulated)
                return {
                    'success': True,
                    'action': step.action,
                    'result': f"Wait step: {step.description}"
                }
            
            elif action_type == 'conditional':
                # Conditional step (simulated)
                return {
                    'success': True,
                    'action': step.action,
                    'result': f"Conditional step: {step.description}"
                }
            
            else:
                return {
                    'success': False,
                    'action': step.action,
                    'error': f"Unknown action type: {action_type}"
                }
                
        except Exception as e:
            logger.error(f"Error executing step: {e}")
            return {
                'success': False,
                'action': step.action,
                'error': str(e)
            }

    def invoke_aws_api(
        self,
        step: 'ResolutionStep',
        incident: IncidentEvent
    ) -> Dict[str, Any]:
        """
        Invoke AWS API based on remediation step.
        
        Args:
            step: ResolutionStep with AWS API details
            incident: IncidentEvent context
            
        Returns:
            Dict with invocation result
        """
        # Parse target for service and operation (format: "service:operation")
        if ':' not in step.target:
            return {
                'success': False,
                'action': step.action,
                'error': 'Target must be in format "service:operation"'
            }
        
        service, operation = step.target.split(':', 1)
        parameters = step.parameters
        
        try:
            # Create boto3 client for the service
            client = boto3.client(service, region_name=self.region_name)
            
            # Get the operation method
            if not hasattr(client, operation):
                return {
                    'success': False,
                    'action': step.action,
                    'error': f"Operation {operation} not found on {service}"
                }
            
            # Execute the operation
            operation_method = getattr(client, operation)
            response = operation_method(**parameters)
            
            return {
                'success': True,
                'action': step.action,
                'result': response,
                'service': service,
                'operation': operation
            }
            
        except ClientError as e:
            logger.error(f"AWS API error: {e}")
            return {
                'success': False,
                'action': step.action,
                'error': f"AWS API error: {str(e)}",
                'service': service,
                'operation': operation
            }
        except Exception as e:
            logger.error(f"Error invoking AWS API: {e}")
            return {
                'success': False,
                'action': step.action,
                'error': str(e)
            }

    def invoke_lambda(
        self,
        step: 'ResolutionStep',
        incident: IncidentEvent
    ) -> Dict[str, Any]:
        """
        Invoke Lambda function for remediation.
        
        Args:
            step: ResolutionStep with Lambda details
            incident: IncidentEvent context
            
        Returns:
            Dict with invocation result
        """
        function_name = step.target
        payload = step.parameters.copy()
        
        try:
            # Add incident context to payload
            payload['incident_id'] = incident.incident_id
            payload['event_type'] = incident.event_type
            
            # Invoke Lambda function
            response = self.lambda_client.invoke(
                FunctionName=function_name,
                InvocationType='RequestResponse',
                Payload=json.dumps(payload)
            )
            
            # Parse response
            response_payload = json.loads(response['Payload'].read())
            
            # Check if Lambda execution was successful
            if response['StatusCode'] == 200:
                return {
                    'success': True,
                    'action': step.action,
                    'result': response_payload,
                    'function_name': function_name
                }
            else:
                return {
                    'success': False,
                    'action': step.action,
                    'error': f"Lambda returned status {response['StatusCode']}",
                    'function_name': function_name
                }
                
        except ClientError as e:
            logger.error(f"Lambda invocation error: {e}")
            return {
                'success': False,
                'action': step.action,
                'error': f"Lambda error: {str(e)}",
                'function_name': function_name
            }
        except Exception as e:
            logger.error(f"Error invoking Lambda: {e}")
            return {
                'success': False,
                'action': step.action,
                'error': str(e)
            }

    def handle_remediation_failure(
        self,
        incident: IncidentEvent,
        agent_response: AgentResponse,
        step_result: Dict[str, Any],
        step_number: int
    ) -> bool:
        """
        Handle remediation failure.
        
        Args:
            incident: IncidentEvent
            agent_response: AgentResponse
            step_result: Failed step result
            step_number: Step number that failed
            
        Returns:
            True if failure was handled and execution can continue
        """
        logger.warning(f"Handling remediation failure at step {step_number}")
        
        # Log failure details
        failure_info = {
            'incident_id': incident.incident_id,
            'step_number': step_number,
            'action': step_result.get('action'),
            'error': step_result.get('error'),
            'agent_confidence': agent_response.confidence
        }
        
        logger.error(f"Remediation failure: {json.dumps(failure_info)}")
        
        # Determine if failure is recoverable
        error_message = step_result.get('error', '').lower()
        
        # Transient errors - can retry
        transient_keywords = ['throttl', 'timeout', 'unavailable', 'capacity']
        if any(keyword in error_message for keyword in transient_keywords):
            logger.info("Transient error detected - could retry")
            return False  # For now, don't continue
        
        # Permission errors - cannot recover
        permission_keywords = ['access denied', 'unauthorized', 'forbidden']
        if any(keyword in error_message for keyword in permission_keywords):
            logger.error("Permission error - cannot recover")
            return False
        
        # Default: don't continue on failure
        return False

    def update_knowledge_base_and_dynamodb(
        self,
        incident: IncidentEvent,
        agent_response: AgentResponse,
        step_results: List[Dict[str, Any]]
    ) -> bool:
        """
        Update Knowledge Base and DynamoDB after successful remediation.
        
        Args:
            incident: IncidentEvent
            agent_response: AgentResponse
            step_results: List of step execution results
            
        Returns:
            True if updates successful
        """
        try:
            # Create incident document for Knowledge Base
            incident_doc = {
                'incident_id': incident.incident_id,
                'event_type': incident.event_type,
                'severity': incident.severity,
                'affected_resources': incident.affected_resources,
                'resolution_steps': agent_response.resolution_steps,
                'confidence_score': agent_response.confidence,
                'execution_results': step_results,
                'status': 'resolved'
            }
            
            # Store in Knowledge Base
            kb_success = self.knowledge_base_service.create_incident_document(
                incident_id=incident.incident_id,
                incident_data=incident_doc
            )
            
            if not kb_success:
                logger.warning("Failed to update Knowledge Base")
            
            # Update DynamoDB incident record
            db_success = self.dynamodb_service.update_incident_status(
                incident_id=incident.incident_id,
                status='resolved',
                resolution_steps=agent_response.resolution_steps,
                confidence_score=agent_response.confidence
            )
            
            if not db_success:
                logger.warning("Failed to update DynamoDB")
            
            return kb_success and db_success
            
        except Exception as e:
            logger.error(f"Error updating Knowledge Base and DynamoDB: {e}")
            return False

    def _get_current_time(self) -> int:
        """Get current timestamp in seconds"""
        from time import time
        return int(time())

    def _calculate_duration(self, start_time: int) -> int:
        """Calculate duration in seconds"""
        return self._get_current_time() - start_time
