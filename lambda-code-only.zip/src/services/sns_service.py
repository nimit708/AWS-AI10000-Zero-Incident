"""SNS service for incident notifications"""
import json
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime
import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


class SNSService:
    """
    Service for SNS notification operations.
    
    Sends summary notifications for successful remediations and urgent alerts
    for failures or unknown incidents.
    """

    def __init__(
        self,
        summary_topic_arn: str,
        urgent_topic_arn: str,
        region_name: str = 'us-east-1',
        max_retries: int = 3
    ):
        """
        Initialize SNS service.
        
        Args:
            summary_topic_arn: ARN for summary notification topic
            urgent_topic_arn: ARN for urgent alert topic
            region_name: AWS region
            max_retries: Maximum number of retry attempts
        """
        self.summary_topic_arn = summary_topic_arn
        self.urgent_topic_arn = urgent_topic_arn
        self.max_retries = max_retries
        
        self.sns_client = boto3.client('sns', region_name=region_name)

    def send_summary_notification(
        self,
        incident_id: str,
        event_type: str,
        affected_resources: List[str],
        actions_performed: List[str],
        resolution_time: int,
        summary: str
    ) -> bool:
        """
        Send summary notification for successful auto-remediation.
        
        Property 23: Success notification format
        For any successful auto-remediation, the SNS summary notification should 
        contain all required fields: incidentId, eventType, affectedResources, 
        actionsPerformed, resolutionTime, and human-readable summary.
        
        Args:
            incident_id: Incident ID
            event_type: Type of incident
            affected_resources: List of affected resources
            actions_performed: List of remediation actions
            resolution_time: Time to resolve in seconds
            summary: Human-readable summary
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Validate required fields
            if not all([incident_id, event_type, affected_resources, actions_performed, summary]):
                logger.error("Missing required fields for summary notification")
                return False
            
            # Create message
            message = {
                "incidentId": incident_id,
                "eventType": event_type,
                "affectedResources": affected_resources,
                "actionsPerformed": actions_performed,
                "resolutionTime": f"{resolution_time} seconds",
                "summary": summary
            }
            
            subject = f"Incident Resolved: {event_type}"
            
            return self._publish_with_retry(
                topic_arn=self.summary_topic_arn,
                subject=subject,
                message=message,
                incident_id=incident_id
            )
            
        except Exception as e:
            logger.error(f"Error sending summary notification for {incident_id}: {e}")
            return False

    def send_urgent_alert(
        self,
        incident_id: str,
        event_type: str,
        reason: str,
        affected_resources: List[str],
        recommended_actions: List[str],
        incident_details: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        Send urgent alert for failures or unknown incidents.
        
        Property 24: Urgent alarm format
        For any failed remediation or unclassified incident, the SNS urgent alarm 
        should contain all required fields: incidentId, eventType, reason for 
        escalation, affectedResources, and recommended next steps.
        
        Args:
            incident_id: Incident ID
            event_type: Type of incident
            reason: Reason for escalation
            affected_resources: List of affected resources
            recommended_actions: List of recommended next steps
            incident_details: Optional additional details
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Validate required fields
            if not all([incident_id, event_type, reason, affected_resources, recommended_actions]):
                logger.error("Missing required fields for urgent alert")
                return False
            
            # Create message
            message = {
                "incidentId": incident_id,
                "eventType": event_type,
                "reason": reason,
                "affectedResources": affected_resources,
                "recommendedActions": recommended_actions
            }
            
            if incident_details:
                message["incidentDetails"] = incident_details
            
            subject = f"URGENT: Incident Requires Attention - {event_type}"
            
            return self._publish_with_retry(
                topic_arn=self.urgent_topic_arn,
                subject=subject,
                message=message,
                incident_id=incident_id
            )
            
        except Exception as e:
            logger.error(f"Error sending urgent alert for {incident_id}: {e}")
            return False

    def _publish_with_retry(
        self,
        topic_arn: str,
        subject: str,
        message: Dict[str, Any],
        incident_id: str
    ) -> bool:
        """
        Publish message to SNS with retry logic.
        
        Args:
            topic_arn: SNS topic ARN
            subject: Message subject
            message: Message body (will be JSON serialized)
            incident_id: Incident ID for logging
            
        Returns:
            True if successful, False otherwise
        """
        message_json = json.dumps(message, indent=2)
        
        for attempt in range(self.max_retries):
            try:
                response = self.sns_client.publish(
                    TopicArn=topic_arn,
                    Subject=subject,
                    Message=message_json,
                    MessageAttributes={
                        'incident_id': {
                            'DataType': 'String',
                            'StringValue': incident_id
                        },
                        'event_type': {
                            'DataType': 'String',
                            'StringValue': message.get('eventType', 'Unknown')
                        }
                    }
                )
                
                message_id = response.get('MessageId')
                logger.info(
                    f"Published notification for incident {incident_id} "
                    f"to {topic_arn} (MessageId: {message_id})"
                )
                return True
                
            except ClientError as e:
                error_code = e.response['Error']['Code']
                
                if attempt < self.max_retries - 1:
                    logger.warning(
                        f"SNS publish failed for incident {incident_id} "
                        f"(attempt {attempt + 1}/{self.max_retries}): {error_code}"
                    )
                    continue
                else:
                    logger.error(
                        f"SNS publish failed after {self.max_retries} retries "
                        f"for incident {incident_id}: {e}"
                    )
                    return False
                    
            except Exception as e:
                logger.error(f"Unexpected error publishing to SNS for {incident_id}: {e}")
                return False
        
        return False

    def send_test_notification(self, topic_type: str = 'summary') -> bool:
        """
        Send a test notification to verify SNS configuration.
        
        Args:
            topic_type: 'summary' or 'urgent'
            
        Returns:
            True if successful, False otherwise
        """
        try:
            if topic_type == 'summary':
                return self.send_summary_notification(
                    incident_id='test-incident-000',
                    event_type='Test Notification',
                    affected_resources=['test-resource'],
                    actions_performed=['Sent test notification'],
                    resolution_time=0,
                    summary='This is a test notification to verify SNS configuration.'
                )
            else:
                return self.send_urgent_alert(
                    incident_id='test-incident-000',
                    event_type='Test Alert',
                    reason='Testing urgent alert configuration',
                    affected_resources=['test-resource'],
                    recommended_actions=['Verify alert received', 'Check email/SMS'],
                    incident_details={'test': True}
                )
                
        except Exception as e:
            logger.error(f"Error sending test notification: {e}")
            return False

    def format_summary_from_remediation(
        self,
        incident_id: str,
        event_type: str,
        affected_resources: List[str],
        actions: List[str],
        resolution_time: int,
        technical_summary: str
    ) -> Dict[str, Any]:
        """
        Format a summary notification message from remediation result.
        
        Helper method to create properly formatted summary notifications.
        
        Args:
            incident_id: Incident ID
            event_type: Event type
            affected_resources: Affected resources
            actions: Actions performed
            resolution_time: Resolution time in seconds
            technical_summary: Technical summary text
            
        Returns:
            Formatted message dictionary
        """
        return {
            "incidentId": incident_id,
            "eventType": event_type,
            "affectedResources": affected_resources,
            "actionsPerformed": actions,
            "resolutionTime": f"{resolution_time} seconds",
            "summary": technical_summary,
            "timestamp": datetime.utcnow().isoformat() + 'Z'
        }

    def format_urgent_alert_from_failure(
        self,
        incident_id: str,
        event_type: str,
        affected_resources: List[str],
        failure_reason: str,
        error_message: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Format an urgent alert message from remediation failure.
        
        Helper method to create properly formatted urgent alerts.
        
        Args:
            incident_id: Incident ID
            event_type: Event type
            affected_resources: Affected resources
            failure_reason: Reason for failure
            error_message: Optional error message
            
        Returns:
            Formatted message dictionary
        """
        recommended_actions = [
            "Review incident details in DynamoDB",
            "Check CloudWatch logs for error details",
            "Manually investigate affected resources",
            "Consider manual remediation"
        ]
        
        incident_details = {
            "timestamp": datetime.utcnow().isoformat() + 'Z',
            "failure_reason": failure_reason
        }
        
        if error_message:
            incident_details["error_message"] = error_message
        
        return {
            "incidentId": incident_id,
            "eventType": event_type,
            "reason": failure_reason,
            "affectedResources": affected_resources,
            "recommendedActions": recommended_actions,
            "incidentDetails": incident_details
        }
