"""Bedrock AI Agent service for intelligent incident matching and remediation"""
import json
import logging
from typing import Optional, List, Dict, Any
import boto3
from botocore.exceptions import ClientError
from src.models import IncidentEvent, AgentResponse, ResolutionStep

logger = logging.getLogger(__name__)


class BedrockAgentService:
    """
    Service for Bedrock AI Agent operations.
    
    Provides intelligent incident matching using semantic search and
    autonomous remediation orchestration.
    """

    def __init__(
        self,
        agent_model: str = 'anthropic.claude-3-5-sonnet-20241022-v2:0',
        embedding_model: str = 'amazon.titan-embed-text-v2:0',
        region_name: str = 'us-east-1',
        confidence_threshold: float = 0.85
    ):
        """
        Initialize Bedrock AI Agent service.
        
        Args:
            agent_model: Bedrock model ID for AI agent
            embedding_model: Bedrock model ID for embeddings
            region_name: AWS region
            confidence_threshold: Minimum confidence for high-confidence routing
        """
        self.agent_model = agent_model
        self.embedding_model = embedding_model
        self.confidence_threshold = confidence_threshold
        
        self.bedrock_runtime = boto3.client('bedrock-runtime', region_name=region_name)

    def query_ai_agent(
        self,
        incident: IncidentEvent,
        max_results: int = 5
    ) -> AgentResponse:
        """
        Query AI Agent for similar incidents and remediation guidance.
        
        Property 25: Semantic search execution
        For any incident processed by the AI Agent, the agent should query 
        the Knowledge Base using semantic search (vector similarity) and 
        return results ranked by similarity score.
        
        Property 26: Confidence score presence
        For any incident match returned by the AI Agent, the response should 
        include a confidence score between 0.0 and 1.0 inclusive.
        
        Args:
            incident: IncidentEvent to analyze
            max_results: Maximum number of similar incidents to return
            
        Returns:
            AgentResponse with match results and confidence score
        """
        try:
            # Create query text from incident
            query_text = self._create_query_text(incident)
            
            # Query the agent using Bedrock
            # In production, this would use Bedrock Agent or Knowledge Base API
            # For now, we'll simulate the response structure
            response = self._invoke_bedrock_agent(query_text, max_results)
            
            return response
            
        except ClientError as e:
            logger.error(f"Bedrock unavailable for incident {incident.incident_id}: {e}")
            # Graceful degradation - return no match
            return AgentResponse(
                match_found=False,
                confidence=0.0,
                reasoning="Bedrock service unavailable - routing to structured path"
            )
        except Exception as e:
            logger.error(f"Error querying AI agent for {incident.incident_id}: {e}")
            return AgentResponse(
                match_found=False,
                confidence=0.0,
                reasoning=f"Error querying agent: {str(e)}"
            )

    def parse_agent_response(
        self,
        raw_response: Dict[str, Any]
    ) -> AgentResponse:
        """
        Parse raw Bedrock agent response into AgentResponse model.
        
        Property 4: Match response completeness
        For any incident query that finds a match, the AgentResponse should 
        contain all required fields: matchFound=true, confidence score, 
        matched incident details, and resolution steps.
        
        Property 5: No-match response format
        For any incident query with no similar incidents found or confidence 
        below threshold, the AgentResponse should have matchFound=false and 
        should not contain matched incident or resolution steps.
        
        Args:
            raw_response: Raw response from Bedrock
            
        Returns:
            Parsed AgentResponse
        """
        try:
            # Extract confidence score
            confidence = raw_response.get('confidence', 0.0)
            
            # Validate confidence is in range [0.0, 1.0]
            if not (0.0 <= confidence <= 1.0):
                logger.warning(f"Invalid confidence score: {confidence}, clamping to [0.0, 1.0]")
                confidence = max(0.0, min(1.0, confidence))
            
            # Check if match found and confidence above threshold
            match_found = confidence >= self.confidence_threshold
            
            if match_found:
                # Property 4: Match response completeness
                matched_incident = raw_response.get('matched_incident')
                resolution_steps_data = raw_response.get('resolution_steps', [])
                
                # Parse resolution steps
                resolution_steps = [
                    ResolutionStep(**step) for step in resolution_steps_data
                ]
                
                return AgentResponse(
                    match_found=True,
                    confidence=confidence,
                    matched_incident=matched_incident,
                    resolution_steps=resolution_steps,
                    reasoning=raw_response.get('reasoning', 'High confidence match found')
                )
            else:
                # Property 5: No-match response format
                return AgentResponse(
                    match_found=False,
                    confidence=confidence,
                    reasoning=raw_response.get('reasoning', 'No high-confidence match found')
                )
                
        except Exception as e:
            logger.error(f"Error parsing agent response: {e}")
            return AgentResponse(
                match_found=False,
                confidence=0.0,
                reasoning=f"Error parsing response: {str(e)}"
            )

    def _invoke_bedrock_agent(
        self,
        query_text: str,
        max_results: int
    ) -> AgentResponse:
        """
        Invoke Bedrock model for incident analysis.
        
        This is a simplified implementation. In production, this would:
        1. Use Bedrock Agent API with Knowledge Base integration
        2. Perform semantic search using vector embeddings
        3. Return ranked results with confidence scores
        
        Args:
            query_text: Query text describing the incident
            max_results: Maximum number of results
            
        Returns:
            AgentResponse with analysis results
        """
        try:
            # Create prompt for Claude
            prompt = self._create_agent_prompt(query_text)
            
            # Invoke Bedrock model
            request_body = json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 2000,
                "messages": [
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                "temperature": 0.1  # Low temperature for consistent results
            })
            
            response = self.bedrock_runtime.invoke_model(
                modelId=self.agent_model,
                body=request_body,
                contentType='application/json',
                accept='application/json'
            )
            
            # Parse response
            response_body = json.loads(response['body'].read())
            content = response_body.get('content', [])
            
            if content and len(content) > 0:
                response_text = content[0].get('text', '')
                # Parse the structured response
                return self._parse_model_response(response_text)
            else:
                return AgentResponse(
                    match_found=False,
                    confidence=0.0,
                    reasoning="No response from model"
                )
                
        except ClientError as e:
            logger.error(f"Bedrock API error: {e}")
            raise
        except Exception as e:
            logger.error(f"Error invoking Bedrock agent: {e}")
            raise

    def _create_query_text(self, incident: IncidentEvent) -> str:
        """
        Create query text from incident for semantic search.
        
        Args:
            incident: IncidentEvent
            
        Returns:
            Query text string
        """
        parts = [
            f"Event Type: {incident.event_type}",
            f"Severity: {incident.severity}",
            f"Affected Resources: {', '.join(incident.affected_resources)}",
            f"Source: {incident.source}"
        ]
        
        # Add relevant metadata
        if incident.metadata:
            for key, value in incident.metadata.items():
                if key in ['alarm_name', 'metric_name', 'reason', 'state']:
                    parts.append(f"{key}: {value}")
        
        return " | ".join(parts)

    def _create_agent_prompt(self, query_text: str) -> str:
        """
        Create prompt for Bedrock agent.
        
        Args:
            query_text: Query text
            
        Returns:
            Formatted prompt
        """
        return f"""You are an AWS incident analysis expert. Analyze the following incident and determine if you have seen similar incidents before.

Incident Details:
{query_text}

Provide your analysis in the following JSON format:
{{
    "confidence": <float between 0.0 and 1.0>,
    "match_found": <boolean>,
    "reasoning": "<explanation of your analysis>",
    "matched_incident": {{
        "incident_id": "<id if match found>",
        "event_type": "<type>",
        "similarity_score": <float>
    }},
    "resolution_steps": [
        {{
            "step_number": 1,
            "action": "aws_api_call",
            "target": "<AWS API or service>",
            "parameters": {{}},
            "description": "<what to do>"
        }}
    ]
}}

If no similar incident is found or confidence is low, set match_found to false and omit matched_incident and resolution_steps.
Respond ONLY with valid JSON, no additional text."""

    def _parse_model_response(self, response_text: str) -> AgentResponse:
        """
        Parse model response text into AgentResponse.
        
        Args:
            response_text: Response text from model
            
        Returns:
            AgentResponse
        """
        try:
            # Try to extract JSON from response
            # Handle cases where model adds extra text
            start_idx = response_text.find('{')
            end_idx = response_text.rfind('}') + 1
            
            if start_idx >= 0 and end_idx > start_idx:
                json_text = response_text[start_idx:end_idx]
                response_data = json.loads(json_text)
                return self.parse_agent_response(response_data)
            else:
                logger.warning("No JSON found in model response")
                return AgentResponse(
                    match_found=False,
                    confidence=0.0,
                    reasoning="Could not parse model response"
                )
                
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error: {e}")
            return AgentResponse(
                match_found=False,
                confidence=0.0,
                reasoning="Invalid JSON in model response"
            )

    def calculate_confidence_score(
        self,
        similarity_score: float,
        metadata_match: float
    ) -> float:
        """
        Calculate overall confidence score from similarity and metadata match.
        
        Property 26: Confidence score presence
        
        Args:
            similarity_score: Vector similarity score (0.0 to 1.0)
            metadata_match: Metadata match score (0.0 to 1.0)
            
        Returns:
            Combined confidence score (0.0 to 1.0)
        """
        # Weighted average: 70% similarity, 30% metadata
        confidence = (0.7 * similarity_score) + (0.3 * metadata_match)
        
        # Ensure in valid range
        return max(0.0, min(1.0, confidence))

    def is_high_confidence(self, confidence: float) -> bool:
        """
        Check if confidence score meets threshold for fast path routing.
        
        Property 7: Confidence-based routing consistency
        
        Args:
            confidence: Confidence score
            
        Returns:
            True if confidence >= threshold
        """
        return confidence >= self.confidence_threshold

    def handle_bedrock_unavailable(self, incident: IncidentEvent) -> AgentResponse:
        """
        Handle graceful degradation when Bedrock is unavailable.
        
        Property 32: Graceful degradation behavior
        For any incident processed when Bedrock Service is unavailable, 
        the system should route the incident to Step Functions workflow 
        instead of failing completely.
        
        Args:
            incident: IncidentEvent
            
        Returns:
            AgentResponse indicating no match (routes to structured path)
        """
        logger.warning(
            f"Bedrock unavailable for incident {incident.incident_id}, "
            "routing to Step Functions"
        )
        
        return AgentResponse(
            match_found=False,
            confidence=0.0,
            reasoning="Bedrock service unavailable - graceful degradation to structured path"
        )
