"""Pattern matching service for incident classification"""
import logging
from typing import Optional, Dict, Any, Literal
from src.models import IncidentEvent

logger = logging.getLogger(__name__)

# Type alias for incident patterns
IncidentPattern = Literal[
    'ec2_cpu_memory_spike',
    'lambda_timeout',
    'ssl_certificate_error',
    'network_timeout',
    'deployment_failure',
    'service_unhealthy',
    'unknown'
]


class PatternMatcher:
    """
    Service for pattern matching and incident classification.
    
    Evaluates incidents against predefined patterns to determine
    the appropriate remediation strategy.
    """

    def __init__(self):
        """Initialize pattern matcher"""
        pass

    def match_pattern(self, incident: IncidentEvent) -> IncidentPattern:
        """
        Match incident to one of six predefined patterns.
        
        Property 9: Pattern matching routing
        For any incident routed to structured path, the system should evaluate 
        against all six patterns and route to the matching remediation handler.
        
        Property 33: Pattern evaluation completeness
        For any incident evaluated by pattern matcher, all six patterns should 
        be checked before determining no match.
        
        Args:
            incident: IncidentEvent to classify
            
        Returns:
            IncidentPattern: Matched pattern or 'unknown'
        """
        # Check all patterns in order
        # Property 33: All patterns must be evaluated
        
        if self._is_ec2_cpu_memory_spike(incident):
            logger.info(f"Incident {incident.incident_id} matched: EC2 CPU/Memory Spike")
            return 'ec2_cpu_memory_spike'
        
        if self._is_lambda_timeout(incident):
            logger.info(f"Incident {incident.incident_id} matched: Lambda Timeout")
            return 'lambda_timeout'
        
        if self._is_ssl_certificate_error(incident):
            logger.info(f"Incident {incident.incident_id} matched: SSL Certificate Error")
            return 'ssl_certificate_error'
        
        if self._is_network_timeout(incident):
            logger.info(f"Incident {incident.incident_id} matched: Network Timeout")
            return 'network_timeout'
        
        if self._is_deployment_failure(incident):
            logger.info(f"Incident {incident.incident_id} matched: Deployment Failure")
            return 'deployment_failure'
        
        if self._is_service_unhealthy(incident):
            logger.info(f"Incident {incident.incident_id} matched: Service Unhealthy/Crash")
            return 'service_unhealthy'
        
        # No pattern matched
        logger.warning(f"Incident {incident.incident_id} matched: Unknown (no pattern)")
        return 'unknown'

    def _is_ec2_cpu_memory_spike(self, incident: IncidentEvent) -> bool:
        """
        Check if incident matches EC2 CPU/Memory Spike pattern.
        
        Pattern conditions:
        - Event type contains "EC2", "CPU", or "Memory"
        - Source is CloudWatch
        - Affected resources include EC2 instance IDs
        
        Args:
            incident: IncidentEvent
            
        Returns:
            True if matches pattern
        """
        event_type_lower = incident.event_type.lower()
        
        # Check event type
        if not any(keyword in event_type_lower for keyword in ['ec2', 'cpu', 'memory']):
            return False
        
        # Check source
        if incident.source != 'cloudwatch':
            return False
        
        # Check for EC2 instance IDs in affected resources
        has_ec2_instance = any(
            resource.startswith('i-') 
            for resource in incident.affected_resources
        )
        
        return has_ec2_instance

    def _is_lambda_timeout(self, incident: IncidentEvent) -> bool:
        """
        Check if incident matches Lambda Timeout pattern.
        
        Pattern conditions:
        - Event type contains "Lambda" and "Timeout"
        - Source is CloudWatch
        - Affected resources include Lambda function names
        
        Args:
            incident: IncidentEvent
            
        Returns:
            True if matches pattern
        """
        event_type_lower = incident.event_type.lower()
        
        # Check event type
        if 'lambda' not in event_type_lower or 'timeout' not in event_type_lower:
            return False
        
        # Check source
        if incident.source != 'cloudwatch':
            return False
        
        # Lambda functions typically don't start with specific prefixes
        # but we can check metadata for function names
        if incident.metadata:
            function_name = incident.metadata.get('function_name')
            if function_name:
                return True
        
        # Check if any resource looks like a Lambda function
        # (doesn't start with common AWS resource prefixes)
        has_lambda_resource = any(
            not resource.startswith(('i-', 'arn:', 'sg-', 'vpc-'))
            for resource in incident.affected_resources
        )
        
        return has_lambda_resource

    def _is_ssl_certificate_error(self, incident: IncidentEvent) -> bool:
        """
        Check if incident matches SSL Certificate Error pattern.
        
        Pattern conditions:
        - Event type contains "SSL", "Certificate", or "TLS"
        - Metadata contains certificate-related information
        
        Args:
            incident: IncidentEvent
            
        Returns:
            True if matches pattern
        """
        event_type_lower = incident.event_type.lower()
        
        # Check event type
        if not any(keyword in event_type_lower for keyword in ['ssl', 'certificate', 'tls', 'cert']):
            return False
        
        # Additional validation from metadata
        if incident.metadata:
            # Check for certificate-related metadata
            cert_keys = ['certificate_arn', 'domain_name', 'expiration_date', 'certificate_id']
            has_cert_metadata = any(key in incident.metadata for key in cert_keys)
            if has_cert_metadata:
                return True
        
        # Check for certificate ARNs in affected resources
        has_cert_arn = any(
            'certificate' in resource.lower() or resource.startswith('arn:aws:acm:')
            for resource in incident.affected_resources
        )
        
        return has_cert_arn

    def _is_network_timeout(self, incident: IncidentEvent) -> bool:
        """
        Check if incident matches Network Timeout pattern.
        
        Pattern conditions:
        - Event type contains "Network", "Timeout", or "Connection"
        - Not a Lambda timeout (more specific pattern)
        - Metadata contains network-related information
        
        Args:
            incident: IncidentEvent
            
        Returns:
            True if matches pattern
        """
        event_type_lower = incident.event_type.lower()
        
        # Exclude Lambda timeouts (more specific pattern)
        if 'lambda' in event_type_lower:
            return False
        
        # Check event type
        network_keywords = ['network', 'timeout', 'connection', 'connectivity']
        if not any(keyword in event_type_lower for keyword in network_keywords):
            return False
        
        # Check metadata for network-related info
        if incident.metadata:
            network_keys = ['security_group', 'vpc_id', 'subnet_id', 'network_interface']
            has_network_metadata = any(key in incident.metadata for key in network_keys)
            if has_network_metadata:
                return True
        
        # Check for network resource IDs
        has_network_resource = any(
            resource.startswith(('sg-', 'vpc-', 'subnet-', 'eni-'))
            for resource in incident.affected_resources
        )
        
        return has_network_resource

    def _is_deployment_failure(self, incident: IncidentEvent) -> bool:
        """
        Check if incident matches Deployment Failure pattern.
        
        Pattern conditions:
        - Event type contains "Deployment", "Deploy", or "Release"
        - Metadata contains deployment-related information
        
        Args:
            incident: IncidentEvent
            
        Returns:
            True if matches pattern
        """
        event_type_lower = incident.event_type.lower()
        
        # Check event type
        deployment_keywords = ['deployment', 'deploy', 'release', 'rollout']
        if not any(keyword in event_type_lower for keyword in deployment_keywords):
            return False
        
        # Check metadata for deployment info
        if incident.metadata:
            deployment_keys = ['deployment_id', 'version', 'release_id', 'pipeline_id']
            has_deployment_metadata = any(key in incident.metadata for key in deployment_keys)
            if has_deployment_metadata:
                return True
        
        # Check for deployment-related resources
        has_deployment_resource = any(
            any(keyword in resource.lower() for keyword in ['deployment', 'pipeline', 'codedeploy'])
            for resource in incident.affected_resources
        )
        
        return has_deployment_resource

    def _is_service_unhealthy(self, incident: IncidentEvent) -> bool:
        """
        Check if incident matches Service Unhealthy/Crash pattern.
        
        Pattern conditions:
        - Event type contains "Unhealthy", "Crash", "Failed", or "Down"
        - Not covered by more specific patterns
        
        Args:
            incident: IncidentEvent
            
        Returns:
            True if matches pattern
        """
        event_type_lower = incident.event_type.lower()
        
        # Check event type
        service_keywords = ['unhealthy', 'crash', 'failed', 'down', 'unavailable', 'service']
        if not any(keyword in event_type_lower for keyword in service_keywords):
            return False
        
        # Exclude more specific patterns
        # (Lambda timeout, deployment failure already checked)
        
        # Check metadata for service health info
        if incident.metadata:
            health_keys = ['health_status', 'target_health', 'instance_state']
            has_health_metadata = any(key in incident.metadata for key in health_keys)
            if has_health_metadata:
                return True
        
        # Check for ECS, ELB, or other service resources
        has_service_resource = any(
            resource.startswith(('ecs:', 'elb:', 'arn:aws:ecs:', 'arn:aws:elasticloadbalancing:'))
            for resource in incident.affected_resources
        )
        
        return has_service_resource or True  # Default to service unhealthy if keywords match

    def get_pattern_description(self, pattern: IncidentPattern) -> str:
        """
        Get human-readable description of pattern.
        
        Args:
            pattern: IncidentPattern
            
        Returns:
            Description string
        """
        descriptions = {
            'ec2_cpu_memory_spike': 'EC2 instance experiencing high CPU or memory usage',
            'lambda_timeout': 'Lambda function execution timeout',
            'ssl_certificate_error': 'SSL/TLS certificate error or expiration',
            'network_timeout': 'Network connectivity or timeout issue',
            'deployment_failure': 'Deployment or release failure',
            'service_unhealthy': 'Service health check failure or crash',
            'unknown': 'Unknown incident type - no pattern match'
        }
        return descriptions.get(pattern, 'Unknown pattern')

    def get_remediation_handler(self, pattern: IncidentPattern) -> str:
        """
        Get the remediation handler name for a pattern.
        
        Args:
            pattern: IncidentPattern
            
        Returns:
            Handler name
        """
        handlers = {
            'ec2_cpu_memory_spike': 'EC2RemediationHandler',
            'lambda_timeout': 'LambdaTimeoutHandler',
            'ssl_certificate_error': 'SSLCertificateHandler',
            'network_timeout': 'NetworkTimeoutHandler',
            'deployment_failure': 'DeploymentFailureHandler',
            'service_unhealthy': 'ServiceHealthHandler',
            'unknown': 'EscalationHandler'
        }
        return handlers.get(pattern, 'EscalationHandler')

    def evaluate_all_patterns(self, incident: IncidentEvent) -> Dict[str, bool]:
        """
        Evaluate incident against all patterns for debugging.
        
        Property 33: Pattern evaluation completeness
        
        Args:
            incident: IncidentEvent
            
        Returns:
            Dictionary mapping pattern names to match results
        """
        return {
            'ec2_cpu_memory_spike': self._is_ec2_cpu_memory_spike(incident),
            'lambda_timeout': self._is_lambda_timeout(incident),
            'ssl_certificate_error': self._is_ssl_certificate_error(incident),
            'network_timeout': self._is_network_timeout(incident),
            'deployment_failure': self._is_deployment_failure(incident),
            'service_unhealthy': self._is_service_unhealthy(incident)
        }

    def get_pattern_confidence(self, incident: IncidentEvent, pattern: IncidentPattern) -> float:
        """
        Get confidence score for a pattern match.
        
        Args:
            incident: IncidentEvent
            pattern: IncidentPattern to evaluate
            
        Returns:
            Confidence score (0.0 to 1.0)
        """
        if pattern == 'unknown':
            return 0.0
        
        # Check if pattern matches
        pattern_methods = {
            'ec2_cpu_memory_spike': self._is_ec2_cpu_memory_spike,
            'lambda_timeout': self._is_lambda_timeout,
            'ssl_certificate_error': self._is_ssl_certificate_error,
            'network_timeout': self._is_network_timeout,
            'deployment_failure': self._is_deployment_failure,
            'service_unhealthy': self._is_service_unhealthy
        }
        
        method = pattern_methods.get(pattern)
        if method and method(incident):
            # Pattern matches - return high confidence
            # Could be enhanced with more sophisticated scoring
            return 0.95
        else:
            return 0.0
