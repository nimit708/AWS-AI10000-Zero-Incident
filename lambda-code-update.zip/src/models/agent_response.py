"""Bedrock AI Agent response models"""
from typing import Optional, List, Dict, Any, Literal
from pydantic import BaseModel, Field, field_validator


class ResolutionStep(BaseModel):
    """Single step in a remediation procedure"""
    step_number: int = Field(ge=1)
    action: Literal['invoke_lambda', 'aws_api_call', 'wait', 'conditional']
    target: str = Field(min_length=1)
    parameters: Dict[str, Any] = Field(default_factory=dict)
    description: str = Field(min_length=1)


class AgentResponse(BaseModel):
    """Response from Bedrock AI Agent"""
    match_found: bool
    confidence: float = Field(ge=0.0, le=1.0)
    matched_incident: Optional[Dict[str, Any]] = None
    resolution_steps: Optional[List[ResolutionStep]] = None
    reasoning: str = Field(default="")

    @field_validator('matched_incident')
    @classmethod
    def validate_match_consistency(cls, v, info):
        """Ensure matched_incident is present when match_found is True"""
        if info.data.get('match_found') and v is None:
            raise ValueError("matched_incident must be provided when match_found is True")
        return v

    @field_validator('resolution_steps')
    @classmethod
    def validate_resolution_steps_consistency(cls, v, info):
        """Ensure resolution_steps is present when match_found is True"""
        if info.data.get('match_found') and v is None:
            raise ValueError("resolution_steps must be provided when match_found is True")
        return v
