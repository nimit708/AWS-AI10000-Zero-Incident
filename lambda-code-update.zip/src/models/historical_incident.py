"""Historical incident models for Knowledge Base"""
from typing import List, Dict, Any, Literal
from pydantic import BaseModel, Field
from .agent_response import ResolutionStep


class HistoricalIncident(BaseModel):
    """Historical incident stored in Knowledge Base"""
    incident_id: str
    timestamp: str
    event_type: str
    severity: str
    affected_resources: List[str]
    symptoms: List[str]  # Textual descriptions for semantic search
    root_cause: str
    resolution_steps: List[ResolutionStep]
    resolution_time: int  # seconds
    outcome: Literal['success', 'partial', 'failed']
    metadata: Dict[str, Any] = Field(default_factory=dict)


class IncidentDocument(BaseModel):
    """Complete incident document with embedding for Knowledge Base storage"""
    incident_id: str
    timestamp: str
    event_type: str
    severity: str
    affected_resources: List[str]
    symptoms: List[str]
    root_cause: str
    resolution_steps: List[ResolutionStep]
    resolution_time: int
    outcome: Literal['success', 'partial', 'failed']
    metadata: Dict[str, Any] = Field(default_factory=dict)
    embedding: List[float] = Field(default_factory=list)  # 1024-dimensional vector

    @classmethod
    def from_historical_incident(
        cls,
        incident: HistoricalIncident,
        embedding: List[float]
    ) -> 'IncidentDocument':
        """Create document from historical incident with embedding"""
        return cls(
            incident_id=incident.incident_id,
            timestamp=incident.timestamp,
            event_type=incident.event_type,
            severity=incident.severity,
            affected_resources=incident.affected_resources,
            symptoms=incident.symptoms,
            root_cause=incident.root_cause,
            resolution_steps=incident.resolution_steps,
            resolution_time=incident.resolution_time,
            outcome=incident.outcome,
            metadata=incident.metadata,
            embedding=embedding
        )
