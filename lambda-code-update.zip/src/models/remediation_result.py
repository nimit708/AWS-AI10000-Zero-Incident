"""Remediation result model"""
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


class RemediationResult(BaseModel):
    """Result of a remediation attempt"""
    success: bool
    actions_performed: List[str] = Field(default_factory=list)
    resolution_time: int  # seconds
    error_message: Optional[str] = None
    new_state: Dict[str, Any] = Field(default_factory=dict)

    @staticmethod
    def create_success(
        actions: List[str],
        resolution_time: int,
        new_state: Dict[str, Any]
    ) -> 'RemediationResult':
        """Create a successful remediation result"""
        return RemediationResult(
            success=True,
            actions_performed=actions,
            resolution_time=resolution_time,
            new_state=new_state
        )

    @staticmethod
    def create_failure(
        error_message: str,
        resolution_time: int,
        actions_attempted: List[str] = None
    ) -> 'RemediationResult':
        """Create a failed remediation result"""
        return RemediationResult(
            success=False,
            actions_performed=actions_attempted or [],
            resolution_time=resolution_time,
            error_message=error_message,
            new_state={}
        )
