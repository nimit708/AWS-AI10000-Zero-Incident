"""DynamoDB incident record model"""
from typing import List, Optional, Literal
from pydantic import BaseModel, Field
from datetime import datetime


class IncidentRecord(BaseModel):
    """Incident record stored in DynamoDB"""
    incident_id: str
    timestamp: int  # Unix epoch milliseconds
    source: str
    event_type: str
    severity: str
    affected_resources: List[str]
    status: Literal['received', 'analyzing', 'remediating', 'resolved', 'failed', 'escalated']
    routing_path: Literal['fast', 'structured']
    confidence: Optional[float] = None
    matched_incident_id: Optional[str] = None
    resolution_steps: Optional[List[str]] = None
    resolution_time: Optional[int] = None  # seconds
    error_message: Optional[str] = None
    created_at: str  # ISO 8601
    updated_at: str  # ISO 8601
    ttl: Optional[int] = None  # Unix epoch seconds

    @staticmethod
    def create_new(
        incident_id: str,
        source: str,
        event_type: str,
        severity: str,
        affected_resources: List[str],
        routing_path: Literal['fast', 'structured']
    ) -> 'IncidentRecord':
        """Create a new incident record with initial status"""
        now = datetime.utcnow()
        return IncidentRecord(
            incident_id=incident_id,
            timestamp=int(now.timestamp() * 1000),
            source=source,
            event_type=event_type,
            severity=severity,
            affected_resources=affected_resources,
            status='received',
            routing_path=routing_path,
            created_at=now.isoformat() + 'Z',
            updated_at=now.isoformat() + 'Z'
        )

    @staticmethod
    def from_incident_event(incident: 'IncidentEvent') -> 'IncidentRecord':
        """
        Create incident record from IncidentEvent.
        
        Args:
            incident: IncidentEvent to convert
            
        Returns:
            IncidentRecord with initial status
        """
        from src.models import IncidentEvent  # Import here to avoid circular dependency
        
        now = datetime.utcnow()
        return IncidentRecord(
            incident_id=incident.incident_id,
            timestamp=int(now.timestamp() * 1000),
            source=incident.source,
            event_type=incident.event_type,
            severity=incident.severity,
            affected_resources=incident.affected_resources,
            status='received',
            routing_path='fast',  # Will be updated after routing decision
            created_at=now.isoformat() + 'Z',
            updated_at=now.isoformat() + 'Z'
        )
