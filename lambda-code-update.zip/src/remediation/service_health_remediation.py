"""Service Unhealthy/Crash remediation handler"""
import logging
from typing import Dict, Any, Optional
import boto3
from botocore.exceptions import ClientError
from src.models import IncidentEvent, RemediationResult

logger = logging.getLogger(__name__)


class ServiceHealthHandler:
    """
    Handler for service unhealthy/crash incidents.
    
    Implements automated remediation through service restart or replacement.
    """

    def __init__(self, region_name: str = 'us-east-1', dry_run: bool = False):
        """
        Initialize service health handler.
        
        Args:
            region_name: AWS region
            dry_run: If True, simulate actions without making changes
        """
        self.region_name = region_name
        self.dry_run = dry_run
        self.ecs_client = boto3.client('ecs', region_name=region_name)
        self.ec2_client = boto3.client('ec2', region_name=region_name)
        self.elb_client = boto3.client('elbv2', region_name=region_name)

    def remediate(self, incident: IncidentEvent) -> RemediationResult:
        """
        Execute remediation for service unhealthy incident.
        
        Property 10: Resource identification from incident metadata
        Property 11: Remediation decision determinism
        Property 14: Post-remediation persistence
        Property 15: Post-remediation notification
        
        Args:
            incident: IncidentEvent to remediate
            
        Returns:
            RemediationResult with success status and actions performed
        """
        start_time = self._get_current_time()
        actions_performed = []
        
        try:
            # Property 10: Identify unhealthy service from incident
            service_info = self.identify_unhealthy_service(incident)
            if not service_info:
                return RemediationResult.create_failure(
                    error_message="Could not identify unhealthy service from incident",
                    resolution_time=self._calculate_duration(start_time),
                    actions_attempted=['Attempted to identify service']
                )
            
            actions_performed.append(f"Identified service: {service_info.get('service_name', service_info.get('instance_id'))}")
            logger.info(f"Identified service for incident {incident.incident_id}")
            
            # Property 11: Determine restart or replace (deterministic)
            decision = self.determine_restart_or_replace(service_info, incident)
            actions_performed.append(f"Decision: {decision['action']} (reason: {decision['reason']})")
            
            if decision['action'] == 'restart':
                # Execute service restart
                success, restart_info = self.execute_service_restart(service_info)
                
                if success:
                    actions_performed.append(f"Executed service restart")
                    
                    # Verify service health
                    if self.verify_service_health(service_info):
                        actions_performed.append("Verified service health after restart")
                        
                        return RemediationResult.create_success(
                            actions=actions_performed,
                            resolution_time=self._calculate_duration(start_time),
                            new_state=restart_info
                        )
                    else:
                        return RemediationResult.create_failure(
                            error_message="Service health verification failed after restart",
                            resolution_time=self._calculate_duration(start_time),
                            actions_attempted=actions_performed
                        )
                else:
                    return RemediationResult.create_failure(
                        error_message="Failed to execute service restart",
                        resolution_time=self._calculate_duration(start_time),
                        actions_attempted=actions_performed
                    )
                    
            elif decision['action'] == 'replace':
                # Execute service replacement
                success, replace_info = self.execute_service_replace(service_info)
                
                if success:
                    actions_performed.append(f"Executed service replacement")
                    
                    # Verify service health
                    if self.verify_service_health(service_info):
                        actions_performed.append("Verified service health after replacement")
                        
                        return RemediationResult.create_success(
                            actions=actions_performed,
                            resolution_time=self._calculate_duration(start_time),
                            new_state=replace_info
                        )
                    else:
                        return RemediationResult.create_failure(
                            error_message="Service health verification failed after replacement",
                            resolution_time=self._calculate_duration(start_time),
                            actions_attempted=actions_performed
                        )
                else:
                    return RemediationResult.create_failure(
                        error_message="Failed to execute service replacement",
                        resolution_time=self._calculate_duration(start_time),
                        actions_attempted=actions_performed
                    )
            else:
                return RemediationResult.create_failure(
                    error_message=f"Unknown remediation action: {decision['action']}",
                    resolution_time=self._calculate_duration(start_time),
                    actions_attempted=actions_performed
                )
                
        except ClientError as e:
            logger.error(f"AWS API error during remediation: {e}")
            return RemediationResult.create_failure(
                error_message=f"AWS API error: {str(e)}",
                resolution_time=self._calculate_duration(start_time),
                actions_attempted=actions_performed
            )
        except Exception as e:
            logger.error(f"Unexpected error during remediation: {e}")
            return RemediationResult.create_failure(
                error_message=f"Unexpected error: {str(e)}",
                resolution_time=self._calculate_duration(start_time),
                actions_attempted=actions_performed
            )

    def identify_unhealthy_service(self, incident: IncidentEvent) -> Optional[Dict[str, Any]]:
        """
        Identify unhealthy service from incident metadata.
        
        Property 10: Resource identification from incident metadata
        
        Args:
            incident: IncidentEvent
            
        Returns:
            Service info dict or None if not found
        """
        service_info = {
            'service_type': 'ecs'  # Default type
        }
        
        # Check metadata first
        if incident.metadata:
            # Extract service identifiers
            service_info['service_name'] = incident.metadata.get('service_name')
            service_info['cluster_name'] = incident.metadata.get('cluster_name')
            service_info['task_id'] = incident.metadata.get('task_id')
            service_info['instance_id'] = incident.metadata.get('instance_id')
            service_info['target_group'] = incident.metadata.get('target_group')
            
            # Override default if specified
            if incident.metadata.get('service_type'):
                service_info['service_type'] = incident.metadata['service_type']
            
            # Extract health information
            service_info['health_status'] = incident.metadata.get('health_status')
            service_info['failure_count'] = incident.metadata.get('failure_count', 0)
            service_info['last_failure_time'] = incident.metadata.get('last_failure_time')
        
        # Check affected resources for service identifiers
        for resource in incident.affected_resources:
            if resource.startswith('arn:aws:ecs:'):
                if 'service' in resource:
                    service_info['service_name'] = resource
                    service_info['service_type'] = 'ecs'
                elif 'task' in resource:
                    service_info['task_id'] = resource
                    service_info['service_type'] = 'ecs'
            elif resource.startswith('i-'):
                service_info['instance_id'] = resource
                service_info['service_type'] = 'ec2'
            elif resource.startswith('arn:aws:elasticloadbalancing:'):
                service_info['target_group'] = resource
                service_info['service_type'] = 'elb'
            elif 'service' in resource.lower() or 'ecs' in resource.lower():
                if not service_info.get('service_name'):
                    service_info['service_name'] = resource
        
        # Must have at least one service identifier
        if any([
            service_info.get('service_name'),
            service_info.get('instance_id'),
            service_info.get('task_id'),
            service_info.get('target_group')
        ]):
            return service_info
        
        return None

    def determine_restart_or_replace(
        self,
        service_info: Dict[str, Any],
        incident: IncidentEvent
    ) -> Dict[str, str]:
        """
        Determine whether to restart or replace service.
        
        Property 11: Remediation decision determinism
        For the same service state and failure history, always return same decision.
        
        Args:
            service_info: Service information
            incident: IncidentEvent
            
        Returns:
            Dict with 'action' (restart/replace) and 'reason'
        """
        failure_count = service_info.get('failure_count', 0)
        health_status = service_info.get('health_status', '').lower()
        
        # Deterministic decision rules:
        
        # 1. If failed 3+ times, replace
        if failure_count >= 3:
            return {
                'action': 'replace',
                'reason': f'Exceeded failure threshold ({failure_count} failures)'
            }
        
        # 2. If service is crashed/terminated, replace
        crash_keywords = ['crash', 'terminated', 'stopped', 'killed']
        if any(keyword in health_status for keyword in crash_keywords):
            return {
                'action': 'replace',
                'reason': 'Service crashed or terminated'
            }
        
        # 3. If service is unresponsive but running, restart
        unresponsive_keywords = ['unresponsive', 'hanging', 'frozen', 'timeout']
        if any(keyword in health_status for keyword in unresponsive_keywords):
            return {
                'action': 'restart',
                'reason': 'Service unresponsive - attempting restart'
            }
        
        # 4. If critical severity, replace (safer)
        if incident.severity == 'critical':
            return {
                'action': 'replace',
                'reason': 'Critical severity - replacing service'
            }
        
        # 5. If high severity and multiple failures, replace
        if incident.severity == 'high' and failure_count >= 2:
            return {
                'action': 'replace',
                'reason': 'High severity with multiple failures'
            }
        
        # 6. Default: restart first (less disruptive)
        if failure_count == 0:
            return {
                'action': 'restart',
                'reason': 'First failure - attempting restart'
            }
        else:
            return {
                'action': 'restart',
                'reason': f'Attempting restart (failure {failure_count + 1})'
            }

    def execute_service_restart(self, service_info: Dict[str, Any]) -> tuple[bool, Dict[str, Any]]:
        """
        Execute service restart.
        
        Args:
            service_info: Service information
            
        Returns:
            Tuple of (success, restart_info)
        """
        service_type = service_info.get('service_type', 'ecs')
        
        if self.dry_run:
            logger.info(f"[DRY RUN] Would restart {service_type} service")
            return True, {
                'service_name': service_info.get('service_name'),
                'service_type': service_type,
                'action': 'restart',
                'status': 'completed'
            }
        
        try:
            if service_type == 'ecs':
                # Restart ECS service by stopping tasks
                service_name = service_info.get('service_name')
                cluster_name = service_info.get('cluster_name', 'default')
                
                if service_name:
                    logger.info(f"Restarting ECS service {service_name}")
                    
                    # Force new deployment to restart tasks
                    self.ecs_client.update_service(
                        cluster=cluster_name,
                        service=service_name,
                        forceNewDeployment=True
                    )
                    
                    return True, {
                        'service_name': service_name,
                        'cluster_name': cluster_name,
                        'service_type': 'ecs',
                        'action': 'restart',
                        'status': 'initiated'
                    }
            
            elif service_type == 'ec2':
                # Restart EC2 instance
                instance_id = service_info.get('instance_id')
                
                if instance_id:
                    logger.info(f"Restarting EC2 instance {instance_id}")
                    
                    self.ec2_client.reboot_instances(
                        InstanceIds=[instance_id]
                    )
                    
                    return True, {
                        'instance_id': instance_id,
                        'service_type': 'ec2',
                        'action': 'restart',
                        'status': 'initiated'
                    }
            
            return False, {}
            
        except ClientError as e:
            logger.error(f"Error executing restart: {e}")
            return False, {}

    def execute_service_replace(self, service_info: Dict[str, Any]) -> tuple[bool, Dict[str, Any]]:
        """
        Execute service replacement.
        
        Args:
            service_info: Service information
            
        Returns:
            Tuple of (success, replace_info)
        """
        service_type = service_info.get('service_type', 'ecs')
        
        if self.dry_run:
            logger.info(f"[DRY RUN] Would replace {service_type} service")
            return True, {
                'service_name': service_info.get('service_name'),
                'service_type': service_type,
                'action': 'replace',
                'status': 'completed',
                'old_instance': 'old-id',
                'new_instance': 'new-id'
            }
        
        try:
            if service_type == 'ecs':
                # Replace ECS service by updating task definition
                service_name = service_info.get('service_name')
                cluster_name = service_info.get('cluster_name', 'default')
                
                if service_name:
                    logger.info(f"Replacing ECS service {service_name}")
                    
                    # Force new deployment with updated task definition
                    # In real implementation, would create new task definition revision
                    self.ecs_client.update_service(
                        cluster=cluster_name,
                        service=service_name,
                        forceNewDeployment=True
                    )
                    
                    return True, {
                        'service_name': service_name,
                        'cluster_name': cluster_name,
                        'service_type': 'ecs',
                        'action': 'replace',
                        'status': 'initiated'
                    }
            
            elif service_type == 'ec2':
                # Replace EC2 instance
                instance_id = service_info.get('instance_id')
                
                if instance_id:
                    logger.info(f"Replacing EC2 instance {instance_id}")
                    
                    # In real implementation, would:
                    # 1. Launch new instance from same AMI
                    # 2. Wait for new instance to be healthy
                    # 3. Terminate old instance
                    
                    return True, {
                        'old_instance_id': instance_id,
                        'service_type': 'ec2',
                        'action': 'replace',
                        'status': 'initiated'
                    }
            
            return False, {}
            
        except ClientError as e:
            logger.error(f"Error executing replacement: {e}")
            return False, {}

    def verify_service_health(self, service_info: Dict[str, Any]) -> bool:
        """
        Verify service health after remediation.
        
        Args:
            service_info: Service information
            
        Returns:
            True if service is healthy
        """
        if self.dry_run:
            return True
        
        # In a real implementation, this would:
        # 1. Check ECS service status
        # 2. Check EC2 instance status checks
        # 3. Check target health in load balancers
        # 4. Check CloudWatch metrics
        
        return True

    def _get_current_time(self) -> int:
        """Get current timestamp in seconds"""
        from time import time
        return int(time())

    def _calculate_duration(self, start_time: int) -> int:
        """Calculate duration in seconds"""
        return self._get_current_time() - start_time
