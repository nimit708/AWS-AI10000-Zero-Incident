"""EC2 CPU/Memory Spike remediation handler"""
import logging
from typing import Dict, Any, Literal, Optional, List
import boto3
from botocore.exceptions import ClientError
from src.models import IncidentEvent, RemediationResult

logger = logging.getLogger(__name__)

# Type aliases
ScalingStrategy = Literal['vertical', 'horizontal', 'none']
InstanceSize = Literal['nano', 'micro', 'small', 'medium', 'large', 'xlarge', '2xlarge']


class EC2RemediationHandler:
    """
    Handler for EC2 CPU/Memory spike incidents.
    
    Implements automated remediation through vertical or horizontal scaling.
    """

    def __init__(self, region_name: str = 'us-east-1', dry_run: bool = False):
        """
        Initialize EC2 remediation handler.
        
        Args:
            region_name: AWS region
            dry_run: If True, simulate actions without making changes
        """
        self.region_name = region_name
        self.dry_run = dry_run
        self.ec2_client = boto3.client('ec2', region_name=region_name)
        self.autoscaling_client = boto3.client('autoscaling', region_name=region_name)

    def remediate(self, incident: IncidentEvent) -> RemediationResult:
        """
        Execute remediation for EC2 CPU/Memory spike incident.
        
        Property 10: Resource identification from incident metadata
        Property 11: Remediation decision determinism
        Property 14: Post-remediation persistence
        Property 15: Post-remediation notification
        
        Args:
            incident: IncidentEvent to remediate
            
        Returns:
            RemediationResult with success status and actions performed
        """
        start_time = self._get_current_time()
        actions_performed = []
        
        try:
            # Property 10: Identify EC2 instance from incident
            instance_id = self.identify_ec2_instance(incident)
            if not instance_id:
                return RemediationResult.create_failure(
                    error_message="Could not identify EC2 instance from incident",
                    resolution_time=self._calculate_duration(start_time),
                    actions_attempted=['Attempted to identify EC2 instance']
                )
            
            actions_performed.append(f"Identified EC2 instance: {instance_id}")
            logger.info(f"Identified EC2 instance {instance_id} for incident {incident.incident_id}")
            
            # Get current instance details
            instance_details = self._get_instance_details(instance_id)
            if not instance_details:
                return RemediationResult.create_failure(
                    error_message=f"Could not retrieve details for instance {instance_id}",
                    resolution_time=self._calculate_duration(start_time),
                    actions_attempted=actions_performed
                )
            
            actions_performed.append(f"Retrieved instance details: {instance_details['InstanceType']}")
            
            # Property 11: Evaluate scaling strategy (deterministic)
            strategy = self.evaluate_scaling_strategy(instance_details, incident)
            actions_performed.append(f"Determined scaling strategy: {strategy}")
            logger.info(f"Scaling strategy for {instance_id}: {strategy}")
            
            if strategy == 'none':
                return RemediationResult.create_success(
                    actions=['No scaling needed - instance already appropriately sized'],
                    resolution_time=self._calculate_duration(start_time),
                    new_state={'instance_id': instance_id, 'action': 'none'}
                )
            
            # Execute scaling based on strategy
            if strategy == 'vertical':
                success, new_state = self.execute_vertical_scaling(instance_id, instance_details)
                if success:
                    actions_performed.append(f"Vertically scaled instance to {new_state.get('new_instance_type')}")
                else:
                    return RemediationResult.create_failure(
                        error_message="Vertical scaling failed",
                        resolution_time=self._calculate_duration(start_time),
                        actions_attempted=actions_performed
                    )
            else:  # horizontal
                success, new_state = self.execute_horizontal_scaling(instance_id, instance_details)
                if success:
                    actions_performed.append(f"Horizontally scaled: added instances to Auto Scaling group")
                else:
                    return RemediationResult.create_failure(
                        error_message="Horizontal scaling failed",
                        resolution_time=self._calculate_duration(start_time),
                        actions_attempted=actions_performed
                    )
            
            # Verify new state
            if self.verify_new_state(instance_id, new_state):
                actions_performed.append("Verified new instance state")
                
                return RemediationResult.create_success(
                    actions=actions_performed,
                    resolution_time=self._calculate_duration(start_time),
                    new_state=new_state
                )
            else:
                return RemediationResult.create_failure(
                    error_message="State verification failed after scaling",
                    resolution_time=self._calculate_duration(start_time),
                    actions_attempted=actions_performed
                )
                
        except ClientError as e:
            logger.error(f"AWS API error during remediation: {e}")
            return RemediationResult.create_failure(
                error_message=f"AWS API error: {str(e)}",
                resolution_time=self._calculate_duration(start_time),
                actions_attempted=actions_performed
            )
        except Exception as e:
            logger.error(f"Unexpected error during remediation: {e}")
            return RemediationResult.create_failure(
                error_message=f"Unexpected error: {str(e)}",
                resolution_time=self._calculate_duration(start_time),
                actions_attempted=actions_performed
            )

    def identify_ec2_instance(self, incident: IncidentEvent) -> Optional[str]:
        """
        Identify EC2 instance from incident metadata.
        
        Property 10: Resource identification from incident metadata
        
        Args:
            incident: IncidentEvent
            
        Returns:
            Instance ID or None if not found
        """
        # Check affected resources for instance IDs
        for resource in incident.affected_resources:
            if resource.startswith('i-') and len(resource) >= 10:  # EC2 instance ID format (at least i-xxxxxxxx)
                return resource
        
        # Check metadata for instance ID
        if incident.metadata:
            instance_id = incident.metadata.get('instance_id')
            if instance_id and instance_id.startswith('i-'):
                return instance_id
            
            # Check dimensions in CloudWatch metadata
            dimensions = incident.metadata.get('dimensions', {})
            if isinstance(dimensions, dict):
                instance_id = dimensions.get('InstanceId')
                if instance_id:
                    return instance_id
        
        return None

    def evaluate_scaling_strategy(
        self,
        instance_details: Dict[str, Any],
        incident: IncidentEvent
    ) -> ScalingStrategy:
        """
        Evaluate whether to scale vertically or horizontally.
        
        Property 11: Remediation decision determinism
        For the same instance type and incident severity, always choose the same strategy.
        
        Args:
            instance_details: EC2 instance details
            incident: IncidentEvent
            
        Returns:
            ScalingStrategy: 'vertical', 'horizontal', or 'none'
        """
        instance_type = instance_details.get('InstanceType', '')
        
        # Parse instance size
        size = self._parse_instance_size(instance_type)
        
        # Check if instance is in Auto Scaling group
        in_asg = self._is_in_autoscaling_group(instance_details.get('InstanceId'))
        
        # Decision logic (deterministic):
        # 1. Small instances (nano, micro, small) → vertical scaling
        # 2. Medium instances → vertical if not in ASG, horizontal if in ASG
        # 3. Large instances (large, xlarge, 2xlarge+) → horizontal scaling
        # 4. Already at maximum size → horizontal scaling
        
        if size in ['nano', 'micro', 'small']:
            return 'vertical'
        elif size == 'medium':
            return 'horizontal' if in_asg else 'vertical'
        elif size in ['large', 'xlarge', '2xlarge']:
            if in_asg:
                return 'horizontal'
            else:
                # Check if we can scale vertically
                next_size = self._get_next_instance_size(instance_type)
                return 'vertical' if next_size else 'none'
        else:
            # Unknown or very large size
            return 'horizontal' if in_asg else 'none'

    def execute_vertical_scaling(
        self,
        instance_id: str,
        instance_details: Dict[str, Any]
    ) -> tuple[bool, Dict[str, Any]]:
        """
        Execute vertical scaling by changing instance type.
        
        Args:
            instance_id: EC2 instance ID
            instance_details: Current instance details
            
        Returns:
            Tuple of (success, new_state)
        """
        current_type = instance_details.get('InstanceType')
        new_type = self._get_next_instance_size(current_type)
        
        if not new_type:
            logger.warning(f"No larger instance type available for {current_type}")
            return False, {}
        
        if self.dry_run:
            logger.info(f"[DRY RUN] Would scale {instance_id} from {current_type} to {new_type}")
            return True, {
                'instance_id': instance_id,
                'old_instance_type': current_type,
                'new_instance_type': new_type,
                'scaling_type': 'vertical'
            }
        
        try:
            # Stop instance
            logger.info(f"Stopping instance {instance_id}")
            self.ec2_client.stop_instances(InstanceIds=[instance_id])
            
            # Wait for instance to stop
            waiter = self.ec2_client.get_waiter('instance_stopped')
            waiter.wait(InstanceIds=[instance_id])
            
            # Modify instance type
            logger.info(f"Changing instance type from {current_type} to {new_type}")
            self.ec2_client.modify_instance_attribute(
                InstanceId=instance_id,
                InstanceType={'Value': new_type}
            )
            
            # Start instance
            logger.info(f"Starting instance {instance_id}")
            self.ec2_client.start_instances(InstanceIds=[instance_id])
            
            return True, {
                'instance_id': instance_id,
                'old_instance_type': current_type,
                'new_instance_type': new_type,
                'scaling_type': 'vertical'
            }
            
        except ClientError as e:
            logger.error(f"Error during vertical scaling: {e}")
            return False, {}

    def execute_horizontal_scaling(
        self,
        instance_id: str,
        instance_details: Dict[str, Any]
    ) -> tuple[bool, Dict[str, Any]]:
        """
        Execute horizontal scaling by increasing Auto Scaling group capacity.
        
        Args:
            instance_id: EC2 instance ID
            instance_details: Current instance details
            
        Returns:
            Tuple of (success, new_state)
        """
        # Find Auto Scaling group
        asg_name = self._get_autoscaling_group_name(instance_id)
        
        if not asg_name:
            logger.warning(f"Instance {instance_id} not in Auto Scaling group")
            return False, {}
        
        if self.dry_run:
            logger.info(f"[DRY RUN] Would increase capacity for ASG {asg_name}")
            return True, {
                'instance_id': instance_id,
                'asg_name': asg_name,
                'scaling_type': 'horizontal',
                'action': 'increased_capacity'
            }
        
        try:
            # Get current ASG details
            response = self.autoscaling_client.describe_auto_scaling_groups(
                AutoScalingGroupNames=[asg_name]
            )
            
            if not response['AutoScalingGroups']:
                return False, {}
            
            asg = response['AutoScalingGroups'][0]
            current_capacity = asg['DesiredCapacity']
            max_capacity = asg['MaxSize']
            
            # Increase desired capacity by 1 (up to max)
            new_capacity = min(current_capacity + 1, max_capacity)
            
            if new_capacity == current_capacity:
                logger.warning(f"ASG {asg_name} already at maximum capacity")
                return False, {}
            
            logger.info(f"Increasing ASG {asg_name} capacity from {current_capacity} to {new_capacity}")
            self.autoscaling_client.set_desired_capacity(
                AutoScalingGroupName=asg_name,
                DesiredCapacity=new_capacity
            )
            
            return True, {
                'instance_id': instance_id,
                'asg_name': asg_name,
                'old_capacity': current_capacity,
                'new_capacity': new_capacity,
                'scaling_type': 'horizontal'
            }
            
        except ClientError as e:
            logger.error(f"Error during horizontal scaling: {e}")
            return False, {}

    def verify_new_state(self, instance_id: str, new_state: Dict[str, Any]) -> bool:
        """
        Verify that scaling was successful.
        
        Args:
            instance_id: EC2 instance ID
            new_state: Expected new state
            
        Returns:
            True if verification successful
        """
        if self.dry_run:
            return True
        
        try:
            scaling_type = new_state.get('scaling_type')
            
            if scaling_type == 'vertical':
                # Verify instance type changed
                instance_details = self._get_instance_details(instance_id)
                if not instance_details:
                    return False
                
                current_type = instance_details.get('InstanceType')
                expected_type = new_state.get('new_instance_type')
                
                return current_type == expected_type
                
            elif scaling_type == 'horizontal':
                # Verify ASG capacity increased
                asg_name = new_state.get('asg_name')
                if not asg_name:
                    return False
                
                response = self.autoscaling_client.describe_auto_scaling_groups(
                    AutoScalingGroupNames=[asg_name]
                )
                
                if not response['AutoScalingGroups']:
                    return False
                
                asg = response['AutoScalingGroups'][0]
                current_capacity = asg['DesiredCapacity']
                expected_capacity = new_state.get('new_capacity')
                
                return current_capacity == expected_capacity
            
            return False
            
        except ClientError as e:
            logger.error(f"Error verifying new state: {e}")
            return False

    def _get_instance_details(self, instance_id: str) -> Optional[Dict[str, Any]]:
        """Get EC2 instance details"""
        try:
            response = self.ec2_client.describe_instances(InstanceIds=[instance_id])
            
            if not response['Reservations'] or not response['Reservations'][0]['Instances']:
                return None
            
            return response['Reservations'][0]['Instances'][0]
            
        except ClientError as e:
            logger.error(f"Error getting instance details: {e}")
            return None

    def _parse_instance_size(self, instance_type: str) -> InstanceSize:
        """Parse instance size from instance type (e.g., 't3.micro' -> 'micro')"""
        if '.' not in instance_type:
            return 'medium'  # Default
        
        size = instance_type.split('.')[1]
        
        # Map to standard sizes
        if size in ['nano', 'micro', 'small', 'medium', 'large', 'xlarge', '2xlarge']:
            return size  # type: ignore
        elif size.endswith('xlarge'):
            return '2xlarge'
        else:
            return 'medium'

    def _get_next_instance_size(self, current_type: str) -> Optional[str]:
        """Get next larger instance size"""
        if '.' not in current_type:
            return None
        
        family, size = current_type.split('.', 1)
        
        # Size progression
        size_map = {
            'nano': 'micro',
            'micro': 'small',
            'small': 'medium',
            'medium': 'large',
            'large': 'xlarge',
            'xlarge': '2xlarge',
            '2xlarge': '4xlarge',
            '4xlarge': '8xlarge'
        }
        
        next_size = size_map.get(size)
        return f"{family}.{next_size}" if next_size else None

    def _is_in_autoscaling_group(self, instance_id: str) -> bool:
        """Check if instance is in an Auto Scaling group"""
        try:
            response = self.autoscaling_client.describe_auto_scaling_instances(
                InstanceIds=[instance_id]
            )
            return len(response.get('AutoScalingInstances', [])) > 0
        except ClientError:
            return False

    def _get_autoscaling_group_name(self, instance_id: str) -> Optional[str]:
        """Get Auto Scaling group name for instance"""
        try:
            response = self.autoscaling_client.describe_auto_scaling_instances(
                InstanceIds=[instance_id]
            )
            
            instances = response.get('AutoScalingInstances', [])
            if instances:
                return instances[0].get('AutoScalingGroupName')
            
            return None
        except ClientError:
            return None

    def _get_current_time(self) -> int:
        """Get current timestamp in seconds"""
        from time import time
        return int(time())

    def _calculate_duration(self, start_time: int) -> int:
        """Calculate duration in seconds"""
        return self._get_current_time() - start_time
