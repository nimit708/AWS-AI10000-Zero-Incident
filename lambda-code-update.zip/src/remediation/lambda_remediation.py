"""Lambda Timeout remediation handler"""
import logging
from typing import Dict, Any, Optional, List
import boto3
from botocore.exceptions import ClientError
from src.models import IncidentEvent, RemediationResult

logger = logging.getLogger(__name__)


class LambdaTimeoutHandler:
    """
    Handler for Lambda timeout incidents.
    
    Implements automated remediation through timeout configuration adjustment.
    """

    def __init__(self, region_name: str = 'us-east-1', dry_run: bool = False):
        """
        Initialize Lambda timeout handler.
        
        Args:
            region_name: AWS region
            dry_run: If True, simulate actions without making changes
        """
        self.region_name = region_name
        self.dry_run = dry_run
        self.lambda_client = boto3.client('lambda', region_name=region_name)
        self.cloudwatch_client = boto3.client('cloudwatch', region_name=region_name)

    def remediate(self, incident: IncidentEvent) -> RemediationResult:
        """
        Execute remediation for Lambda timeout incident.
        
        Property 10: Resource identification from incident metadata
        Property 11: Remediation decision determinism
        Property 14: Post-remediation persistence
        Property 15: Post-remediation notification
        
        Args:
            incident: IncidentEvent to remediate
            
        Returns:
            RemediationResult with success status and actions performed
        """
        start_time = self._get_current_time()
        actions_performed = []
        
        try:
            # Property 10: Identify Lambda function from incident
            function_name = self.identify_lambda_function(incident)
            if not function_name:
                return RemediationResult.create_failure(
                    error_message="Could not identify Lambda function from incident",
                    resolution_time=self._calculate_duration(start_time),
                    actions_attempted=['Attempted to identify Lambda function']
                )
            
            actions_performed.append(f"Identified Lambda function: {function_name}")
            logger.info(f"Identified Lambda function {function_name} for incident {incident.incident_id}")
            
            # Get current function configuration
            function_config = self._get_function_configuration(function_name)
            if not function_config:
                return RemediationResult.create_failure(
                    error_message=f"Could not retrieve configuration for function {function_name}",
                    resolution_time=self._calculate_duration(start_time),
                    actions_attempted=actions_performed
                )
            
            current_timeout = function_config.get('Timeout', 3)
            actions_performed.append(f"Current timeout: {current_timeout} seconds")
            
            # Analyze execution history to determine appropriate timeout
            execution_history = self.analyze_execution_history(function_name)
            actions_performed.append(f"Analyzed execution history: {len(execution_history)} recent invocations")
            
            # Property 11: Calculate recommended timeout (deterministic)
            recommended_timeout = self.calculate_recommended_timeout(
                current_timeout,
                execution_history,
                incident
            )
            actions_performed.append(f"Calculated recommended timeout: {recommended_timeout} seconds")
            
            # Check if timeout adjustment is needed
            if recommended_timeout == current_timeout:
                return RemediationResult.create_success(
                    actions=['No timeout adjustment needed - current timeout is appropriate'],
                    resolution_time=self._calculate_duration(start_time),
                    new_state={
                        'function_name': function_name,
                        'timeout': current_timeout,
                        'action': 'none'
                    }
                )
            
            # Update Lambda configuration
            success, new_state = self.update_lambda_configuration(
                function_name,
                recommended_timeout
            )
            
            if success:
                actions_performed.append(
                    f"Updated timeout from {current_timeout}s to {recommended_timeout}s"
                )
                
                # Verify configuration change
                if self.verify_configuration_change(function_name, recommended_timeout):
                    actions_performed.append("Verified configuration change")
                    
                    return RemediationResult.create_success(
                        actions=actions_performed,
                        resolution_time=self._calculate_duration(start_time),
                        new_state=new_state
                    )
                else:
                    return RemediationResult.create_failure(
                        error_message="Configuration verification failed",
                        resolution_time=self._calculate_duration(start_time),
                        actions_attempted=actions_performed
                    )
            else:
                return RemediationResult.create_failure(
                    error_message="Failed to update Lambda configuration",
                    resolution_time=self._calculate_duration(start_time),
                    actions_attempted=actions_performed
                )
                
        except ClientError as e:
            logger.error(f"AWS API error during remediation: {e}")
            return RemediationResult.create_failure(
                error_message=f"AWS API error: {str(e)}",
                resolution_time=self._calculate_duration(start_time),
                actions_attempted=actions_performed
            )
        except Exception as e:
            logger.error(f"Unexpected error during remediation: {e}")
            return RemediationResult.create_failure(
                error_message=f"Unexpected error: {str(e)}",
                resolution_time=self._calculate_duration(start_time),
                actions_attempted=actions_performed
            )

    def identify_lambda_function(self, incident: IncidentEvent) -> Optional[str]:
        """
        Identify Lambda function from incident metadata.
        
        Property 10: Resource identification from incident metadata
        
        Args:
            incident: IncidentEvent
            
        Returns:
            Function name or None if not found
        """
        # Check metadata first (more specific)
        if incident.metadata:
            # Check explicit function_name field
            function_name = incident.metadata.get('function_name')
            if function_name:
                return function_name
            
            # Check dimensions in CloudWatch metadata
            dimensions = incident.metadata.get('dimensions', {})
            if isinstance(dimensions, dict):
                function_name = dimensions.get('FunctionName')
                if function_name:
                    return function_name
            
            # Check alarm name for function name
            alarm_name = incident.metadata.get('alarm_name', '')
            if 'lambda' in alarm_name.lower() or 'function' in alarm_name.lower():
                # Try to extract function name from alarm name
                # Common patterns: "FunctionName-Timeout", "lambda-FunctionName-timeout"
                parts = alarm_name.split('-')
                for part in parts:
                    if part and not part.lower() in ['lambda', 'timeout', 'alarm', 'error']:
                        return part
        
        # Check affected resources for function names (fallback)
        for resource in incident.affected_resources:
            # Lambda function names don't have a specific prefix
            # but we can check if it's not an AWS resource ID
            if not resource.startswith(('i-', 'sg-', 'vpc-', 'arn:')):
                # Likely a function name
                return resource
        
        return None

    def analyze_execution_history(self, function_name: str) -> List[Dict[str, Any]]:
        """
        Analyze Lambda execution history from CloudWatch metrics.
        
        Args:
            function_name: Lambda function name
            
        Returns:
            List of execution data points
        """
        if self.dry_run:
            # Return mock data for dry run
            return [
                {'duration': 2500, 'timestamp': '2024-01-01T00:00:00Z'},
                {'duration': 2800, 'timestamp': '2024-01-01T00:01:00Z'},
                {'duration': 2600, 'timestamp': '2024-01-01T00:02:00Z'}
            ]
        
        try:
            from datetime import datetime, timedelta
            
            # Get duration metrics for the last hour
            end_time = datetime.utcnow()
            start_time = end_time - timedelta(hours=1)
            
            response = self.cloudwatch_client.get_metric_statistics(
                Namespace='AWS/Lambda',
                MetricName='Duration',
                Dimensions=[
                    {'Name': 'FunctionName', 'Value': function_name}
                ],
                StartTime=start_time,
                EndTime=end_time,
                Period=60,  # 1 minute
                Statistics=['Maximum', 'Average']
            )
            
            datapoints = response.get('Datapoints', [])
            
            # Convert to simplified format
            execution_history = []
            for dp in datapoints:
                execution_history.append({
                    'duration': dp.get('Maximum', dp.get('Average', 0)),
                    'timestamp': dp.get('Timestamp', '').isoformat() if dp.get('Timestamp') else ''
                })
            
            return execution_history
            
        except ClientError as e:
            logger.warning(f"Could not retrieve execution history: {e}")
            return []

    def calculate_recommended_timeout(
        self,
        current_timeout: int,
        execution_history: List[Dict[str, Any]],
        incident: IncidentEvent
    ) -> int:
        """
        Calculate recommended timeout based on execution history.
        
        Property 11: Remediation decision determinism
        For the same execution history and current timeout, always return the same value.
        
        Args:
            current_timeout: Current timeout in seconds
            execution_history: List of execution data
            incident: IncidentEvent
            
        Returns:
            Recommended timeout in seconds
        """
        # If no execution history, increase by 50%
        if not execution_history:
            new_timeout = int(current_timeout * 1.5)
            return min(new_timeout, 900)  # Max Lambda timeout is 900 seconds (15 minutes)
        
        # Calculate statistics from execution history
        durations = [exec_data['duration'] for exec_data in execution_history]
        
        if not durations:
            new_timeout = int(current_timeout * 1.5)
            return min(new_timeout, 900)
        
        # Convert milliseconds to seconds (CloudWatch returns duration in ms)
        durations_seconds = [d / 1000 for d in durations]
        
        # Calculate p95 duration (95th percentile)
        sorted_durations = sorted(durations_seconds)
        p95_index = int(len(sorted_durations) * 0.95)
        p95_duration = sorted_durations[p95_index] if p95_index < len(sorted_durations) else sorted_durations[-1]
        
        # Add 20% buffer to p95 duration
        recommended_timeout = int(p95_duration * 1.2)
        
        # Ensure minimum timeout of 3 seconds
        recommended_timeout = max(recommended_timeout, 3)
        
        # Ensure maximum timeout of 900 seconds
        recommended_timeout = min(recommended_timeout, 900)
        
        # Round to nearest 5 seconds for cleaner values
        recommended_timeout = ((recommended_timeout + 2) // 5) * 5
        
        return recommended_timeout

    def update_lambda_configuration(
        self,
        function_name: str,
        new_timeout: int
    ) -> tuple[bool, Dict[str, Any]]:
        """
        Update Lambda function timeout configuration.
        
        Args:
            function_name: Lambda function name
            new_timeout: New timeout in seconds
            
        Returns:
            Tuple of (success, new_state)
        """
        if self.dry_run:
            logger.info(f"[DRY RUN] Would update {function_name} timeout to {new_timeout}s")
            return True, {
                'function_name': function_name,
                'old_timeout': 3,  # Mock value
                'new_timeout': new_timeout,
                'action': 'timeout_updated'
            }
        
        try:
            # Get current configuration first
            current_config = self._get_function_configuration(function_name)
            old_timeout = current_config.get('Timeout', 3) if current_config else 3
            
            # Update function configuration
            logger.info(f"Updating {function_name} timeout to {new_timeout}s")
            self.lambda_client.update_function_configuration(
                FunctionName=function_name,
                Timeout=new_timeout
            )
            
            return True, {
                'function_name': function_name,
                'old_timeout': old_timeout,
                'new_timeout': new_timeout,
                'action': 'timeout_updated'
            }
            
        except ClientError as e:
            logger.error(f"Error updating Lambda configuration: {e}")
            return False, {}

    def verify_configuration_change(
        self,
        function_name: str,
        expected_timeout: int
    ) -> bool:
        """
        Verify that timeout configuration was updated successfully.
        
        Args:
            function_name: Lambda function name
            expected_timeout: Expected timeout value
            
        Returns:
            True if verification successful
        """
        if self.dry_run:
            return True
        
        try:
            config = self._get_function_configuration(function_name)
            if not config:
                return False
            
            current_timeout = config.get('Timeout', 0)
            return current_timeout == expected_timeout
            
        except ClientError as e:
            logger.error(f"Error verifying configuration: {e}")
            return False

    def _get_function_configuration(self, function_name: str) -> Optional[Dict[str, Any]]:
        """Get Lambda function configuration"""
        try:
            response = self.lambda_client.get_function_configuration(
                FunctionName=function_name
            )
            return response
        except ClientError as e:
            logger.error(f"Error getting function configuration: {e}")
            return None

    def _get_current_time(self) -> int:
        """Get current timestamp in seconds"""
        from time import time
        return int(time())

    def _calculate_duration(self, start_time: int) -> int:
        """Calculate duration in seconds"""
        return self._get_current_time() - start_time
