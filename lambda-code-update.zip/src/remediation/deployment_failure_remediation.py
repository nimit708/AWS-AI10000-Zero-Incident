"""Deployment Failure remediation handler"""
import logging
from typing import Dict, Any, Optional
import boto3
from botocore.exceptions import ClientError
from src.models import IncidentEvent, RemediationResult

logger = logging.getLogger(__name__)


class DeploymentFailureHandler:
    """
    Handler for deployment failure incidents.
    
    Implements automated remediation through rollback or retry.
    """

    def __init__(self, region_name: str = 'us-east-1', dry_run: bool = False):
        """
        Initialize deployment failure handler.
        
        Args:
            region_name: AWS region
            dry_run: If True, simulate actions without making changes
        """
        self.region_name = region_name
        self.dry_run = dry_run
        self.codedeploy_client = boto3.client('codedeploy', region_name=region_name)
        self.ecs_client = boto3.client('ecs', region_name=region_name)

    def remediate(self, incident: IncidentEvent) -> RemediationResult:
        """
        Execute remediation for deployment failure incident.
        
        Property 10: Resource identification from incident metadata
        Property 11: Remediation decision determinism
        Property 14: Post-remediation persistence
        Property 15: Post-remediation notification
        
        Args:
            incident: IncidentEvent to remediate
            
        Returns:
            RemediationResult with success status and actions performed
        """
        start_time = self._get_current_time()
        actions_performed = []
        
        try:
            # Property 10: Identify failed deployment from incident
            deployment_info = self.identify_failed_deployment(incident)
            if not deployment_info:
                return RemediationResult.create_failure(
                    error_message="Could not identify failed deployment from incident",
                    resolution_time=self._calculate_duration(start_time),
                    actions_attempted=['Attempted to identify deployment']
                )
            
            actions_performed.append(f"Identified deployment: {deployment_info['deployment_id']}")
            logger.info(f"Identified deployment {deployment_info['deployment_id']} for incident {incident.incident_id}")
            
            # Property 11: Determine rollback or retry (deterministic)
            decision = self.determine_rollback_or_retry(deployment_info, incident)
            actions_performed.append(f"Decision: {decision['action']} (reason: {decision['reason']})")
            
            if decision['action'] == 'rollback':
                # Execute rollback
                success, rollback_info = self.execute_rollback(deployment_info)
                
                if success:
                    actions_performed.append(f"Executed rollback to previous version")
                    
                    # Verify service health
                    if self.verify_service_health(deployment_info):
                        actions_performed.append("Verified service health after rollback")
                        
                        return RemediationResult.create_success(
                            actions=actions_performed,
                            resolution_time=self._calculate_duration(start_time),
                            new_state=rollback_info
                        )
                    else:
                        return RemediationResult.create_failure(
                            error_message="Service health verification failed after rollback",
                            resolution_time=self._calculate_duration(start_time),
                            actions_attempted=actions_performed
                        )
                else:
                    return RemediationResult.create_failure(
                        error_message="Failed to execute rollback",
                        resolution_time=self._calculate_duration(start_time),
                        actions_attempted=actions_performed
                    )
                    
            elif decision['action'] == 'retry':
                # Execute retry
                success, retry_info = self.execute_retry(deployment_info)
                
                if success:
                    actions_performed.append(f"Executed deployment retry")
                    
                    # Verify service health
                    if self.verify_service_health(deployment_info):
                        actions_performed.append("Verified service health after retry")
                        
                        return RemediationResult.create_success(
                            actions=actions_performed,
                            resolution_time=self._calculate_duration(start_time),
                            new_state=retry_info
                        )
                    else:
                        return RemediationResult.create_failure(
                            error_message="Service health verification failed after retry",
                            resolution_time=self._calculate_duration(start_time),
                            actions_attempted=actions_performed
                        )
                else:
                    return RemediationResult.create_failure(
                        error_message="Failed to execute retry",
                        resolution_time=self._calculate_duration(start_time),
                        actions_attempted=actions_performed
                    )
            else:
                return RemediationResult.create_failure(
                    error_message=f"Unknown remediation action: {decision['action']}",
                    resolution_time=self._calculate_duration(start_time),
                    actions_attempted=actions_performed
                )
                
        except ClientError as e:
            logger.error(f"AWS API error during remediation: {e}")
            return RemediationResult.create_failure(
                error_message=f"AWS API error: {str(e)}",
                resolution_time=self._calculate_duration(start_time),
                actions_attempted=actions_performed
            )
        except Exception as e:
            logger.error(f"Unexpected error during remediation: {e}")
            return RemediationResult.create_failure(
                error_message=f"Unexpected error: {str(e)}",
                resolution_time=self._calculate_duration(start_time),
                actions_attempted=actions_performed
            )

    def identify_failed_deployment(self, incident: IncidentEvent) -> Optional[Dict[str, Any]]:
        """
        Identify failed deployment from incident metadata.
        
        Property 10: Resource identification from incident metadata
        
        Args:
            incident: IncidentEvent
            
        Returns:
            Deployment info dict or None if not found
        """
        deployment_info = {
            'deployment_type': 'codedeploy'  # Default type
        }
        
        # Check metadata first
        if incident.metadata:
            # Extract deployment identifiers
            deployment_info['deployment_id'] = incident.metadata.get('deployment_id')
            deployment_info['deployment_group'] = incident.metadata.get('deployment_group')
            deployment_info['application_name'] = incident.metadata.get('application_name')
            deployment_info['service_name'] = incident.metadata.get('service_name')
            deployment_info['cluster_name'] = incident.metadata.get('cluster_name')
            
            # Override default if specified
            if incident.metadata.get('deployment_type'):
                deployment_info['deployment_type'] = incident.metadata['deployment_type']
            
            # Extract failure information
            deployment_info['failure_reason'] = incident.metadata.get('failure_reason')
            deployment_info['retry_count'] = incident.metadata.get('retry_count', 0)
        
        # Check affected resources for deployment identifiers
        for resource in incident.affected_resources:
            if 'deployment' in resource.lower():
                if not deployment_info.get('deployment_id'):
                    deployment_info['deployment_id'] = resource
            elif resource.startswith('arn:aws:codedeploy:'):
                deployment_info['deployment_id'] = resource
                deployment_info['deployment_type'] = 'codedeploy'
            elif resource.startswith('arn:aws:ecs:'):
                # For ECS, use metadata service_name if available, otherwise use ARN
                if not deployment_info.get('service_name'):
                    deployment_info['service_name'] = resource
                deployment_info['deployment_type'] = 'ecs'
        
        # Must have at least deployment_id or service_name
        if deployment_info.get('deployment_id') or deployment_info.get('service_name'):
            return deployment_info
        
        return None

    def determine_rollback_or_retry(
        self,
        deployment_info: Dict[str, Any],
        incident: IncidentEvent
    ) -> Dict[str, str]:
        """
        Determine whether to rollback or retry deployment.
        
        Property 11: Remediation decision determinism
        For the same deployment state and failure reason, always return same decision.
        
        Args:
            deployment_info: Deployment information
            incident: IncidentEvent
            
        Returns:
            Dict with 'action' (rollback/retry) and 'reason'
        """
        retry_count = deployment_info.get('retry_count', 0)
        failure_reason = deployment_info.get('failure_reason', '').lower()
        
        # Deterministic decision rules:
        
        # 1. If already retried 2+ times, rollback
        if retry_count >= 2:
            return {
                'action': 'rollback',
                'reason': f'Exceeded retry limit ({retry_count} retries)'
            }
        
        # 2. If failure is due to configuration error, rollback
        config_error_keywords = ['configuration', 'config', 'invalid', 'syntax', 'parse']
        if any(keyword in failure_reason for keyword in config_error_keywords):
            return {
                'action': 'rollback',
                'reason': 'Configuration error detected'
            }
        
        # 3. If failure is due to transient error, retry
        transient_error_keywords = ['timeout', 'throttl', 'capacity', 'unavailable', 'network']
        if any(keyword in failure_reason for keyword in transient_error_keywords):
            return {
                'action': 'retry',
                'reason': 'Transient error detected'
            }
        
        # 4. If high severity, rollback (safer)
        if incident.severity in ['critical', 'high']:
            return {
                'action': 'rollback',
                'reason': f'High severity incident ({incident.severity})'
            }
        
        # 5. Default: retry once, then rollback
        if retry_count == 0:
            return {
                'action': 'retry',
                'reason': 'First failure - attempting retry'
            }
        else:
            return {
                'action': 'rollback',
                'reason': 'Retry failed - rolling back'
            }

    def execute_rollback(self, deployment_info: Dict[str, Any]) -> tuple[bool, Dict[str, Any]]:
        """
        Execute deployment rollback.
        
        Args:
            deployment_info: Deployment information
            
        Returns:
            Tuple of (success, rollback_info)
        """
        deployment_type = deployment_info.get('deployment_type', 'codedeploy')
        
        if self.dry_run:
            logger.info(f"[DRY RUN] Would rollback deployment {deployment_info.get('deployment_id')}")
            return True, {
                'deployment_id': deployment_info.get('deployment_id'),
                'action': 'rollback',
                'status': 'completed',
                'previous_version': 'v1.0.0',
                'rolled_back_to': 'v0.9.0',
                'deployment_type': deployment_type
            }
        
        try:
            if deployment_type == 'codedeploy':
                # Stop current deployment
                deployment_id = deployment_info.get('deployment_id')
                if deployment_id:
                    self.codedeploy_client.stop_deployment(
                        deploymentId=deployment_id,
                        autoRollbackEnabled=True
                    )
                    
                    return True, {
                        'deployment_id': deployment_id,
                        'action': 'rollback',
                        'status': 'initiated',
                        'deployment_type': 'codedeploy'
                    }
            
            elif deployment_type == 'ecs':
                # ECS rollback by updating service to previous task definition
                service_name = deployment_info.get('service_name')
                cluster_name = deployment_info.get('cluster_name', 'default')
                
                if service_name:
                    # In real implementation, would get previous task definition
                    # and update service to use it
                    logger.info(f"Rolling back ECS service {service_name}")
                    
                    return True, {
                        'service_name': service_name,
                        'cluster_name': cluster_name,
                        'action': 'rollback',
                        'status': 'initiated',
                        'deployment_type': 'ecs'
                    }
            
            return False, {}
            
        except ClientError as e:
            logger.error(f"Error executing rollback: {e}")
            return False, {}

    def execute_retry(self, deployment_info: Dict[str, Any]) -> tuple[bool, Dict[str, Any]]:
        """
        Execute deployment retry.
        
        Args:
            deployment_info: Deployment information
            
        Returns:
            Tuple of (success, retry_info)
        """
        deployment_type = deployment_info.get('deployment_type', 'codedeploy')
        
        if self.dry_run:
            logger.info(f"[DRY RUN] Would retry deployment {deployment_info.get('deployment_id')}")
            return True, {
                'deployment_id': deployment_info.get('deployment_id'),
                'action': 'retry',
                'status': 'initiated',
                'retry_count': deployment_info.get('retry_count', 0) + 1,
                'deployment_type': deployment_type
            }
        
        try:
            if deployment_type == 'codedeploy':
                # Create new deployment with same configuration
                deployment_group = deployment_info.get('deployment_group')
                application_name = deployment_info.get('application_name')
                
                if deployment_group and application_name:
                    # In real implementation, would create new deployment
                    logger.info(f"Retrying CodeDeploy deployment for {application_name}/{deployment_group}")
                    
                    return True, {
                        'application_name': application_name,
                        'deployment_group': deployment_group,
                        'action': 'retry',
                        'status': 'initiated',
                        'retry_count': deployment_info.get('retry_count', 0) + 1,
                        'deployment_type': 'codedeploy'
                    }
            
            elif deployment_type == 'ecs':
                # ECS retry by forcing new deployment
                service_name = deployment_info.get('service_name')
                cluster_name = deployment_info.get('cluster_name', 'default')
                
                if service_name:
                    logger.info(f"Retrying ECS deployment for {service_name}")
                    
                    return True, {
                        'service_name': service_name,
                        'cluster_name': cluster_name,
                        'action': 'retry',
                        'status': 'initiated',
                        'retry_count': deployment_info.get('retry_count', 0) + 1,
                        'deployment_type': 'ecs'
                    }
            
            return False, {}
            
        except ClientError as e:
            logger.error(f"Error executing retry: {e}")
            return False, {}

    def verify_service_health(self, deployment_info: Dict[str, Any]) -> bool:
        """
        Verify service health after remediation.
        
        Args:
            deployment_info: Deployment information
            
        Returns:
            True if service is healthy
        """
        if self.dry_run:
            return True
        
        # In a real implementation, this would:
        # 1. Check deployment status
        # 2. Check service health checks
        # 3. Check CloudWatch metrics
        # 4. Verify target health in load balancers
        
        return True

    def _get_current_time(self) -> int:
        """Get current timestamp in seconds"""
        from time import time
        return int(time())

    def _calculate_duration(self, start_time: int) -> int:
        """Calculate duration in seconds"""
        return self._get_current_time() - start_time
