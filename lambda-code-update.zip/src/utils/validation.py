"""Event validation utilities"""
from typing import Optional, Dict, Any
from dataclasses import dataclass
from pydantic import ValidationError
from src.models import IncomingEvent, IncidentEvent


@dataclass
class ValidationResult:
    """Result of event validation"""
    valid: bool
    metadata: Optional[IncidentEvent] = None
    error: Optional[Dict[str, Any]] = None

    @staticmethod
    def success(incident: IncidentEvent) -> 'ValidationResult':
        """Create successful validation result"""
        return ValidationResult(valid=True, metadata=incident)

    @staticmethod
    def failure(error_message: str, details: Optional[Dict[str, Any]] = None) -> 'ValidationResult':
        """Create failed validation result"""
        return ValidationResult(
            valid=False,
            error={
                'message': error_message,
                'details': details or {}
            }
        )


def validate_event(event: Dict[str, Any]) -> ValidationResult:
    """
    Validate incoming event structure and content.
    
    Property 1: Event validation consistency
    For any incoming event, the validation function should either accept it 
    and extract all required metadata fields, or reject it with a descriptive 
    error message. There should be no partial acceptance.
    
    Args:
        event: Raw event dictionary
        
    Returns:
        ValidationResult with either valid metadata or error details
    """
    try:
        # Validate basic structure
        if not isinstance(event, dict):
            return ValidationResult.failure(
                "Event must be a dictionary",
                {'received_type': type(event).__name__}
            )

        # Check required top-level fields
        required_fields = ['source', 'timestamp', 'raw_payload']
        missing_fields = [f for f in required_fields if f not in event]
        
        if missing_fields:
            return ValidationResult.failure(
                f"Missing required fields: {', '.join(missing_fields)}",
                {'missing_fields': missing_fields, 'received_fields': list(event.keys())}
            )

        # Validate source - accept any source for flexibility
        # Valid sources include: cloudwatch, api_gateway, manual, test, etc.
        if not event['source']:
            return ValidationResult.failure(
                "Source field cannot be empty",
                {'received_source': event['source']}
            )

        # Validate using Pydantic model
        try:
            incoming_event = IncomingEvent(**event)
        except ValidationError as e:
            return ValidationResult.failure(
                "Event validation failed",
                {'validation_errors': e.errors()}
            )

        # If we get here, basic validation passed
        # Return success (actual normalization happens in normalize_* functions)
        return ValidationResult(valid=True)

    except Exception as e:
        return ValidationResult.failure(
            f"Unexpected validation error: {str(e)}",
            {'exception_type': type(e).__name__}
        )


def validate_incident_event(incident: IncidentEvent) -> ValidationResult:
    """
    Validate a normalized IncidentEvent.
    
    Args:
        incident: IncidentEvent to validate
        
    Returns:
        ValidationResult indicating if incident is valid
    """
    try:
        # Pydantic already validates on construction, but we can add extra checks
        
        # Ensure affected_resources is not empty
        if not incident.affected_resources:
            return ValidationResult.failure(
                "affected_resources must not be empty"
            )

        # Ensure event_type is not empty or whitespace
        if not incident.event_type or not incident.event_type.strip():
            return ValidationResult.failure(
                "event_type must not be empty"
            )

        # All validations passed
        return ValidationResult.success(incident)

    except Exception as e:
        return ValidationResult.failure(
            f"Incident validation error: {str(e)}",
            {'exception_type': type(e).__name__}
        )
