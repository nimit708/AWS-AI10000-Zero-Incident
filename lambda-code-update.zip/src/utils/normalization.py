"""Event normalization utilities"""
from typing import Dict, Any, List, Literal
from datetime import datetime
import uuid
from src.models import IncidentEvent


def normalize_cloudwatch_event(event: Dict[str, Any]) -> IncidentEvent:
    """
    Normalize CloudWatch alarm event to standard IncidentEvent format.
    
    Property 2: Event normalization preserves information
    For any valid event from CloudWatch, normalizing the event should preserve 
    all critical incident information (timestamp, affected resources, event type, 
    severity) in the standard IncidentEvent format.
    
    Args:
        event: Raw CloudWatch event
        
    Returns:
        Normalized IncidentEvent
    """
    raw_payload = event.get('raw_payload', {})
    
    # Extract CloudWatch alarm details
    detail = raw_payload.get('detail', {})
    alarm_name = detail.get('alarmName', 'Unknown Alarm')
    state = detail.get('state', {})
    state_value = state.get('value', 'ALARM')
    
    # Extract metric information
    configuration = detail.get('configuration', {})
    metrics = configuration.get('metrics', [])
    metric_name = 'Unknown'
    if metrics:
        metric_name = metrics[0].get('metricStat', {}).get('metric', {}).get('name', 'Unknown')
    
    # Determine event type from alarm name and metric
    event_type = _determine_cloudwatch_event_type(alarm_name, metric_name, detail)
    
    # Determine severity from state and threshold
    severity = _determine_cloudwatch_severity(state_value, configuration)
    
    # Extract affected resources
    affected_resources = _extract_cloudwatch_resources(detail, configuration)
    
    # Extract metadata
    metadata = {
        'alarm_name': alarm_name,
        'state': state_value,
        'metric_name': metric_name,
        'reason': state.get('reason', ''),
        'timestamp': state.get('timestamp', event.get('timestamp')),
        'configuration': configuration
    }
    
    return IncidentEvent(
        incident_id=str(uuid.uuid4()),
        timestamp=event.get('timestamp', datetime.utcnow().isoformat() + 'Z'),
        source='cloudwatch',
        event_type=event_type,
        severity=severity,
        affected_resources=affected_resources,
        metadata=metadata,
        raw_event=raw_payload
    )


def normalize_api_gateway_event(event: Dict[str, Any]) -> IncidentEvent:
    """
    Normalize API Gateway custom event to standard IncidentEvent format.
    
    Property 2: Event normalization preserves information
    For any valid event from API Gateway, normalizing the event should preserve 
    all critical incident information (timestamp, affected resources, event type, 
    severity) in the standard IncidentEvent format.
    
    Args:
        event: Raw API Gateway event
        
    Returns:
        Normalized IncidentEvent
    """
    raw_payload = event.get('raw_payload', {})
    body = raw_payload.get('body', {})
    
    # If body is a string, it might be JSON
    if isinstance(body, str):
        import json
        try:
            body = json.loads(body)
        except json.JSONDecodeError:
            body = {}
    
    # Extract incident details from body
    event_type = body.get('event_type', body.get('eventType', 'Unknown Incident'))
    severity = body.get('severity', 'medium')
    affected_resources = body.get('affected_resources', body.get('affectedResources', []))
    
    # Ensure affected_resources is a list
    if isinstance(affected_resources, str):
        affected_resources = [affected_resources]
    elif not isinstance(affected_resources, list):
        affected_resources = ['unknown-resource']
    
    # If still empty, add a placeholder
    if not affected_resources:
        affected_resources = ['unknown-resource']
    
    # Validate severity
    valid_severities = ['low', 'medium', 'high', 'critical']
    if severity not in valid_severities:
        severity = 'medium'
    
    # Extract metadata
    metadata = {
        'source_ip': raw_payload.get('requestContext', {}).get('identity', {}).get('sourceIp', 'unknown'),
        'user_agent': raw_payload.get('headers', {}).get('User-Agent', 'unknown'),
        'custom_data': body.get('metadata', {})
    }
    
    # Add any additional fields from body to metadata
    for key, value in body.items():
        if key not in ['event_type', 'eventType', 'severity', 'affected_resources', 'affectedResources', 'metadata']:
            metadata[key] = value
    
    return IncidentEvent(
        incident_id=str(uuid.uuid4()),
        timestamp=event.get('timestamp', datetime.utcnow().isoformat() + 'Z'),
        source='api_gateway',
        event_type=event_type,
        severity=severity,
        affected_resources=affected_resources,
        metadata=metadata,
        raw_event=raw_payload
    )


def _determine_cloudwatch_event_type(
    alarm_name: str, 
    metric_name: str, 
    detail: Dict[str, Any]
) -> str:
    """Determine event type from CloudWatch alarm details"""
    alarm_lower = alarm_name.lower()
    metric_lower = metric_name.lower()
    
    # EC2 CPU/Memory patterns
    if 'cpu' in alarm_lower or 'cpu' in metric_lower:
        return 'EC2 CPU Spike'
    if 'memory' in alarm_lower or 'memory' in metric_lower:
        return 'EC2 Memory Spike'
    
    # Lambda patterns
    if 'lambda' in alarm_lower and ('timeout' in alarm_lower or 'duration' in metric_lower):
        return 'Lambda Timeout'
    if 'lambda' in alarm_lower and 'error' in alarm_lower:
        return 'Lambda Error'
    
    # Certificate patterns
    if 'certificate' in alarm_lower or 'cert' in alarm_lower or 'ssl' in alarm_lower:
        return 'SSL Certificate Error'
    
    # Network patterns
    if 'network' in alarm_lower or 'connection' in alarm_lower or 'timeout' in alarm_lower:
        return 'Network Timeout'
    
    # Deployment patterns
    if 'deploy' in alarm_lower or 'deployment' in alarm_lower:
        return 'Deployment Failure'
    
    # Service health patterns
    if 'health' in alarm_lower or 'unhealthy' in alarm_lower or 'crash' in alarm_lower:
        return 'Service Unhealthy'
    
    # Default
    return f'CloudWatch Alarm: {alarm_name}'


def _determine_cloudwatch_severity(
    state_value: str, 
    configuration: Dict[str, Any]
) -> Literal['low', 'medium', 'high', 'critical']:
    """Determine severity from CloudWatch alarm state and configuration"""
    if state_value != 'ALARM':
        return 'low'
    
    # Check threshold to determine severity
    metrics = configuration.get('metrics', [])
    if metrics:
        metric_stat = metrics[0].get('metricStat', {})
        stat = metric_stat.get('stat', '')
        
        # High percentiles or max stats indicate critical issues
        if 'p99' in stat.lower() or 'max' in stat.lower():
            return 'critical'
        elif 'p95' in stat.lower():
            return 'high'
        elif 'p90' in stat.lower() or 'average' in stat.lower():
            return 'medium'
    
    return 'medium'


def _extract_cloudwatch_resources(
    detail: Dict[str, Any], 
    configuration: Dict[str, Any]
) -> List[str]:
    """Extract affected resources from CloudWatch alarm"""
    resources = []
    
    # Try to get resources from alarm configuration
    metrics = configuration.get('metrics', [])
    for metric in metrics:
        metric_stat = metric.get('metricStat', {})
        metric_info = metric_stat.get('metric', {})
        dimensions = metric_info.get('dimensions', {})
        
        # Extract resource identifiers from dimensions
        if 'InstanceId' in dimensions:
            resources.append(dimensions['InstanceId'])
        if 'FunctionName' in dimensions:
            resources.append(dimensions['FunctionName'])
        if 'LoadBalancer' in dimensions:
            resources.append(dimensions['LoadBalancer'])
        if 'ServiceName' in dimensions:
            resources.append(dimensions['ServiceName'])
    
    # If no resources found, use alarm ARN or name
    if not resources:
        alarm_arn = detail.get('alarmArn', '')
        if alarm_arn:
            resources.append(alarm_arn)
        else:
            resources.append(detail.get('alarmName', 'unknown-resource'))
    
    return resources


def normalize_event(event: Dict[str, Any]) -> IncidentEvent:
    """
    Generic event normalizer that dispatches to appropriate normalizer.
    
    Determines event source and calls the appropriate normalization function.
    
    Args:
        event: Raw event from CloudWatch or API Gateway
        
    Returns:
        Normalized IncidentEvent
        
    Raises:
        ValueError: If event source is unknown
    """
    source = event.get('source', '').lower()
    raw_payload = event.get('raw_payload', {})
    
    # Check if raw_payload has direct incident data (for testing/demo)
    if raw_payload and 'event_type' in raw_payload and 'body' not in raw_payload and 'detail' not in raw_payload:
        # Direct incident format - use as-is
        return IncidentEvent(
            incident_id=raw_payload.get('incident_id', str(uuid.uuid4())),
            timestamp=raw_payload.get('timestamp', event.get('timestamp', datetime.utcnow().isoformat() + 'Z')),
            source=source or 'api_gateway',
            event_type=raw_payload.get('event_type', 'Unknown Incident'),
            severity=raw_payload.get('severity', 'medium'),
            resource_id=raw_payload.get('resource_id', 'unknown-resource'),
            affected_resources=raw_payload.get('affected_resources', []),
            description=raw_payload.get('description', ''),
            metadata=raw_payload.get('metadata', {}),
            raw_event=raw_payload
        )
    
    if 'cloudwatch' in source or source == 'aws.cloudwatch':
        return normalize_cloudwatch_event(event)
    elif 'api' in source or source == 'api_gateway':
        return normalize_api_gateway_event(event)
    else:
        # Try to infer from structure
        if 'detail' in raw_payload and 'alarmName' in raw_payload.get('detail', {}):
            return normalize_cloudwatch_event(event)
        elif 'body' in raw_payload:
            return normalize_api_gateway_event(event)
        else:
            raise ValueError(f"Unknown event source: {source}")
