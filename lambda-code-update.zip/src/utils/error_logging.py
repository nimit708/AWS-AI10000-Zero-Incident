"""Error logging and alerting utilities"""
import logging
import json
from typing import Dict, Any, Optional, List
from datetime import datetime
from enum import Enum

logger = logging.getLogger(__name__)


class ErrorSeverity(Enum):
    """Error severity levels"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ErrorCategory(Enum):
    """Error categories for classification"""
    VALIDATION = "validation"
    NORMALIZATION = "normalization"
    BEDROCK = "bedrock"
    DYNAMODB = "dynamodb"
    SNS = "sns"
    REMEDIATION = "remediation"
    ROUTING = "routing"
    SYSTEM = "system"


def log_error(
    error_category: ErrorCategory,
    error_message: str,
    severity: ErrorSeverity = ErrorSeverity.MEDIUM,
    incident_id: Optional[str] = None,
    context: Optional[Dict[str, Any]] = None,
    exception: Optional[Exception] = None
) -> Dict[str, Any]:
    """
    Log structured error with context.
    
    Property 30: Error logging completeness
    For any error that occurs during incident processing, the system should
    log the error with complete context including incident ID, error type,
    severity, and relevant details.
    
    Args:
        error_category: Category of error
        error_message: Human-readable error message
        severity: Error severity level
        incident_id: Associated incident ID if available
        context: Additional context information
        exception: Exception object if available
        
    Returns:
        Structured error log entry
    """
    error_log = {
        'timestamp': datetime.utcnow().isoformat() + 'Z',
        'error_category': error_category.value,
        'error_message': error_message,
        'severity': severity.value,
        'incident_id': incident_id,
        'context': context or {},
    }
    
    # Add exception details if provided
    if exception:
        error_log['exception'] = {
            'type': type(exception).__name__,
            'message': str(exception),
            'args': exception.args
        }
    
    # Log at appropriate level based on severity
    log_message = json.dumps(error_log)
    
    if severity == ErrorSeverity.CRITICAL:
        logger.critical(log_message)
    elif severity == ErrorSeverity.HIGH:
        logger.error(log_message)
    elif severity == ErrorSeverity.MEDIUM:
        logger.warning(log_message)
    else:
        logger.info(log_message)
    
    return error_log


def log_remediation_failure(
    incident_id: str,
    event_type: str,
    routing_path: str,
    error_message: str,
    actions_attempted: List[str],
    failure_reason: str,
    severity: ErrorSeverity = ErrorSeverity.HIGH
) -> Dict[str, Any]:
    """
    Log remediation failure with detailed context.
    
    Args:
        incident_id: Incident ID
        event_type: Type of incident
        routing_path: Routing path taken
        error_message: Error message
        actions_attempted: List of actions attempted
        failure_reason: Reason for failure
        severity: Error severity
        
    Returns:
        Structured error log entry
    """
    context = {
        'event_type': event_type,
        'routing_path': routing_path,
        'actions_attempted': actions_attempted,
        'failure_reason': failure_reason
    }
    
    return log_error(
        error_category=ErrorCategory.REMEDIATION,
        error_message=f"Remediation failed: {error_message}",
        severity=severity,
        incident_id=incident_id,
        context=context
    )


def log_system_health_degradation(
    service_name: str,
    degradation_type: str,
    impact: str,
    metrics: Optional[Dict[str, Any]] = None,
    severity: ErrorSeverity = ErrorSeverity.HIGH
) -> Dict[str, Any]:
    """
    Log system health degradation.
    
    Property 31: Health degradation alerting
    When system health degrades (e.g., high error rate, service unavailability),
    the system should log the degradation with metrics and impact assessment.
    
    Args:
        service_name: Name of affected service
        degradation_type: Type of degradation
        impact: Impact description
        metrics: Related metrics
        severity: Degradation severity
        
    Returns:
        Structured health degradation log entry
    """
    context = {
        'service_name': service_name,
        'degradation_type': degradation_type,
        'impact': impact,
        'metrics': metrics or {}
    }
    
    return log_error(
        error_category=ErrorCategory.SYSTEM,
        error_message=f"System health degradation detected: {service_name} - {degradation_type}",
        severity=severity,
        context=context
    )


def log_service_unavailable(
    service_name: str,
    operation: str,
    error_details: str,
    fallback_action: Optional[str] = None
) -> Dict[str, Any]:
    """
    Log service unavailability.
    
    Args:
        service_name: Name of unavailable service
        operation: Operation that failed
        error_details: Error details
        fallback_action: Fallback action taken if any
        
    Returns:
        Structured error log entry
    """
    context = {
        'service_name': service_name,
        'operation': operation,
        'error_details': error_details,
        'fallback_action': fallback_action
    }
    
    return log_error(
        error_category=ErrorCategory.SYSTEM,
        error_message=f"Service unavailable: {service_name}",
        severity=ErrorSeverity.HIGH,
        context=context
    )


def log_validation_error(
    incident_id: Optional[str],
    validation_errors: List[str],
    event_source: str
) -> Dict[str, Any]:
    """
    Log validation error.
    
    Args:
        incident_id: Incident ID if available
        validation_errors: List of validation errors
        event_source: Source of the event
        
    Returns:
        Structured error log entry
    """
    context = {
        'validation_errors': validation_errors,
        'event_source': event_source,
        'error_count': len(validation_errors)
    }
    
    return log_error(
        error_category=ErrorCategory.VALIDATION,
        error_message=f"Event validation failed with {len(validation_errors)} error(s)",
        severity=ErrorSeverity.LOW,
        incident_id=incident_id,
        context=context
    )


def log_bedrock_error(
    operation: str,
    error_message: str,
    incident_id: Optional[str] = None,
    fallback_used: bool = False
) -> Dict[str, Any]:
    """
    Log Bedrock service error.
    
    Args:
        operation: Bedrock operation attempted
        error_message: Error message
        incident_id: Associated incident ID
        fallback_used: Whether fallback was used
        
    Returns:
        Structured error log entry
    """
    context = {
        'operation': operation,
        'fallback_used': fallback_used
    }
    
    return log_error(
        error_category=ErrorCategory.BEDROCK,
        error_message=f"Bedrock error during {operation}: {error_message}",
        severity=ErrorSeverity.MEDIUM if fallback_used else ErrorSeverity.HIGH,
        incident_id=incident_id,
        context=context
    )


def log_database_error(
    operation: str,
    table_name: str,
    error_message: str,
    incident_id: Optional[str] = None,
    retry_attempted: bool = False
) -> Dict[str, Any]:
    """
    Log database error.
    
    Args:
        operation: Database operation attempted
        table_name: Table name
        error_message: Error message
        incident_id: Associated incident ID
        retry_attempted: Whether retry was attempted
        
    Returns:
        Structured error log entry
    """
    context = {
        'operation': operation,
        'table_name': table_name,
        'retry_attempted': retry_attempted
    }
    
    return log_error(
        error_category=ErrorCategory.DYNAMODB,
        error_message=f"Database error during {operation} on {table_name}: {error_message}",
        severity=ErrorSeverity.MEDIUM,
        incident_id=incident_id,
        context=context
    )


def log_notification_error(
    notification_type: str,
    error_message: str,
    incident_id: Optional[str] = None,
    recipient: Optional[str] = None
) -> Dict[str, Any]:
    """
    Log notification error.
    
    Args:
        notification_type: Type of notification (summary, urgent)
        error_message: Error message
        incident_id: Associated incident ID
        recipient: Notification recipient
        
    Returns:
        Structured error log entry
    """
    context = {
        'notification_type': notification_type,
        'recipient': recipient
    }
    
    return log_error(
        error_category=ErrorCategory.SNS,
        error_message=f"Notification error ({notification_type}): {error_message}",
        severity=ErrorSeverity.LOW,
        incident_id=incident_id,
        context=context
    )


class HealthMonitor:
    """
    Monitor system health and detect degradation.
    
    Tracks error rates and service availability to detect
    when system health is degrading.
    """

    def __init__(
        self,
        error_rate_threshold: float = 0.1,  # 10% error rate
        window_size: int = 100  # Last 100 operations
    ):
        """
        Initialize health monitor.
        
        Args:
            error_rate_threshold: Threshold for error rate alerting
            window_size: Number of operations to track
        """
        self.error_rate_threshold = error_rate_threshold
        self.window_size = window_size
        self.operation_results: Dict[str, List[bool]] = {}
        self.service_availability: Dict[str, bool] = {}

    def record_operation(
        self,
        operation_name: str,
        success: bool
    ):
        """
        Record operation result.
        
        Args:
            operation_name: Name of operation
            success: Whether operation succeeded
        """
        if operation_name not in self.operation_results:
            self.operation_results[operation_name] = []
        
        results = self.operation_results[operation_name]
        results.append(success)
        
        # Keep only last window_size results
        if len(results) > self.window_size:
            results.pop(0)

    def get_error_rate(self, operation_name: str) -> float:
        """
        Get error rate for operation.
        
        Args:
            operation_name: Name of operation
            
        Returns:
            Error rate (0.0 to 1.0)
        """
        if operation_name not in self.operation_results:
            return 0.0
        
        results = self.operation_results[operation_name]
        if not results:
            return 0.0
        
        failures = sum(1 for r in results if not r)
        return failures / len(results)

    def check_health_degradation(
        self,
        operation_name: str
    ) -> Optional[Dict[str, Any]]:
        """
        Check if operation shows health degradation.
        
        Property 31: Health degradation alerting
        Detects when error rate exceeds threshold and logs degradation.
        
        Args:
            operation_name: Name of operation to check
            
        Returns:
            Health degradation log entry if degraded, None otherwise
        """
        error_rate = self.get_error_rate(operation_name)
        
        if error_rate > self.error_rate_threshold:
            metrics = {
                'error_rate': error_rate,
                'threshold': self.error_rate_threshold,
                'sample_size': len(self.operation_results.get(operation_name, []))
            }
            
            return log_system_health_degradation(
                service_name=operation_name,
                degradation_type='high_error_rate',
                impact=f"Error rate {error_rate:.1%} exceeds threshold {self.error_rate_threshold:.1%}",
                metrics=metrics,
                severity=ErrorSeverity.HIGH
            )
        
        return None

    def record_service_availability(
        self,
        service_name: str,
        available: bool
    ):
        """
        Record service availability.
        
        Args:
            service_name: Name of service
            available: Whether service is available
        """
        was_available = self.service_availability.get(service_name, True)
        self.service_availability[service_name] = available
        
        # Log if service became unavailable
        if was_available and not available:
            log_service_unavailable(
                service_name=service_name,
                operation='availability_check',
                error_details='Service became unavailable'
            )

    def is_service_available(self, service_name: str) -> bool:
        """
        Check if service is available.
        
        Args:
            service_name: Name of service
            
        Returns:
            True if service is available
        """
        return self.service_availability.get(service_name, True)

    def get_health_summary(self) -> Dict[str, Any]:
        """
        Get overall health summary.
        
        Returns:
            Health summary with error rates and service availability
        """
        return {
            'timestamp': datetime.utcnow().isoformat() + 'Z',
            'error_rates': {
                op: self.get_error_rate(op)
                for op in self.operation_results.keys()
            },
            'service_availability': self.service_availability.copy(),
            'degraded_operations': [
                op for op in self.operation_results.keys()
                if self.get_error_rate(op) > self.error_rate_threshold
            ]
        }
