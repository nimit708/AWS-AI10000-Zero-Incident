"""SNS service for incident notifications"""
import json
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime
import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


class SNSService:
    """
    Service for SNS notification operations.
    
    Sends summary notifications for successful remediations and urgent alerts
    for failures or unknown incidents.
    """

    def __init__(
        self,
        summary_topic_arn: str,
        urgent_topic_arn: str,
        region_name: str = 'us-east-1',
        max_retries: int = 3,
        summary_model: Optional[str] = None
    ):
        """
        Initialize SNS service.
        
        Args:
            summary_topic_arn: ARN for summary notification topic
            urgent_topic_arn: ARN for urgent alert topic
            region_name: AWS region
            max_retries: Maximum number of retry attempts
            summary_model: Bedrock model ID for generating summaries
        """
        self.summary_topic_arn = summary_topic_arn
        self.urgent_topic_arn = urgent_topic_arn
        self.max_retries = max_retries
        self.summary_model = summary_model
        self.region_name = region_name
        
        self.sns_client = boto3.client('sns', region_name=region_name)
        self.bedrock_client = boto3.client('bedrock-runtime', region_name=region_name) if summary_model else None

    def send_summary_notification(
        self,
        incident_id: str,
        event_type: str,
        severity: str,
        remediation_summary: str,
        actions_taken: List[str],
        affected_resources: Optional[List[str]] = None,
        resolution_time: Optional[int] = None
    ) -> bool:
        """
        Send summary notification for successful auto-remediation.
        
        Uses Bedrock to generate human-readable summary if available.
        
        Args:
            incident_id: Incident ID
            event_type: Type of incident
            severity: Incident severity
            remediation_summary: Brief remediation summary
            actions_taken: List of actions performed
            affected_resources: List of affected resources
            resolution_time: Time to resolve in seconds
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Generate human-readable summary using Bedrock
            if self.bedrock_client and self.summary_model:
                human_summary = self._generate_bedrock_summary(
                    incident_id=incident_id,
                    event_type=event_type,
                    severity=severity,
                    actions_taken=actions_taken,
                    affected_resources=affected_resources or []
                )
            else:
                # Fallback to simple summary
                human_summary = self._generate_simple_summary(
                    event_type=event_type,
                    actions_taken=actions_taken,
                    affected_resources=affected_resources or []
                )
            
            # Create message
            message = {
                "incidentId": incident_id,
                "eventType": event_type,
                "severity": severity,
                "affectedResources": affected_resources or [],
                "actionsPerformed": actions_taken,
                "resolutionTime": f"{resolution_time} seconds" if resolution_time else "N/A",
                "summary": human_summary,
                "timestamp": datetime.utcnow().isoformat() + 'Z'
            }
            
            subject = f"✅ Remediation Successfully Done: {event_type}"
            
            return self._publish_with_retry(
                topic_arn=self.summary_topic_arn,
                subject=subject,
                message=message,
                incident_id=incident_id
            )
            
        except Exception as e:
            logger.error(f"Error sending summary notification for {incident_id}: {e}")
            return False

    def _generate_bedrock_summary(
        self,
        incident_id: str,
        event_type: str,
        severity: str,
        actions_taken: List[str],
        affected_resources: List[str]
    ) -> str:
        """
        Generate human-readable summary using Bedrock.
        
        Args:
            incident_id: Incident ID
            event_type: Event type
            severity: Severity level
            actions_taken: Actions performed
            affected_resources: Affected resources
            
        Returns:
            Human-readable summary
        """
        try:
            # Create prompt for Bedrock
            prompt = f"""Generate a concise, professional incident resolution summary for the following:

Incident Type: {event_type}
Severity: {severity}
Affected Resources: {', '.join(affected_resources) if affected_resources else 'N/A'}
Actions Taken:
{chr(10).join(f'- {action}' for action in actions_taken)}

Write a 2-3 sentence summary explaining what happened and how it was resolved. Use clear, non-technical language suitable for stakeholders."""

            # Call Bedrock
            request_body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 200,
                "messages": [
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                "temperature": 0.3
            }
            
            response = self.bedrock_client.invoke_model(
                modelId=self.summary_model,
                body=json.dumps(request_body)
            )
            
            response_body = json.loads(response['body'].read())
            summary = response_body['content'][0]['text'].strip()
            
            logger.info(f"Generated Bedrock summary for incident {incident_id}")
            return summary
            
        except Exception as e:
            logger.warning(f"Failed to generate Bedrock summary: {e}, using fallback")
            return self._generate_simple_summary(event_type, actions_taken, affected_resources)

    def _generate_simple_summary(
        self,
        event_type: str,
        actions_taken: List[str],
        affected_resources: List[str]
    ) -> str:
        """
        Generate simple summary without Bedrock.
        
        Args:
            event_type: Event type
            actions_taken: Actions performed
            affected_resources: Affected resources
            
        Returns:
            Simple summary
        """
        resource_str = f" affecting {len(affected_resources)} resource(s)" if affected_resources else ""
        action_count = len(actions_taken)
        
        return (
            f"Successfully resolved {event_type} incident{resource_str}. "
            f"Performed {action_count} remediation action(s) to restore normal operation. "
            f"System is now operating normally."
        )

    def _generate_bedrock_failure_summary(
        self,
        incident_id: str,
        event_type: str,
        severity: str,
        reason: str,
        affected_resources: List[str],
        recommended_actions: List[str],
        incident_details: Dict[str, Any]
    ) -> str:
        """
        Generate human-readable failure summary using Bedrock.
        
        Args:
            incident_id: Incident ID
            event_type: Event type
            severity: Severity level
            reason: Failure reason
            affected_resources: Affected resources
            recommended_actions: Recommended actions
            incident_details: Additional details
            
        Returns:
            Human-readable failure summary
        """
        try:
            # Create prompt for Bedrock
            error_msg = incident_details.get('error_message', incident_details.get('error', 'Unknown error'))
            
            prompt = f"""Generate a concise, professional incident alert summary for the following failure:

Incident Type: {event_type}
Severity: {severity}
Failure Reason: {reason}
Affected Resources: {', '.join(affected_resources) if affected_resources else 'N/A'}
Error Details: {error_msg}
Recommended Actions:
{chr(10).join(f'- {action}' for action in recommended_actions)}

Write a 2-3 sentence summary explaining what went wrong and what needs to be done. Use clear, urgent language suitable for on-call engineers."""

            # Call Bedrock
            request_body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 200,
                "messages": [
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                "temperature": 0.3
            }
            
            response = self.bedrock_client.invoke_model(
                modelId=self.summary_model,
                body=json.dumps(request_body)
            )
            
            response_body = json.loads(response['body'].read())
            summary = response_body['content'][0]['text'].strip()
            
            logger.info(f"Generated Bedrock failure summary for incident {incident_id}")
            return summary
            
        except Exception as e:
            logger.warning(f"Failed to generate Bedrock failure summary: {e}, using fallback")
            return self._generate_simple_failure_summary(event_type, reason, affected_resources)

    def _generate_simple_failure_summary(
        self,
        event_type: str,
        reason: str,
        affected_resources: List[str]
    ) -> str:
        """
        Generate simple failure summary without Bedrock.
        
        Args:
            event_type: Event type
            reason: Failure reason
            affected_resources: Affected resources
            
        Returns:
            Simple failure summary
        """
        resource_str = f" affecting {len(affected_resources)} resource(s)" if affected_resources else ""
        
        return (
            f"URGENT: {event_type} incident{resource_str} requires immediate attention. "
            f"Reason: {reason}. "
            f"Manual intervention required to resolve this issue."
        )

    def send_urgent_alert(
        self,
        incident_id: str,
        event_type: str,
        reason: str,
        affected_resources: List[str],
        recommended_actions: List[str],
        incident_details: Optional[Dict[str, Any]] = None,
        severity: str = 'high'
    ) -> bool:
        """
        Send urgent alert for failures or unknown incidents.
        
        Uses Bedrock to generate human-readable summary if available.
        
        Property 24: Urgent alarm format
        For any failed remediation or unclassified incident, the SNS urgent alarm 
        should contain all required fields: incidentId, eventType, reason for 
        escalation, affectedResources, and recommended next steps.
        
        Args:
            incident_id: Incident ID
            event_type: Type of incident
            reason: Reason for escalation
            affected_resources: List of affected resources
            recommended_actions: List of recommended next steps
            incident_details: Optional additional details
            severity: Incident severity
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Validate required fields
            if not all([incident_id, event_type, reason, affected_resources, recommended_actions]):
                logger.error("Missing required fields for urgent alert")
                return False
            
            # Generate human-readable summary using Bedrock
            if self.bedrock_client and self.summary_model:
                human_summary = self._generate_bedrock_failure_summary(
                    incident_id=incident_id,
                    event_type=event_type,
                    severity=severity,
                    reason=reason,
                    affected_resources=affected_resources,
                    recommended_actions=recommended_actions,
                    incident_details=incident_details or {}
                )
            else:
                # Fallback to simple summary
                human_summary = self._generate_simple_failure_summary(
                    event_type=event_type,
                    reason=reason,
                    affected_resources=affected_resources
                )
            
            # Create message
            message = {
                "incidentId": incident_id,
                "eventType": event_type,
                "reason": reason,
                "affectedResources": affected_resources,
                "recommendedActions": recommended_actions,
                "summary": human_summary,
                "timestamp": datetime.utcnow().isoformat() + 'Z'
            }
            
            if incident_details:
                message["incidentDetails"] = incident_details
            
            subject = f"URGENT: Incident Requires Attention - {event_type}"
            
            return self._publish_with_retry(
                topic_arn=self.urgent_topic_arn,
                subject=subject,
                message=message,
                incident_id=incident_id
            )
            
        except Exception as e:
            logger.error(f"Error sending urgent alert for {incident_id}: {e}")
            return False

    def _publish_with_retry(
        self,
        topic_arn: str,
        subject: str,
        message: Dict[str, Any],
        incident_id: str
    ) -> bool:
        """
        Publish message to SNS with retry logic.
        
        Args:
            topic_arn: SNS topic ARN
            subject: Message subject
            message: Message body (will be JSON serialized)
            incident_id: Incident ID for logging
            
        Returns:
            True if successful, False otherwise
        """
        message_json = json.dumps(message, indent=2)
        
        for attempt in range(self.max_retries):
            try:
                response = self.sns_client.publish(
                    TopicArn=topic_arn,
                    Subject=subject,
                    Message=message_json,
                    MessageAttributes={
                        'incident_id': {
                            'DataType': 'String',
                            'StringValue': incident_id
                        },
                        'event_type': {
                            'DataType': 'String',
                            'StringValue': message.get('eventType', 'Unknown')
                        }
                    }
                )
                
                message_id = response.get('MessageId')
                logger.info(
                    f"Published notification for incident {incident_id} "
                    f"to {topic_arn} (MessageId: {message_id})"
                )
                return True
                
            except ClientError as e:
                error_code = e.response['Error']['Code']
                
                if attempt < self.max_retries - 1:
                    logger.warning(
                        f"SNS publish failed for incident {incident_id} "
                        f"(attempt {attempt + 1}/{self.max_retries}): {error_code}"
                    )
                    continue
                else:
                    logger.error(
                        f"SNS publish failed after {self.max_retries} retries "
                        f"for incident {incident_id}: {e}"
                    )
                    return False
                    
            except Exception as e:
                logger.error(f"Unexpected error publishing to SNS for {incident_id}: {e}")
                return False
        
        return False

    def send_test_notification(self, topic_type: str = 'summary') -> bool:
        """
        Send a test notification to verify SNS configuration.
        
        Args:
            topic_type: 'summary' or 'urgent'
            
        Returns:
            True if successful, False otherwise
        """
        try:
            if topic_type == 'summary':
                return self.send_summary_notification(
                    incident_id='test-incident-000',
                    event_type='Test Notification',
                    affected_resources=['test-resource'],
                    actions_performed=['Sent test notification'],
                    resolution_time=0,
                    summary='This is a test notification to verify SNS configuration.'
                )
            else:
                return self.send_urgent_alert(
                    incident_id='test-incident-000',
                    event_type='Test Alert',
                    reason='Testing urgent alert configuration',
                    affected_resources=['test-resource'],
                    recommended_actions=['Verify alert received', 'Check email/SMS'],
                    incident_details={'test': True}
                )
                
        except Exception as e:
            logger.error(f"Error sending test notification: {e}")
            return False

    def format_summary_from_remediation(
        self,
        incident_id: str,
        event_type: str,
        affected_resources: List[str],
        actions: List[str],
        resolution_time: int,
        technical_summary: str
    ) -> Dict[str, Any]:
        """
        Format a summary notification message from remediation result.
        
        Helper method to create properly formatted summary notifications.
        
        Args:
            incident_id: Incident ID
            event_type: Event type
            affected_resources: Affected resources
            actions: Actions performed
            resolution_time: Resolution time in seconds
            technical_summary: Technical summary text
            
        Returns:
            Formatted message dictionary
        """
        return {
            "incidentId": incident_id,
            "eventType": event_type,
            "affectedResources": affected_resources,
            "actionsPerformed": actions,
            "resolutionTime": f"{resolution_time} seconds",
            "summary": technical_summary,
            "timestamp": datetime.utcnow().isoformat() + 'Z'
        }

    def format_urgent_alert_from_failure(
        self,
        incident_id: str,
        event_type: str,
        affected_resources: List[str],
        failure_reason: str,
        error_message: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Format an urgent alert message from remediation failure.
        
        Helper method to create properly formatted urgent alerts.
        
        Args:
            incident_id: Incident ID
            event_type: Event type
            affected_resources: Affected resources
            failure_reason: Reason for failure
            error_message: Optional error message
            
        Returns:
            Formatted message dictionary
        """
        recommended_actions = [
            "Review incident details in DynamoDB",
            "Check CloudWatch logs for error details",
            "Manually investigate affected resources",
            "Consider manual remediation"
        ]
        
        incident_details = {
            "timestamp": datetime.utcnow().isoformat() + 'Z',
            "failure_reason": failure_reason
        }
        
        if error_message:
            incident_details["error_message"] = error_message
        
        return {
            "incidentId": incident_id,
            "eventType": event_type,
            "reason": failure_reason,
            "affectedResources": affected_resources,
            "recommendedActions": recommended_actions,
            "incidentDetails": incident_details
        }
