"""Knowledge Base service for incident storage and semantic search"""
import json
import logging
from typing import List, Optional, Dict, Any
from datetime import datetime
import boto3
from botocore.exceptions import ClientError
from src.models import HistoricalIncident, IncidentDocument

logger = logging.getLogger(__name__)


class KnowledgeBaseService:
    """
    Service for Knowledge Base operations using S3 and Bedrock.
    
    Stores incident documents in S3 with versioning and generates embeddings
    for semantic search using Bedrock.
    """

    def __init__(
        self,
        bucket_name: str,
        embedding_model: str = 'amazon.titan-embed-text-v2:0',
        region_name: str = 'us-east-1'
    ):
        """
        Initialize Knowledge Base service.
        
        Args:
            bucket_name: S3 bucket name for document storage
            embedding_model: Bedrock model ID for embeddings
            region_name: AWS region
        """
        self.bucket_name = bucket_name
        self.embedding_model = embedding_model
        self.region_name = region_name
        
        self.s3_client = boto3.client('s3', region_name=region_name)
        self.bedrock_runtime = boto3.client('bedrock-runtime', region_name=region_name)

    def store_incident_document(
        self,
        incident: HistoricalIncident
    ) -> bool:
        """
        Store incident document in S3 with versioning.
        
        Property 16: Incident storage completeness
        For any successfully remediated incident, storing it in the Knowledge Base 
        should preserve all essential information: incident details, resolution steps, 
        outcome, and timestamp.
        
        Args:
            incident: HistoricalIncident to store
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Generate S3 key with year/month structure
            timestamp = datetime.fromisoformat(incident.timestamp.replace('Z', '+00:00'))
            s3_key = f"incidents/{timestamp.year}/{timestamp.month:02d}/{incident.incident_id}.json"
            
            # Convert incident to JSON
            incident_dict = incident.model_dump()
            incident_json = json.dumps(incident_dict, indent=2)
            
            # Upload to S3
            self.s3_client.put_object(
                Bucket=self.bucket_name,
                Key=s3_key,
                Body=incident_json,
                ContentType='application/json',
                Metadata={
                    'incident_id': incident.incident_id,
                    'event_type': incident.event_type,
                    'severity': incident.severity,
                    'outcome': incident.outcome
                }
            )
            
            logger.info(f"Stored incident {incident.incident_id} in S3: {s3_key}")
            return True
            
        except ClientError as e:
            logger.error(f"Error storing incident {incident.incident_id} in S3: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error storing incident {incident.incident_id}: {e}")
            return False

    def generate_embedding(self, text: str) -> Optional[List[float]]:
        """
        Generate vector embedding using Bedrock.
        
        Property 17: Embedding generation consistency
        For any incident stored in the Knowledge Base, the system should generate 
        a vector embedding using Bedrock Service, and the embedding should have 
        the expected dimensionality (1024 dimensions for Titan Embeddings V2).
        
        Args:
            text: Text to generate embedding for
            
        Returns:
            List of floats representing the embedding, or None on error
        """
        try:
            # Prepare request body for Titan Embeddings V2
            request_body = json.dumps({
                "inputText": text
            })
            
            # Invoke Bedrock model
            response = self.bedrock_runtime.invoke_model(
                modelId=self.embedding_model,
                body=request_body,
                contentType='application/json',
                accept='application/json'
            )
            
            # Parse response
            response_body = json.loads(response['body'].read())
            embedding = response_body.get('embedding', [])
            
            # Validate embedding dimensions (Titan V2 = 1024 dimensions)
            expected_dimensions = 1024
            if len(embedding) != expected_dimensions:
                logger.warning(
                    f"Unexpected embedding dimensions: {len(embedding)} "
                    f"(expected {expected_dimensions})"
                )
            
            return embedding
            
        except ClientError as e:
            logger.error(f"Error generating embedding with Bedrock: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error generating embedding: {e}")
            return None

    def store_embedding(
        self,
        incident_id: str,
        embedding: List[float]
    ) -> bool:
        """
        Store embedding in vector database (simplified - stores in S3 for now).
        
        In production, this would store in a vector database like OpenSearch
        or use Bedrock Knowledge Base native vector store.
        
        Args:
            incident_id: Incident ID
            embedding: Vector embedding
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # For now, store embedding as separate JSON file in S3
            # In production, use proper vector database
            s3_key = f"embeddings/{incident_id}.json"
            
            embedding_data = {
                'incident_id': incident_id,
                'embedding': embedding,
                'dimensions': len(embedding),
                'model': self.embedding_model,
                'created_at': datetime.utcnow().isoformat() + 'Z'
            }
            
            self.s3_client.put_object(
                Bucket=self.bucket_name,
                Key=s3_key,
                Body=json.dumps(embedding_data),
                ContentType='application/json'
            )
            
            logger.info(f"Stored embedding for incident {incident_id}")
            return True
            
        except ClientError as e:
            logger.error(f"Error storing embedding for {incident_id}: {e}")
            return False

    def query_knowledge_base(
        self,
        query_text: str,
        top_k: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Query Knowledge Base using semantic search.
        
        This is a simplified implementation. In production, use:
        - Bedrock Knowledge Base native search
        - OpenSearch k-NN search
        - Vector database with similarity search
        
        Args:
            query_text: Query text
            top_k: Number of results to return
            
        Returns:
            List of matching incidents with similarity scores
        """
        try:
            # Generate embedding for query
            query_embedding = self.generate_embedding(query_text)
            if not query_embedding:
                return []
            
            # In production, perform vector similarity search
            # For now, return empty list (would need vector DB integration)
            logger.info(f"Query embedding generated with {len(query_embedding)} dimensions")
            
            # TODO: Implement actual vector similarity search
            # This would involve:
            # 1. Query vector database with query_embedding
            # 2. Calculate cosine similarity scores
            # 3. Return top_k results sorted by similarity
            
            return []
            
        except Exception as e:
            logger.error(f"Error querying knowledge base: {e}")
            return []

    def get_incident(self, incident_id: str) -> Optional[HistoricalIncident]:
        """
        Retrieve incident document from S3.
        
        Args:
            incident_id: Incident ID
            
        Returns:
            HistoricalIncident if found, None otherwise
        """
        try:
            # List objects to find the incident (since we don't know year/month)
            response = self.s3_client.list_objects_v2(
                Bucket=self.bucket_name,
                Prefix='incidents/'
            )
            
            # Find matching incident
            for obj in response.get('Contents', []):
                if incident_id in obj['Key']:
                    # Get the object
                    obj_response = self.s3_client.get_object(
                        Bucket=self.bucket_name,
                        Key=obj['Key']
                    )
                    
                    # Parse JSON
                    incident_data = json.loads(obj_response['Body'].read())
                    return HistoricalIncident(**incident_data)
            
            return None
            
        except ClientError as e:
            logger.error(f"Error retrieving incident {incident_id}: {e}")
            return None

    def get_incident_versions(self, incident_id: str) -> List[Dict[str, Any]]:
        """
        Get all versions of an incident document.
        
        Property 18: Version history preservation
        For any incident added to the Knowledge Base, if a previous version exists, 
        the S3 versioning should preserve the previous version and the new version 
        should be retrievable independently.
        
        Args:
            incident_id: Incident ID
            
        Returns:
            List of version metadata
        """
        try:
            # Find the incident key
            response = self.s3_client.list_objects_v2(
                Bucket=self.bucket_name,
                Prefix='incidents/'
            )
            
            incident_key = None
            for obj in response.get('Contents', []):
                if incident_id in obj['Key']:
                    incident_key = obj['Key']
                    break
            
            if not incident_key:
                return []
            
            # List versions
            versions_response = self.s3_client.list_object_versions(
                Bucket=self.bucket_name,
                Prefix=incident_key
            )
            
            versions = []
            for version in versions_response.get('Versions', []):
                versions.append({
                    'version_id': version['VersionId'],
                    'last_modified': version['LastModified'].isoformat(),
                    'size': version['Size'],
                    'is_latest': version.get('IsLatest', False)
                })
            
            return versions
            
        except ClientError as e:
            logger.error(f"Error retrieving versions for {incident_id}: {e}")
            return []

    def create_incident_document(
        self,
        incident: HistoricalIncident
    ) -> Optional[IncidentDocument]:
        """
        Create complete incident document with embedding.
        
        Args:
            incident: HistoricalIncident
            
        Returns:
            IncidentDocument with embedding, or None on error
        """
        try:
            # Generate text for embedding
            embedding_text = self._create_embedding_text(incident)
            
            # Generate embedding
            embedding = self.generate_embedding(embedding_text)
            if not embedding:
                logger.error(f"Failed to generate embedding for {incident.incident_id}")
                return None
            
            # Create document
            document = IncidentDocument.from_historical_incident(incident, embedding)
            
            return document
            
        except Exception as e:
            logger.error(f"Error creating incident document: {e}")
            return None

    def _create_embedding_text(self, incident: HistoricalIncident) -> str:
        """
        Create text representation for embedding generation.
        
        Combines incident details into a single text for semantic search.
        """
        parts = [
            f"Event Type: {incident.event_type}",
            f"Severity: {incident.severity}",
            f"Symptoms: {', '.join(incident.symptoms)}",
            f"Root Cause: {incident.root_cause}",
            f"Affected Resources: {', '.join(incident.affected_resources)}",
            f"Resolution Steps: {'; '.join([step.description for step in incident.resolution_steps])}",
            f"Outcome: {incident.outcome}"
        ]
        
        return " | ".join(parts)
