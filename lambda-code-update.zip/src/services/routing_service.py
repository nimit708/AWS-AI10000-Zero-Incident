"""Incident routing service for confidence-based path selection"""
import logging
from typing import Literal, Optional
from src.models import IncidentEvent, AgentResponse, RemediationResult

logger = logging.getLogger(__name__)

# Type aliases for routing paths
RoutingPath = Literal['fast_path', 'structured_path', 'escalation']


class RoutingService:
    """
    Service for routing incidents based on confidence scores and remediation results.
    
    Implements confidence-based routing logic to determine whether incidents
    should be handled via fast path (AI Agent) or structured path (Step Functions).
    """

    def __init__(self, confidence_threshold: float = 0.85):
        """
        Initialize routing service.
        
        Args:
            confidence_threshold: Minimum confidence for fast path routing
        """
        self.confidence_threshold = confidence_threshold

    def route_incident(
        self,
        incident: IncidentEvent,
        agent_response: AgentResponse
    ) -> RoutingPath:
        """
        Route incident based on AI Agent confidence score.
        
        Property 7: Confidence-based routing consistency
        For any incident with AI Agent confidence >= threshold (0.85), the system 
        should route to fast path. For confidence < threshold or no match, route 
        to structured path.
        
        Args:
            incident: IncidentEvent to route
            agent_response: AgentResponse from Bedrock AI Agent
            
        Returns:
            RoutingPath: 'fast_path' or 'structured_path'
        """
        # Check if match found and confidence meets threshold
        if agent_response.match_found and agent_response.confidence >= self.confidence_threshold:
            logger.info(
                f"Routing incident {incident.incident_id} to fast path "
                f"(confidence: {agent_response.confidence:.2f})"
            )
            return 'fast_path'
        else:
            logger.info(
                f"Routing incident {incident.incident_id} to structured path "
                f"(confidence: {agent_response.confidence:.2f}, match_found: {agent_response.match_found})"
            )
            return 'structured_path'

    def should_escalate(
        self,
        incident: IncidentEvent,
        remediation_result: RemediationResult,
        retry_count: int = 0,
        max_retries: int = 1
    ) -> bool:
        """
        Determine if failed remediation should be escalated.
        
        Property 8: Failed remediation escalation
        For any incident where fast path remediation fails, the system should 
        route to structured path for retry. If structured path also fails, 
        escalate to human operators.
        
        Args:
            incident: IncidentEvent
            remediation_result: Result of remediation attempt
            retry_count: Number of retry attempts so far
            max_retries: Maximum number of retries before escalation
            
        Returns:
            True if should escalate, False if should retry
        """
        if remediation_result.success:
            # Successful remediation, no escalation needed
            return False
        
        if retry_count >= max_retries:
            # Exhausted retries, escalate
            logger.warning(
                f"Escalating incident {incident.incident_id} after {retry_count} failed attempts"
            )
            return True
        
        # Still have retries available
        logger.info(
            f"Incident {incident.incident_id} remediation failed, "
            f"retry {retry_count + 1}/{max_retries}"
        )
        return False

    def route_after_failure(
        self,
        incident: IncidentEvent,
        failed_path: RoutingPath,
        retry_count: int = 0
    ) -> RoutingPath:
        """
        Route incident after remediation failure.
        
        Property 8: Failed remediation escalation
        Fast path failure → Structured path
        Structured path failure → Escalation
        
        Args:
            incident: IncidentEvent
            failed_path: Path that failed ('fast_path' or 'structured_path')
            retry_count: Number of previous attempts
            
        Returns:
            Next routing path
        """
        if failed_path == 'fast_path':
            # Fast path failed, try structured path
            logger.info(
                f"Fast path failed for incident {incident.incident_id}, "
                "routing to structured path"
            )
            return 'structured_path'
        
        elif failed_path == 'structured_path':
            # Structured path failed, escalate
            logger.warning(
                f"Structured path failed for incident {incident.incident_id}, "
                "escalating to human operators"
            )
            return 'escalation'
        
        else:
            # Already escalated, no further routing
            logger.error(
                f"Incident {incident.incident_id} already escalated, "
                "no further routing available"
            )
            return 'escalation'

    def is_high_confidence(self, confidence: float) -> bool:
        """
        Check if confidence score meets threshold for fast path.
        
        Property 7: Confidence-based routing consistency
        
        Args:
            confidence: Confidence score (0.0 to 1.0)
            
        Returns:
            True if confidence >= threshold
        """
        return confidence >= self.confidence_threshold

    def get_routing_reason(
        self,
        agent_response: AgentResponse
    ) -> str:
        """
        Get human-readable reason for routing decision.
        
        Args:
            agent_response: AgentResponse from Bedrock
            
        Returns:
            Reason string
        """
        if not agent_response.match_found:
            return "No similar incident found in knowledge base"
        
        if agent_response.confidence < self.confidence_threshold:
            return (
                f"Low confidence match ({agent_response.confidence:.2f} < "
                f"{self.confidence_threshold})"
            )
        
        return (
            f"High confidence match ({agent_response.confidence:.2f} >= "
            f"{self.confidence_threshold})"
        )

    def determine_escalation_priority(
        self,
        incident: IncidentEvent,
        failure_count: int
    ) -> Literal['low', 'medium', 'high', 'critical']:
        """
        Determine escalation priority based on incident severity and failure count.
        
        Args:
            incident: IncidentEvent
            failure_count: Number of failed remediation attempts
            
        Returns:
            Priority level
        """
        # Base priority on incident severity
        severity_priority = {
            'low': 'low',
            'medium': 'medium',
            'high': 'high',
            'critical': 'critical'
        }
        
        base_priority = severity_priority.get(incident.severity, 'medium')
        
        # Escalate priority if multiple failures
        if failure_count >= 2:
            if base_priority == 'low':
                return 'medium'
            elif base_priority == 'medium':
                return 'high'
            else:
                return 'critical'
        
        return base_priority  # type: ignore

    def should_retry_with_structured_path(
        self,
        incident: IncidentEvent,
        fast_path_result: RemediationResult
    ) -> bool:
        """
        Determine if failed fast path should retry with structured path.
        
        Property 8: Failed remediation escalation
        
        Args:
            incident: IncidentEvent
            fast_path_result: Result from fast path attempt
            
        Returns:
            True if should retry with structured path
        """
        if fast_path_result.success:
            return False
        
        # Always retry fast path failures with structured path
        logger.info(
            f"Fast path failed for incident {incident.incident_id}, "
            "will retry with structured path"
        )
        return True

    def get_escalation_metadata(
        self,
        incident: IncidentEvent,
        failure_history: list[RemediationResult]
    ) -> dict:
        """
        Generate metadata for escalation notifications.
        
        Args:
            incident: IncidentEvent
            failure_history: List of failed remediation attempts
            
        Returns:
            Metadata dictionary
        """
        return {
            'incident_id': incident.incident_id,
            'event_type': incident.event_type,
            'severity': incident.severity,
            'affected_resources': incident.affected_resources,
            'failure_count': len(failure_history),
            'last_error': failure_history[-1].error_message if failure_history else None,
            'escalation_priority': self.determine_escalation_priority(
                incident, 
                len(failure_history)
            )
        }
