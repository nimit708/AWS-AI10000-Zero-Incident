"""CloudWatch metrics service for system observability"""
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime
import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


class MetricsService:
    """
    Service for emitting CloudWatch metrics.
    
    Provides observability into system operations including:
    - Incident ingestion rates
    - Remediation success/failure rates
    - Processing latency
    - Service availability
    - Escalation rates
    """

    def __init__(
        self,
        namespace: str = 'IncidentManagement',
        region_name: str = 'us-east-1'
    ):
        """
        Initialize metrics service.
        
        Args:
            namespace: CloudWatch namespace for metrics
            region_name: AWS region
        """
        self.namespace = namespace
        self.region_name = region_name
        self.cloudwatch = boto3.client('cloudwatch', region_name=region_name)

    def emit_ingestion_rate(
        self,
        source: str,
        event_type: str,
        count: int = 1
    ) -> bool:
        """
        Emit incident ingestion rate metric.
        
        Property 29: Metrics emission
        For any incident processed, the system should emit a metric to CloudWatch
        indicating the ingestion occurred.
        
        Args:
            source: Event source (cloudwatch, api_gateway)
            event_type: Type of incident
            count: Number of incidents (default 1)
            
        Returns:
            True if metric emitted successfully
        """
        try:
            self.cloudwatch.put_metric_data(
                Namespace=self.namespace,
                MetricData=[
                    {
                        'MetricName': 'IncidentIngestionRate',
                        'Value': count,
                        'Unit': 'Count',
                        'Timestamp': datetime.utcnow(),
                        'Dimensions': [
                            {'Name': 'Source', 'Value': source},
                            {'Name': 'EventType', 'Value': event_type}
                        ]
                    }
                ]
            )
            logger.debug(f"Emitted ingestion metric: source={source}, type={event_type}")
            return True
            
        except ClientError as e:
            logger.error(f"Failed to emit ingestion metric: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error emitting ingestion metric: {e}")
            return False

    def emit_remediation_success_rate(
        self,
        event_type: str,
        routing_path: str,
        success: bool,
        resolution_time: Optional[int] = None
    ) -> bool:
        """
        Emit remediation success/failure rate metric.
        
        Args:
            event_type: Type of incident
            routing_path: Routing path taken (fast_path, structured_path, escalation)
            success: Whether remediation succeeded
            resolution_time: Time taken to resolve (seconds)
            
        Returns:
            True if metric emitted successfully
        """
        try:
            metric_data = [
                {
                    'MetricName': 'RemediationSuccessRate',
                    'Value': 1 if success else 0,
                    'Unit': 'Count',
                    'Timestamp': datetime.utcnow(),
                    'Dimensions': [
                        {'Name': 'EventType', 'Value': event_type},
                        {'Name': 'RoutingPath', 'Value': routing_path},
                        {'Name': 'Status', 'Value': 'Success' if success else 'Failure'}
                    ]
                }
            ]
            
            # Also emit resolution time if provided
            if resolution_time is not None:
                metric_data.append({
                    'MetricName': 'RemediationResolutionTime',
                    'Value': resolution_time,
                    'Unit': 'Seconds',
                    'Timestamp': datetime.utcnow(),
                    'Dimensions': [
                        {'Name': 'EventType', 'Value': event_type},
                        {'Name': 'RoutingPath', 'Value': routing_path}
                    ]
                })
            
            self.cloudwatch.put_metric_data(
                Namespace=self.namespace,
                MetricData=metric_data
            )
            logger.debug(f"Emitted remediation metric: type={event_type}, success={success}")
            return True
            
        except ClientError as e:
            logger.error(f"Failed to emit remediation metric: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error emitting remediation metric: {e}")
            return False

    def emit_processing_latency(
        self,
        operation: str,
        latency_ms: float,
        dimensions: Optional[Dict[str, str]] = None
    ) -> bool:
        """
        Emit processing latency metric.
        
        Args:
            operation: Operation name (validation, normalization, bedrock_query, etc.)
            latency_ms: Latency in milliseconds
            dimensions: Additional dimensions
            
        Returns:
            True if metric emitted successfully
        """
        try:
            metric_dimensions = [
                {'Name': 'Operation', 'Value': operation}
            ]
            
            if dimensions:
                metric_dimensions.extend([
                    {'Name': k, 'Value': v} for k, v in dimensions.items()
                ])
            
            self.cloudwatch.put_metric_data(
                Namespace=self.namespace,
                MetricData=[
                    {
                        'MetricName': 'ProcessingLatency',
                        'Value': latency_ms,
                        'Unit': 'Milliseconds',
                        'Timestamp': datetime.utcnow(),
                        'Dimensions': metric_dimensions
                    }
                ]
            )
            logger.debug(f"Emitted latency metric: operation={operation}, latency={latency_ms}ms")
            return True
            
        except ClientError as e:
            logger.error(f"Failed to emit latency metric: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error emitting latency metric: {e}")
            return False

    def emit_bedrock_availability(
        self,
        available: bool,
        operation: str = 'query'
    ) -> bool:
        """
        Emit Bedrock service availability metric.
        
        Args:
            available: Whether Bedrock was available
            operation: Operation attempted (query, embedding, etc.)
            
        Returns:
            True if metric emitted successfully
        """
        try:
            self.cloudwatch.put_metric_data(
                Namespace=self.namespace,
                MetricData=[
                    {
                        'MetricName': 'BedrockAvailability',
                        'Value': 1 if available else 0,
                        'Unit': 'Count',
                        'Timestamp': datetime.utcnow(),
                        'Dimensions': [
                            {'Name': 'Operation', 'Value': operation},
                            {'Name': 'Status', 'Value': 'Available' if available else 'Unavailable'}
                        ]
                    }
                ]
            )
            logger.debug(f"Emitted Bedrock availability metric: available={available}")
            return True
            
        except ClientError as e:
            logger.error(f"Failed to emit Bedrock availability metric: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error emitting Bedrock availability metric: {e}")
            return False

    def emit_escalation_rate(
        self,
        event_type: str,
        reason: str,
        severity: str
    ) -> bool:
        """
        Emit escalation rate metric.
        
        Args:
            event_type: Type of incident
            reason: Reason for escalation
            severity: Incident severity
            
        Returns:
            True if metric emitted successfully
        """
        try:
            self.cloudwatch.put_metric_data(
                Namespace=self.namespace,
                MetricData=[
                    {
                        'MetricName': 'EscalationRate',
                        'Value': 1,
                        'Unit': 'Count',
                        'Timestamp': datetime.utcnow(),
                        'Dimensions': [
                            {'Name': 'EventType', 'Value': event_type},
                            {'Name': 'Reason', 'Value': reason},
                            {'Name': 'Severity', 'Value': severity}
                        ]
                    }
                ]
            )
            logger.debug(f"Emitted escalation metric: type={event_type}, reason={reason}")
            return True
            
        except ClientError as e:
            logger.error(f"Failed to emit escalation metric: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error emitting escalation metric: {e}")
            return False

    def emit_routing_decision(
        self,
        routing_path: str,
        confidence: float,
        event_type: str
    ) -> bool:
        """
        Emit routing decision metric.
        
        Args:
            routing_path: Path chosen (fast_path, structured_path, escalation)
            confidence: Confidence score
            event_type: Type of incident
            
        Returns:
            True if metric emitted successfully
        """
        try:
            self.cloudwatch.put_metric_data(
                Namespace=self.namespace,
                MetricData=[
                    {
                        'MetricName': 'RoutingDecision',
                        'Value': 1,
                        'Unit': 'Count',
                        'Timestamp': datetime.utcnow(),
                        'Dimensions': [
                            {'Name': 'RoutingPath', 'Value': routing_path},
                            {'Name': 'EventType', 'Value': event_type}
                        ]
                    },
                    {
                        'MetricName': 'RoutingConfidence',
                        'Value': confidence,
                        'Unit': 'None',
                        'Timestamp': datetime.utcnow(),
                        'Dimensions': [
                            {'Name': 'RoutingPath', 'Value': routing_path},
                            {'Name': 'EventType', 'Value': event_type}
                        ]
                    }
                ]
            )
            logger.debug(f"Emitted routing metric: path={routing_path}, confidence={confidence}")
            return True
            
        except ClientError as e:
            logger.error(f"Failed to emit routing metric: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error emitting routing metric: {e}")
            return False

    def emit_batch_metrics(
        self,
        metrics: List[Dict[str, Any]]
    ) -> bool:
        """
        Emit multiple metrics in a single API call.
        
        Args:
            metrics: List of metric data dictionaries
            
        Returns:
            True if all metrics emitted successfully
        """
        try:
            # CloudWatch allows up to 20 metrics per call
            batch_size = 20
            
            for i in range(0, len(metrics), batch_size):
                batch = metrics[i:i + batch_size]
                self.cloudwatch.put_metric_data(
                    Namespace=self.namespace,
                    MetricData=batch
                )
            
            logger.debug(f"Emitted {len(metrics)} metrics in batch")
            return True
            
        except ClientError as e:
            logger.error(f"Failed to emit batch metrics: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error emitting batch metrics: {e}")
            return False

    def emit_error_rate(
        self,
        error_type: str,
        operation: str,
        severity: str = 'medium'
    ) -> bool:
        """
        Emit error rate metric.
        
        Args:
            error_type: Type of error
            operation: Operation that failed
            severity: Error severity
            
        Returns:
            True if metric emitted successfully
        """
        try:
            self.cloudwatch.put_metric_data(
                Namespace=self.namespace,
                MetricData=[
                    {
                        'MetricName': 'ErrorRate',
                        'Value': 1,
                        'Unit': 'Count',
                        'Timestamp': datetime.utcnow(),
                        'Dimensions': [
                            {'Name': 'ErrorType', 'Value': error_type},
                            {'Name': 'Operation', 'Value': operation},
                            {'Name': 'Severity', 'Value': severity}
                        ]
                    }
                ]
            )
            logger.debug(f"Emitted error metric: type={error_type}, operation={operation}")
            return True
            
        except ClientError as e:
            logger.error(f"Failed to emit error metric: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error emitting error metric: {e}")
            return False
