"""Graceful degradation handlers for service failures"""
import logging
from typing import Dict, Any, Optional
from datetime import datetime
import boto3
from botocore.exceptions import ClientError

from src.utils.error_logging import (
    log_service_unavailable,
    log_error,
    ErrorCategory,
    ErrorSeverity
)

logger = logging.getLogger(__name__)


class GracefulDegradationHandler:
    """
    Handles graceful degradation when services are unavailable.
    
    Provides fallback mechanisms for:
    - Bedrock AI Agent unavailability
    - DynamoDB failures
    - SNS notification failures
    
    Requirements:
    - 15.3: Graceful degradation when services unavailable
    - 15.5: System continues processing with reduced functionality
    """

    def __init__(self, region_name: str = 'us-east-1'):
        """
        Initialize graceful degradation handler.
        
        Args:
            region_name: AWS region
        """
        self.region_name = region_name
        self.sqs = boto3.client('sqs', region_name=region_name)

    def handle_bedrock_unavailable(
        self,
        incident_id: str,
        event_type: str,
        operation: str,
        error_details: str
    ) -> Dict[str, Any]:
        """
        Handle Bedrock service unavailability.
        
        Property 32: Graceful degradation behavior
        When Bedrock is unavailable, the system should fall back to
        structured path (Step Functions pattern matching) instead of failing.
        
        Requirements:
        - 15.5: Continue processing with reduced functionality
        
        Args:
            incident_id: Incident ID
            event_type: Type of incident
            operation: Operation that failed
            error_details: Error details
            
        Returns:
            Degradation response with fallback action
        """
        # Log service unavailability
        log_service_unavailable(
            service_name='Bedrock',
            operation=operation,
            error_details=error_details,
            fallback_action='Route to structured path (pattern matching)'
        )
        
        logger.warning(
            f"Bedrock unavailable for incident {incident_id}, "
            f"falling back to structured path"
        )
        
        return {
            'service': 'Bedrock',
            'available': False,
            'fallback_action': 'structured_path',
            'reason': 'Bedrock service unavailable',
            'incident_id': incident_id,
            'event_type': event_type,
            'timestamp': datetime.utcnow().isoformat() + 'Z'
        }

    def handle_dynamodb_failure(
        self,
        incident_id: str,
        operation: str,
        error_details: str,
        dlq_url: Optional[str] = None,
        incident_data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Handle DynamoDB service failure.
        
        Property 32: Graceful degradation behavior
        When DynamoDB fails, the system should route the incident to a
        Dead Letter Queue for later processing instead of losing data.
        
        Requirements:
        - 15.3: Route to DLQ on persistent failures
        - 15.5: Continue processing with reduced functionality
        
        Args:
            incident_id: Incident ID
            operation: Operation that failed
            error_details: Error details
            dlq_url: Dead Letter Queue URL
            incident_data: Incident data to preserve
            
        Returns:
            Degradation response with DLQ routing status
        """
        # Log service unavailability
        log_service_unavailable(
            service_name='DynamoDB',
            operation=operation,
            error_details=error_details,
            fallback_action='Route to Dead Letter Queue'
        )
        
        logger.warning(
            f"DynamoDB failure for incident {incident_id}, "
            f"routing to DLQ"
        )
        
        # Route to DLQ if URL provided
        dlq_routed = False
        if dlq_url and incident_data:
            dlq_routed = self._route_to_dlq(
                dlq_url=dlq_url,
                incident_id=incident_id,
                incident_data=incident_data,
                failure_reason=f"DynamoDB {operation} failed: {error_details}"
            )
        
        return {
            'service': 'DynamoDB',
            'available': False,
            'fallback_action': 'dlq_routing',
            'dlq_routed': dlq_routed,
            'reason': f"DynamoDB {operation} failed",
            'incident_id': incident_id,
            'timestamp': datetime.utcnow().isoformat() + 'Z'
        }

    def handle_sns_failure(
        self,
        incident_id: str,
        notification_type: str,
        error_details: str,
        notification_data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Handle SNS notification failure.
        
        Property 32: Graceful degradation behavior
        When SNS fails, the system should log the failure but continue
        processing. Notifications are non-critical.
        
        Requirements:
        - 15.5: Continue processing with reduced functionality
        
        Args:
            incident_id: Incident ID
            notification_type: Type of notification (summary, urgent)
            error_details: Error details
            notification_data: Notification data for logging
            
        Returns:
            Degradation response with logging status
        """
        # Log service unavailability
        log_service_unavailable(
            service_name='SNS',
            operation=f'send_{notification_type}_notification',
            error_details=error_details,
            fallback_action='Log notification failure and continue'
        )
        
        logger.warning(
            f"SNS failure for incident {incident_id}, "
            f"notification type: {notification_type}"
        )
        
        # Log notification data for manual review if needed
        if notification_data:
            logger.info(
                f"Failed notification data for incident {incident_id}: "
                f"{notification_data}"
            )
        
        return {
            'service': 'SNS',
            'available': False,
            'fallback_action': 'log_and_continue',
            'notification_type': notification_type,
            'reason': f"SNS {notification_type} notification failed",
            'incident_id': incident_id,
            'timestamp': datetime.utcnow().isoformat() + 'Z'
        }

    def _route_to_dlq(
        self,
        dlq_url: str,
        incident_id: str,
        incident_data: Dict[str, Any],
        failure_reason: str
    ) -> bool:
        """
        Route incident to Dead Letter Queue.
        
        Args:
            dlq_url: SQS DLQ URL
            incident_id: Incident ID
            incident_data: Incident data
            failure_reason: Reason for DLQ routing
            
        Returns:
            True if successfully routed to DLQ
        """
        try:
            message_body = {
                'incident_id': incident_id,
                'incident_data': incident_data,
                'failure_reason': failure_reason,
                'timestamp': datetime.utcnow().isoformat() + 'Z'
            }
            
            import json
            self.sqs.send_message(
                QueueUrl=dlq_url,
                MessageBody=json.dumps(message_body)
            )
            
            logger.info(f"Successfully routed incident {incident_id} to DLQ")
            return True
            
        except ClientError as e:
            logger.error(f"Failed to route to DLQ: {e}")
            log_error(
                error_category=ErrorCategory.SYSTEM,
                error_message=f"DLQ routing failed: {str(e)}",
                severity=ErrorSeverity.CRITICAL,
                incident_id=incident_id,
                exception=e
            )
            return False
        except Exception as e:
            logger.error(f"Unexpected error routing to DLQ: {e}")
            return False


class DLQProcessor:
    """
    Processes messages from Dead Letter Queue.
    
    Retries failed operations when services become available again.
    """

    def __init__(self, region_name: str = 'us-east-1'):
        """
        Initialize DLQ processor.
        
        Args:
            region_name: AWS region
        """
        self.region_name = region_name
        self.sqs = boto3.client('sqs', region_name=region_name)
        self.dynamodb = boto3.client('dynamodb', region_name=region_name)

    def process_dlq_message(
        self,
        message: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Process a message from the DLQ.
        
        Attempts to retry the failed operation.
        
        Args:
            message: SQS message from DLQ
            
        Returns:
            Processing result
        """
        try:
            import json
            body = json.loads(message.get('Body', '{}'))
            
            incident_id = body.get('incident_id')
            incident_data = body.get('incident_data', {})
            failure_reason = body.get('failure_reason', 'Unknown')
            
            logger.info(
                f"Processing DLQ message for incident {incident_id}, "
                f"failure reason: {failure_reason}"
            )
            
            # Attempt to retry the operation
            # For now, we'll try to write to DynamoDB
            retry_success = self._retry_dynamodb_operation(
                incident_id=incident_id,
                incident_data=incident_data
            )
            
            return {
                'incident_id': incident_id,
                'retry_success': retry_success,
                'failure_reason': failure_reason,
                'timestamp': datetime.utcnow().isoformat() + 'Z'
            }
            
        except Exception as e:
            logger.error(f"Error processing DLQ message: {e}")
            return {
                'success': False,
                'error': str(e)
            }

    def _retry_dynamodb_operation(
        self,
        incident_id: str,
        incident_data: Dict[str, Any]
    ) -> bool:
        """
        Retry DynamoDB operation.
        
        Args:
            incident_id: Incident ID
            incident_data: Incident data
            
        Returns:
            True if retry succeeded
        """
        try:
            # Attempt to write to DynamoDB
            # This is a simplified version - in production, you'd use
            # the full DynamoDBService
            table_name = 'IncidentTracking'
            
            self.dynamodb.put_item(
                TableName=table_name,
                Item={
                    'incident_id': {'S': incident_id},
                    'status': {'S': incident_data.get('status', 'received')},
                    'event_type': {'S': incident_data.get('event_type', 'unknown')},
                    'timestamp': {'S': incident_data.get('timestamp', datetime.utcnow().isoformat() + 'Z')}
                }
            )
            
            logger.info(f"Successfully retried DynamoDB operation for {incident_id}")
            return True
            
        except ClientError as e:
            logger.error(f"DynamoDB retry failed: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error during retry: {e}")
            return False


def check_service_health(
    service_name: str,
    region_name: str = 'us-east-1'
) -> bool:
    """
    Check if a service is healthy.
    
    Args:
        service_name: Name of service to check (bedrock, dynamodb, sns)
        region_name: AWS region
        
    Returns:
        True if service is healthy
    """
    try:
        if service_name.lower() == 'bedrock':
            client = boto3.client('bedrock-runtime', region_name=region_name)
            # Simple health check - list models
            client.list_foundation_models()
            return True
            
        elif service_name.lower() == 'dynamodb':
            client = boto3.client('dynamodb', region_name=region_name)
            # Simple health check - list tables
            client.list_tables()
            return True
            
        elif service_name.lower() == 'sns':
            client = boto3.client('sns', region_name=region_name)
            # Simple health check - list topics
            client.list_topics()
            return True
            
        else:
            logger.warning(f"Unknown service: {service_name}")
            return False
            
    except ClientError as e:
        logger.error(f"Service health check failed for {service_name}: {e}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error checking {service_name} health: {e}")
        return False
