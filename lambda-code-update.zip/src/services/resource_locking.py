"""Resource locking mechanism for concurrent incident processing"""
import logging
from typing import Optional, Dict, Any
from datetime import datetime, timedelta, timezone
import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


class ResourceLockManager:
    """
    Manages resource locks to prevent concurrent remediation of the same resource.
    
    Uses DynamoDB for distributed locking with automatic expiry.
    
    Requirements:
    - 12.1: Create incident records (lock table)
    - 12.3: Update incident status (lock acquisition/release)
    """

    def __init__(
        self,
        table_name: str = 'ResourceLocks',
        region_name: str = 'us-east-1',
        default_lock_duration_seconds: int = 300  # 5 minutes
    ):
        """
        Initialize resource lock manager.
        
        Args:
            table_name: DynamoDB table name for locks
            region_name: AWS region
            default_lock_duration_seconds: Default lock duration
        """
        self.table_name = table_name
        self.region_name = region_name
        self.default_lock_duration_seconds = default_lock_duration_seconds
        self.dynamodb = boto3.resource('dynamodb', region_name=region_name)
        self.table = self.dynamodb.Table(table_name)

    def acquire_resource_lock(
        self,
        resource_id: str,
        incident_id: str,
        lock_duration_seconds: Optional[int] = None
    ) -> bool:
        """
        Acquire a lock on a resource.
        
        Uses conditional write to ensure only one incident can lock a resource.
        
        Args:
            resource_id: ID of resource to lock (e.g., instance-id, function-arn)
            incident_id: ID of incident acquiring the lock
            lock_duration_seconds: Lock duration (default: 5 minutes)
            
        Returns:
            True if lock acquired successfully
        """
        duration = lock_duration_seconds or self.default_lock_duration_seconds
        expiry_time = datetime.now(timezone.utc) + timedelta(seconds=duration)
        
        try:
            # Try to create lock record with condition that it doesn't exist
            # or that it has expired
            self.table.put_item(
                Item={
                    'resource_id': resource_id,
                    'incident_id': incident_id,
                    'lock_acquired_at': datetime.now(timezone.utc).isoformat(),
                    'lock_expires_at': expiry_time.isoformat(),
                    'lock_duration_seconds': duration
                },
                ConditionExpression='attribute_not_exists(resource_id) OR lock_expires_at < :now',
                ExpressionAttributeValues={
                    ':now': datetime.now(timezone.utc).isoformat()
                }
            )
            
            logger.info(
                f"Lock acquired for resource {resource_id} by incident {incident_id}, "
                f"expires at {expiry_time.isoformat()}"
            )
            return True
            
        except ClientError as e:
            if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
                # Lock already exists and hasn't expired
                logger.warning(
                    f"Failed to acquire lock for resource {resource_id}: "
                    f"already locked by another incident"
                )
                return False
            else:
                logger.error(f"Error acquiring lock for resource {resource_id}: {e}")
                return False
        except Exception as e:
            logger.error(f"Unexpected error acquiring lock: {e}")
            return False

    def release_resource_lock(
        self,
        resource_id: str,
        incident_id: str
    ) -> bool:
        """
        Release a lock on a resource.
        
        Only the incident that acquired the lock can release it.
        
        Args:
            resource_id: ID of resource to unlock
            incident_id: ID of incident releasing the lock
            
        Returns:
            True if lock released successfully
        """
        try:
            # Delete lock record with condition that it's owned by this incident
            self.table.delete_item(
                Key={'resource_id': resource_id},
                ConditionExpression='incident_id = :incident_id',
                ExpressionAttributeValues={
                    ':incident_id': incident_id
                }
            )
            
            logger.info(
                f"Lock released for resource {resource_id} by incident {incident_id}"
            )
            return True
            
        except ClientError as e:
            if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
                # Lock doesn't exist or is owned by different incident
                logger.warning(
                    f"Failed to release lock for resource {resource_id}: "
                    f"not owned by incident {incident_id}"
                )
                return False
            else:
                logger.error(f"Error releasing lock for resource {resource_id}: {e}")
                return False
        except Exception as e:
            logger.error(f"Unexpected error releasing lock: {e}")
            return False

    def check_lock_expiry(
        self,
        resource_id: str
    ) -> Dict[str, Any]:
        """
        Check if a lock exists and whether it has expired.
        
        Args:
            resource_id: ID of resource to check
            
        Returns:
            Dict with lock status information
        """
        try:
            response = self.table.get_item(
                Key={'resource_id': resource_id}
            )
            
            if 'Item' not in response:
                return {
                    'locked': False,
                    'expired': False,
                    'resource_id': resource_id
                }
            
            lock = response['Item']
            expiry_time = datetime.fromisoformat(lock['lock_expires_at'].replace('Z', '+00:00'))
            now = datetime.now(timezone.utc)
            expired = now >= expiry_time
            
            return {
                'locked': not expired,
                'expired': expired,
                'resource_id': resource_id,
                'incident_id': lock.get('incident_id'),
                'lock_acquired_at': lock.get('lock_acquired_at'),
                'lock_expires_at': lock.get('lock_expires_at'),
                'time_remaining_seconds': max(0, (expiry_time - now).total_seconds()) if not expired else 0
            }
            
        except ClientError as e:
            logger.error(f"Error checking lock expiry for resource {resource_id}: {e}")
            return {
                'locked': False,
                'expired': False,
                'resource_id': resource_id,
                'error': str(e)
            }
        except Exception as e:
            logger.error(f"Unexpected error checking lock expiry: {e}")
            return {
                'locked': False,
                'expired': False,
                'resource_id': resource_id,
                'error': str(e)
            }

    def extend_lock(
        self,
        resource_id: str,
        incident_id: str,
        additional_seconds: int
    ) -> bool:
        """
        Extend an existing lock duration.
        
        Args:
            resource_id: ID of resource
            incident_id: ID of incident that owns the lock
            additional_seconds: Additional seconds to add to lock duration
            
        Returns:
            True if lock extended successfully
        """
        try:
            # Get current lock
            lock_status = self.check_lock_expiry(resource_id)
            
            if not lock_status['locked']:
                logger.warning(
                    f"Cannot extend lock for resource {resource_id}: "
                    f"lock does not exist or has expired"
                )
                return False
            
            if lock_status.get('incident_id') != incident_id:
                logger.warning(
                    f"Cannot extend lock for resource {resource_id}: "
                    f"lock owned by different incident"
                )
                return False
            
            # Calculate new expiry time
            current_expiry = datetime.fromisoformat(
                lock_status['lock_expires_at'].replace('Z', '+00:00')
            )
            new_expiry = current_expiry + timedelta(seconds=additional_seconds)
            
            # Update lock expiry
            self.table.update_item(
                Key={'resource_id': resource_id},
                UpdateExpression='SET lock_expires_at = :new_expiry',
                ConditionExpression='incident_id = :incident_id',
                ExpressionAttributeValues={
                    ':new_expiry': new_expiry.isoformat(),
                    ':incident_id': incident_id
                }
            )
            
            logger.info(
                f"Lock extended for resource {resource_id} by {additional_seconds}s, "
                f"new expiry: {new_expiry.isoformat()}"
            )
            return True
            
        except ClientError as e:
            logger.error(f"Error extending lock for resource {resource_id}: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error extending lock: {e}")
            return False

    def cleanup_expired_locks(self) -> int:
        """
        Clean up expired locks from the table.
        
        This should be run periodically to prevent table bloat.
        
        Returns:
            Number of locks cleaned up
        """
        try:
            # Scan for expired locks
            now = datetime.now(timezone.utc).isoformat()
            response = self.table.scan(
                FilterExpression='lock_expires_at < :now',
                ExpressionAttributeValues={
                    ':now': now
                }
            )
            
            expired_locks = response.get('Items', [])
            cleanup_count = 0
            
            for lock in expired_locks:
                try:
                    self.table.delete_item(
                        Key={'resource_id': lock['resource_id']}
                    )
                    cleanup_count += 1
                except Exception as e:
                    logger.error(
                        f"Error deleting expired lock for {lock['resource_id']}: {e}"
                    )
            
            if cleanup_count > 0:
                logger.info(f"Cleaned up {cleanup_count} expired locks")
            
            return cleanup_count
            
        except Exception as e:
            logger.error(f"Error cleaning up expired locks: {e}")
            return 0


def with_resource_lock(
    lock_manager: ResourceLockManager,
    resource_id: str,
    incident_id: str,
    lock_duration_seconds: Optional[int] = None
):
    """
    Context manager for resource locking.
    
    Usage:
        with with_resource_lock(lock_manager, resource_id, incident_id):
            # Perform remediation
            pass
    
    Args:
        lock_manager: ResourceLockManager instance
        resource_id: ID of resource to lock
        incident_id: ID of incident
        lock_duration_seconds: Lock duration
    """
    class ResourceLockContext:
        def __init__(self):
            self.acquired = False
        
        def __enter__(self):
            self.acquired = lock_manager.acquire_resource_lock(
                resource_id=resource_id,
                incident_id=incident_id,
                lock_duration_seconds=lock_duration_seconds
            )
            if not self.acquired:
                raise RuntimeError(
                    f"Failed to acquire lock for resource {resource_id}"
                )
            return self
        
        def __exit__(self, exc_type, exc_val, exc_tb):
            if self.acquired:
                lock_manager.release_resource_lock(
                    resource_id=resource_id,
                    incident_id=incident_id
                )
            return False
    
    return ResourceLockContext()
