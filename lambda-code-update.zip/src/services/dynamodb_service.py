"""DynamoDB service for incident tracking operations"""
import time
import logging
from typing import List, Optional, Dict, Any, Literal
from datetime import datetime, timedelta
import boto3
from botocore.exceptions import ClientError
from src.models import IncidentRecord

logger = logging.getLogger(__name__)


class DynamoDBService:
    """
    Service for DynamoDB incident tracking operations.
    
    Implements CRUD operations with retry logic and exponential backoff.
    """

    def __init__(
        self,
        table_name: str,
        region_name: str = 'us-east-1',
        max_retries: int = 3,
        backoff_base: float = 1.0
    ):
        """
        Initialize DynamoDB service.
        
        Args:
            table_name: Name of the DynamoDB table
            region_name: AWS region
            max_retries: Maximum number of retry attempts
            backoff_base: Base delay for exponential backoff (seconds)
        """
        self.table_name = table_name
        self.max_retries = max_retries
        self.backoff_base = backoff_base
        
        self.dynamodb = boto3.resource('dynamodb', region_name=region_name)
        self.table = self.dynamodb.Table(table_name)

    def create_incident_record(self, record: IncidentRecord) -> bool:
        """
        Create a new incident record in DynamoDB.
        
        Property 19: Incident record creation
        For any received incident, a record should be created in the Incident 
        Tracking Database with a unique incident ID and initial status of 'received'.
        
        Args:
            record: IncidentRecord to create
            
        Returns:
            True if successful, False otherwise
        """
        item = self._record_to_item(record)
        
        return self._retry_operation(
            operation=lambda: self.table.put_item(Item=item),
            operation_name='create_incident_record',
            incident_id=record.incident_id
        )

    def update_incident_status(
        self,
        incident_id: str,
        timestamp: int,
        new_status: Literal['received', 'analyzing', 'remediating', 'resolved', 'failed', 'escalated'],
        resolution_steps: Optional[List[str]] = None,
        resolution_time: Optional[int] = None,
        error_message: Optional[str] = None,
        matched_incident_id: Optional[str] = None,
        confidence: Optional[float] = None
    ) -> bool:
        """
        Update incident status and related fields.
        
        Property 21: Status update consistency
        For any incident status change, the corresponding DynamoDB record should 
        be updated with the new status and the updatedAt timestamp should be more 
        recent than the previous updatedAt value.
        
        Args:
            incident_id: Incident ID
            timestamp: Incident timestamp (sort key)
            new_status: New status value
            resolution_steps: Optional resolution steps
            resolution_time: Optional resolution time in seconds
            error_message: Optional error message
            matched_incident_id: Optional matched incident ID
            confidence: Optional confidence score
            
        Returns:
            True if successful, False otherwise
        """
        from decimal import Decimal
        
        update_expression = "SET #status = :status, updated_at = :updated_at"
        expression_attribute_names = {"#status": "status"}
        expression_attribute_values = {
            ":status": new_status,
            ":updated_at": datetime.utcnow().isoformat() + 'Z'
        }

        # Add optional fields
        if resolution_steps is not None:
            update_expression += ", resolution_steps = :resolution_steps"
            expression_attribute_values[":resolution_steps"] = resolution_steps

        if resolution_time is not None:
            update_expression += ", resolution_time = :resolution_time"
            expression_attribute_values[":resolution_time"] = resolution_time

        if error_message is not None:
            update_expression += ", error_message = :error_message"
            expression_attribute_values[":error_message"] = error_message

        if matched_incident_id is not None:
            update_expression += ", matched_incident_id = :matched_incident_id"
            expression_attribute_values[":matched_incident_id"] = matched_incident_id

        if confidence is not None:
            update_expression += ", confidence = :confidence"
            # Convert float to Decimal for DynamoDB
            expression_attribute_values[":confidence"] = Decimal(str(confidence))

        return self._retry_operation(
            operation=lambda: self.table.update_item(
                Key={
                    'incident_id': incident_id,
                    'timestamp': timestamp
                },
                UpdateExpression=update_expression,
                ExpressionAttributeNames=expression_attribute_names,
                ExpressionAttributeValues=expression_attribute_values
            ),
            operation_name='update_incident_status',
            incident_id=incident_id
        )

    def query_incidents_by_time_range(
        self,
        start_time: datetime,
        end_time: datetime,
        source: Optional[str] = None
    ) -> List[IncidentRecord]:
        """
        Query incidents within a time range.
        
        Property 22: Query result correctness
        For any query to the Incident Tracking Database by time range, all returned 
        records should match the query criteria and no matching records should be omitted.
        
        Args:
            start_time: Start of time range
            end_time: End of time range
            source: Optional source filter (uses TimeRangeIndex GSI)
            
        Returns:
            List of IncidentRecords matching criteria
        """
        start_timestamp = int(start_time.timestamp() * 1000)
        end_timestamp = int(end_time.timestamp() * 1000)

        try:
            if source:
                # Use TimeRangeIndex GSI
                response = self.table.query(
                    IndexName='TimeRangeIndex',
                    KeyConditionExpression='#source = :source AND #timestamp BETWEEN :start AND :end',
                    ExpressionAttributeNames={
                        '#source': 'source',
                        '#timestamp': 'timestamp'
                    },
                    ExpressionAttributeValues={
                        ':source': source,
                        ':start': start_timestamp,
                        ':end': end_timestamp
                    }
                )
            else:
                # Scan with filter (less efficient but necessary without source)
                response = self.table.scan(
                    FilterExpression='#timestamp BETWEEN :start AND :end',
                    ExpressionAttributeNames={'#timestamp': 'timestamp'},
                    ExpressionAttributeValues={
                        ':start': start_timestamp,
                        ':end': end_timestamp
                    }
                )

            items = response.get('Items', [])
            return [self._item_to_record(item) for item in items]

        except ClientError as e:
            logger.error(f"Error querying incidents by time range: {e}")
            return []

    def query_incidents_by_status(
        self,
        status: Literal['received', 'analyzing', 'remediating', 'resolved', 'failed', 'escalated'],
        limit: Optional[int] = None
    ) -> List[IncidentRecord]:
        """
        Query incidents by status using StatusIndex GSI.
        
        Property 22: Query result correctness
        
        Args:
            status: Status to filter by
            limit: Optional limit on number of results
            
        Returns:
            List of IncidentRecords with matching status
        """
        try:
            query_params = {
                'IndexName': 'StatusIndex',
                'KeyConditionExpression': '#status = :status',
                'ExpressionAttributeNames': {'#status': 'status'},
                'ExpressionAttributeValues': {':status': status},
                'ScanIndexForward': False  # Most recent first
            }

            if limit:
                query_params['Limit'] = limit

            response = self.table.query(**query_params)
            items = response.get('Items', [])
            return [self._item_to_record(item) for item in items]

        except ClientError as e:
            logger.error(f"Error querying incidents by status: {e}")
            return []

    def query_incidents_by_event_type(
        self,
        event_type: str,
        limit: Optional[int] = None
    ) -> List[IncidentRecord]:
        """
        Query incidents by event type using EventTypeIndex GSI.
        
        Property 22: Query result correctness
        
        Args:
            event_type: Event type to filter by
            limit: Optional limit on number of results
            
        Returns:
            List of IncidentRecords with matching event type
        """
        try:
            query_params = {
                'IndexName': 'EventTypeIndex',
                'KeyConditionExpression': 'event_type = :event_type',
                'ExpressionAttributeValues': {':event_type': event_type},
                'ScanIndexForward': False  # Most recent first
            }

            if limit:
                query_params['Limit'] = limit

            response = self.table.query(**query_params)
            items = response.get('Items', [])
            return [self._item_to_record(item) for item in items]

        except ClientError as e:
            logger.error(f"Error querying incidents by event type: {e}")
            return []

    def get_incident(self, incident_id: str, timestamp: int) -> Optional[IncidentRecord]:
        """
        Get a specific incident by ID and timestamp.
        
        Args:
            incident_id: Incident ID
            timestamp: Incident timestamp
            
        Returns:
            IncidentRecord if found, None otherwise
        """
        try:
            response = self.table.get_item(
                Key={
                    'incident_id': incident_id,
                    'timestamp': timestamp
                }
            )
            item = response.get('Item')
            return self._item_to_record(item) if item else None

        except ClientError as e:
            logger.error(f"Error getting incident {incident_id}: {e}")
            return None

    def _retry_operation(
        self,
        operation: callable,
        operation_name: str,
        incident_id: str
    ) -> bool:
        """
        Execute operation with exponential backoff retry logic.
        
        Handles throttling errors and transient failures.
        
        Args:
            operation: Function to execute
            operation_name: Name for logging
            incident_id: Incident ID for logging
            
        Returns:
            True if successful, False after all retries exhausted
        """
        for attempt in range(self.max_retries):
            try:
                operation()
                return True

            except ClientError as e:
                error_code = e.response['Error']['Code']
                
                # Check if error is retryable
                if error_code in ['ProvisionedThroughputExceededException', 'ThrottlingException']:
                    if attempt < self.max_retries - 1:
                        # Calculate backoff delay
                        delay = self.backoff_base * (2 ** attempt)
                        logger.warning(
                            f"{operation_name} throttled for incident {incident_id}, "
                            f"retrying in {delay}s (attempt {attempt + 1}/{self.max_retries})"
                        )
                        time.sleep(delay)
                        continue
                    else:
                        logger.error(
                            f"{operation_name} failed after {self.max_retries} retries "
                            f"for incident {incident_id}: {e}"
                        )
                        return False
                else:
                    # Non-retryable error
                    logger.error(f"{operation_name} failed for incident {incident_id}: {e}")
                    return False

            except Exception as e:
                logger.error(f"Unexpected error in {operation_name} for incident {incident_id}: {e}")
                return False

        return False

    def _record_to_item(self, record: IncidentRecord) -> Dict[str, Any]:
        """
        Convert IncidentRecord to DynamoDB item.
        
        Property 20: Incident record structure
        For any incident record created in DynamoDB, it should contain all required 
        fields: incidentId, timestamp, source, eventType, severity, status, 
        affectedResources, createdAt, and updatedAt.
        """
        item = {
            'incident_id': record.incident_id,
            'timestamp': record.timestamp,
            'source': record.source,
            'event_type': record.event_type,
            'severity': record.severity,
            'affected_resources': record.affected_resources,
            'status': record.status,
            'routing_path': record.routing_path,
            'created_at': record.created_at,
            'updated_at': record.updated_at
        }

        # Add optional fields if present
        if record.confidence is not None:
            item['confidence'] = record.confidence
        if record.matched_incident_id is not None:
            item['matched_incident_id'] = record.matched_incident_id
        if record.resolution_steps is not None:
            item['resolution_steps'] = record.resolution_steps
        if record.resolution_time is not None:
            item['resolution_time'] = record.resolution_time
        if record.error_message is not None:
            item['error_message'] = record.error_message
        if record.ttl is not None:
            item['ttl'] = record.ttl

        return item

    def _item_to_record(self, item: Dict[str, Any]) -> IncidentRecord:
        """Convert DynamoDB item to IncidentRecord"""
        return IncidentRecord(
            incident_id=item['incident_id'],
            timestamp=item['timestamp'],
            source=item['source'],
            event_type=item['event_type'],
            severity=item['severity'],
            affected_resources=item['affected_resources'],
            status=item['status'],
            routing_path=item['routing_path'],
            confidence=item.get('confidence'),
            matched_incident_id=item.get('matched_incident_id'),
            resolution_steps=item.get('resolution_steps'),
            resolution_time=item.get('resolution_time'),
            error_message=item.get('error_message'),
            created_at=item['created_at'],
            updated_at=item['updated_at'],
            ttl=item.get('ttl')
        )
