"""AI Agent remediation executor service"""
import logging
import json
from typing import Dict, Any, List, Optional
import boto3
from botocore.exceptions import ClientError
from src.models import IncidentEvent, AgentResponse, RemediationResult, ResolutionStep
from src.services.dynamodb_service import DynamoDBService
from src.services.knowledge_base_service import KnowledgeBaseService

logger = logging.getLogger(__name__)


class AIAgentExecutor:
    """
    Executor for AI Agent remediation recommendations.
    
    Executes high-confidence remediation steps from the AI Agent.
    """

    def __init__(self, region_name: str = 'us-east-1', incident_table_name: str = None):
        """
        Initialize AI Agent executor.
        
        Args:
            region_name: AWS region
            incident_table_name: DynamoDB incident table name
        """
        from config import INCIDENT_TABLE_NAME, KNOWLEDGE_BASE_BUCKET
        
        self.region_name = region_name
        self.lambda_client = boto3.client('lambda', region_name=region_name)
        self.dynamodb_service = DynamoDBService(
            table_name=incident_table_name or INCIDENT_TABLE_NAME,
            region_name=region_name
        )
        self.knowledge_base_service = KnowledgeBaseService(
            bucket_name=KNOWLEDGE_BASE_BUCKET,
            region_name=region_name
        )

    def execute_remediation_steps(
        self,
        incident: IncidentEvent,
        agent_response: AgentResponse
    ) -> RemediationResult:
        """
        Execute remediation steps from AI Agent response.
        
        Property 27: High-confidence remediation execution
        For high-confidence matches (≥ 0.85), execute remediation steps from agent.
        
        Args:
            incident: IncidentEvent to remediate
            agent_response: AgentResponse with remediation steps
            
        Returns:
            RemediationResult with execution status
        """
        start_time = self._get_current_time()
        actions_performed = []
        
        try:
            # Validate agent response has remediation steps
            if not agent_response.resolution_steps:
                return RemediationResult.create_failure(
                    error_message="No resolution steps provided by AI Agent",
                    resolution_time=self._calculate_duration(start_time),
                    actions_attempted=['Attempted to execute remediation']
                )
            
            # Replace placeholders in resolution steps with actual resource names
            resolution_steps = self._replace_resource_placeholders(
                agent_response.resolution_steps,
                incident
            )
            
            actions_performed.append(f"Executing {len(resolution_steps)} remediation steps")
            logger.info(f"Executing {len(resolution_steps)} steps for incident {incident.incident_id}")
            
            # Execute each remediation step
            step_results = []
            for i, step in enumerate(resolution_steps, 1):
                logger.info(f"Executing step {i}/{len(resolution_steps)}: {step.action}")
                
                step_result = self._execute_single_step(step, incident)
                step_results.append(step_result)
                
                if step_result['success']:
                    actions_performed.append(f"Step {i}: {step.action} - Success")
                else:
                    actions_performed.append(f"Step {i}: {step.action} - Failed: {step_result.get('error')}")
                    
                    # Handle failure
                    failure_handled = self.handle_remediation_failure(
                        incident,
                        agent_response,
                        step_result,
                        i
                    )
                    
                    if not failure_handled:
                        # Critical failure, stop execution
                        return RemediationResult.create_failure(
                            error_message=f"Step {i} failed: {step_result.get('error')}",
                            resolution_time=self._calculate_duration(start_time),
                            actions_attempted=actions_performed
                        )
            
            # All steps succeeded
            actions_performed.append("All remediation steps completed successfully")
            
            # Update Knowledge Base and DynamoDB
            update_success = self.update_knowledge_base_and_dynamodb(
                incident,
                agent_response,
                step_results
            )
            
            if update_success:
                actions_performed.append("Updated Knowledge Base and DynamoDB")
            
            return RemediationResult.create_success(
                actions=actions_performed,
                resolution_time=self._calculate_duration(start_time),
                new_state={
                    'steps_executed': len(step_results),
                    'steps_succeeded': sum(1 for r in step_results if r['success']),
                    'agent_confidence': agent_response.confidence,
                    'matched_incident': agent_response.matched_incident
                }
            )
            
        except Exception as e:
            logger.error(f"Unexpected error during remediation execution: {e}")
            return RemediationResult.create_failure(
                error_message=f"Execution error: {str(e)}",
                resolution_time=self._calculate_duration(start_time),
                actions_attempted=actions_performed
            )
    
    def _replace_resource_placeholders(
        self,
        resolution_steps: List['ResolutionStep'],
        incident: IncidentEvent
    ) -> List['ResolutionStep']:
        """
        Replace placeholder resource names in resolution steps with actual values from incident.
        
        Args:
            resolution_steps: Original resolution steps from Bedrock
            incident: IncidentEvent with actual resource names
            
        Returns:
            Resolution steps with placeholders replaced
        """
        # Extract resource names from incident
        resource_name = None
        
        # Try to get function name from Lambda incidents
        if 'Lambda' in incident.event_type or 'lambda' in incident.source:
            # Check affected resources
            for resource in incident.affected_resources:
                if 'function' in resource.lower() or ':function:' in resource:
                    # Extract function name from ARN or direct name
                    if ':function:' in resource:
                        resource_name = resource.split(':function:')[-1].split(':')[0]
                    else:
                        resource_name = resource
                    break
            
            # Check metadata for function name
            if not resource_name and incident.metadata:
                for key in ['FunctionName', 'function_name', 'functionName']:
                    if key in incident.metadata:
                        resource_name = incident.metadata[key]
                        break
        
        # Try to get instance ID from EC2 incidents
        elif 'EC2' in incident.event_type or 'ec2' in incident.source:
            for resource in incident.affected_resources:
                if resource.startswith('i-'):
                    resource_name = resource
                    break
            
            if not resource_name and incident.metadata:
                for key in ['InstanceId', 'instance_id', 'instanceId']:
                    if key in incident.metadata:
                        resource_name = incident.metadata[key]
                        break
        
        # If no resource name found, use a default
        if not resource_name:
            resource_name = incident.affected_resources[0] if incident.affected_resources else "unknown-resource"
        
        logger.info(f"Extracted resource name: {resource_name}")
        
        # Get current Lambda configuration if needed for timeout calculation
        current_timeout = None
        if 'Lambda' in incident.event_type or 'lambda' in incident.source:
            try:
                lambda_client = boto3.client('lambda', region_name=self.region_name)
                response = lambda_client.get_function_configuration(FunctionName=resource_name)
                current_timeout = response.get('Timeout', 3)
                logger.info(f"Current Lambda timeout: {current_timeout} seconds")
            except Exception as e:
                logger.warning(f"Could not get current timeout: {e}")
                current_timeout = 3  # Default
        
        # Replace placeholders in each step
        updated_steps = []
        for step in resolution_steps:
            # Create a copy of parameters
            updated_params = step.parameters.copy()
            
            # Replace common placeholder patterns
            for key, value in updated_params.items():
                if isinstance(value, str):
                    # Replace resource name placeholders
                    if 'REPLACE_WITH_ACTUAL' in value or '<function_name>' in value or '<instance_id>' in value:
                        updated_params[key] = resource_name
                    # Replace timeout calculation placeholder
                    elif value == 'CURRENT_TIMEOUT_PLUS_30' and current_timeout:
                        # If already at max, keep it; otherwise increase by 30
                        if current_timeout >= 900:
                            new_timeout = 900  # Already at max
                            logger.info(f"Timeout already at maximum (900 seconds), keeping current value")
                        else:
                            new_timeout = min(current_timeout + 30, 900)  # Cap at Lambda max
                            logger.info(f"Calculated new timeout: {new_timeout} seconds (current: {current_timeout} + 30, max: 900)")
                        updated_params[key] = new_timeout
                elif isinstance(value, list):
                    # Handle lists (e.g., InstanceIds)
                    updated_params[key] = [
                        resource_name if isinstance(item, str) and ('REPLACE' in item or '<' in item) else item
                        for item in value
                    ]
            
            # Create new ResolutionStep with updated parameters
            from src.models import ResolutionStep
            updated_step = ResolutionStep(
                step_number=step.step_number,
                action=step.action,
                target=step.target,
                parameters=updated_params,
                description=step.description
            )
            updated_steps.append(updated_step)
        
        return updated_steps

    def _execute_single_step(
        self,
        step: 'ResolutionStep',
        incident: IncidentEvent
    ) -> Dict[str, Any]:
        """
        Execute a single remediation step.
        
        Args:
            step: ResolutionStep from agent
            incident: IncidentEvent context
            
        Returns:
            Dict with execution result
        """
        action_type = step.action
        
        try:
            if action_type == 'aws_api_call':
                # Execute AWS API call
                return self.invoke_aws_api(step, incident)
            
            elif action_type == 'invoke_lambda':
                # Invoke Lambda function
                return self.invoke_lambda(step, incident)
            
            elif action_type == 'wait':
                # Wait step (simulated)
                return {
                    'success': True,
                    'action': step.action,
                    'result': f"Wait step: {step.description}"
                }
            
            elif action_type == 'conditional':
                # Conditional step (simulated)
                return {
                    'success': True,
                    'action': step.action,
                    'result': f"Conditional step: {step.description}"
                }
            
            else:
                return {
                    'success': False,
                    'action': step.action,
                    'error': f"Unknown action type: {action_type}"
                }
                
        except Exception as e:
            logger.error(f"Error executing step: {e}")
            return {
                'success': False,
                'action': step.action,
                'error': str(e)
            }

    def invoke_aws_api(
        self,
        step: 'ResolutionStep',
        incident: IncidentEvent
    ) -> Dict[str, Any]:
        """
        Invoke AWS API based on remediation step.
        
        Args:
            step: ResolutionStep with AWS API details
            incident: IncidentEvent context
            
        Returns:
            Dict with invocation result
        """
        # Parse target for service and operation (format: "service:operation")
        if ':' not in step.target:
            return {
                'success': False,
                'action': step.action,
                'error': 'Target must be in format "service:operation"'
            }
        
        service, operation = step.target.split(':', 1)
        
        # Fix common service name mistakes from knowledge base/Bedrock
        service = self._fix_service_name(service, operation)
        
        parameters = step.parameters.copy()  # Make a copy to avoid modifying original
        
        # Log original parameters for debugging
        logger.info(f"Original parameters before processing: {json.dumps(parameters, default=str)}")
        
        # Process parameters to replace placeholders with actual values
        parameters = self._process_parameters(parameters, incident)
        
        # Log processed parameters for debugging
        logger.info(f"Processed parameters after conversion: {json.dumps(parameters, default=str)}")
        
        # Convert AWS API operation name (PascalCase) to boto3 method name (snake_case)
        # e.g., GetFunction -> get_function, UpdateFunctionConfiguration -> update_function_configuration
        boto3_method_name = self._convert_to_boto3_method(operation)
        
        try:
            # Create boto3 client for the service
            client = boto3.client(service, region_name=self.region_name)
            
            # Get the operation method
            if not hasattr(client, boto3_method_name):
                return {
                    'success': False,
                    'action': step.action,
                    'error': f"Operation {operation} (boto3: {boto3_method_name}) not found on {service}"
                }
            
            # Execute the operation
            operation_method = getattr(client, boto3_method_name)
            response = operation_method(**parameters)
            
            logger.info(f"Successfully executed {service}.{boto3_method_name}")
            
            return {
                'success': True,
                'action': step.action,
                'result': response,
                'service': service,
                'operation': operation,
                'boto3_method': boto3_method_name
            }
            
        except ClientError as e:
            logger.error(f"AWS API error: {e}")
            return {
                'success': False,
                'action': step.action,
                'error': f"AWS API error: {str(e)}",
                'service': service,
                'operation': operation
            }
        except Exception as e:
            logger.error(f"Error invoking AWS API: {e}")
            return {
                'success': False,
                'action': step.action,
                'error': str(e)
            }
    
    def _process_parameters(
        self,
        parameters: Dict[str, Any],
        incident: IncidentEvent
    ) -> Dict[str, Any]:
        """
        Process parameters to replace placeholders with actual values.
        
        Handles placeholders like:
        - "current_time", "now" -> datetime.now()
        - "time_minus_3_hours" -> datetime.now() - timedelta(hours=3)
        - "now-24h", "now-3h" -> datetime.now() - timedelta(hours=24/3)
        - "now+1h" -> datetime.now() + timedelta(hours=1)
        - "-3h", "+1h", "-30m" -> relative time from now
        
        Args:
            parameters: Original parameters dict
            incident: IncidentEvent context
            
        Returns:
            Processed parameters with placeholders replaced
        """
        from datetime import datetime, timedelta, timezone
        import re
        
        processed = {}
        
        for key, value in parameters.items():
            if isinstance(value, str):
                # Handle time placeholders
                if value in ['current_time', 'now', 'time-now']:
                    processed[key] = datetime.now(timezone.utc)
                # Handle "now-24h", "now-3h", "now-30m", "now+1h" format
                elif re.match(r'now[-+]\d+[hm]', value):
                    match = re.match(r'now([-+])(\d+)([hm])', value)
                    if match:
                        sign, amount, unit = match.groups()
                        amount = int(amount)
                        if sign == '-':
                            amount = -amount
                        
                        if unit == 'h':
                            processed[key] = datetime.now(timezone.utc) + timedelta(hours=amount)
                        else:  # 'm'
                            processed[key] = datetime.now(timezone.utc) + timedelta(minutes=amount)
                    else:
                        processed[key] = value
                # Handle "-3h", "+1h", "-30m" format (without "now" prefix)
                elif re.match(r'^[-+]\d+[hm]$', value):
                    match = re.match(r'^([-+])(\d+)([hm])$', value)
                    if match:
                        sign, amount, unit = match.groups()
                        amount = int(amount)
                        if sign == '-':
                            amount = -amount
                        
                        if unit == 'h':
                            processed[key] = datetime.now(timezone.utc) + timedelta(hours=amount)
                        else:  # 'm'
                            processed[key] = datetime.now(timezone.utc) + timedelta(minutes=amount)
                    else:
                        processed[key] = value
                # Handle "time-24hours", "time-3hours" format
                elif re.match(r'^time-\d+(hours?|minutes?|days?)$', value):
                    match = re.match(r'^time-(\d+)(hours?|minutes?|days?)$', value)
                    if match:
                        amount, unit = match.groups()
                        amount = int(amount)
                        
                        if 'hour' in unit:
                            processed[key] = datetime.now(timezone.utc) - timedelta(hours=amount)
                        elif 'minute' in unit:
                            processed[key] = datetime.now(timezone.utc) - timedelta(minutes=amount)
                        elif 'day' in unit:
                            processed[key] = datetime.now(timezone.utc) - timedelta(days=amount)
                        else:
                            processed[key] = value
                    else:
                        processed[key] = value
                # Handle "time_minus_3_hours" format
                elif value.startswith('time_minus_'):
                    try:
                        parts = value.split('_')
                        if len(parts) >= 3 and parts[-1] in ['hours', 'hour']:
                            hours = int(parts[2])
                            processed[key] = datetime.now(timezone.utc) - timedelta(hours=hours)
                        elif len(parts) >= 3 and parts[-1] in ['minutes', 'minute']:
                            minutes = int(parts[2])
                            processed[key] = datetime.now(timezone.utc) - timedelta(minutes=minutes)
                        else:
                            processed[key] = value
                    except (ValueError, IndexError):
                        processed[key] = value
                # Handle "time_plus_1_hours" format
                elif value.startswith('time_plus_'):
                    try:
                        parts = value.split('_')
                        if len(parts) >= 3 and parts[-1] in ['hours', 'hour']:
                            hours = int(parts[2])
                            processed[key] = datetime.now(timezone.utc) + timedelta(hours=hours)
                        elif len(parts) >= 3 and parts[-1] in ['minutes', 'minute']:
                            minutes = int(parts[2])
                            processed[key] = datetime.now(timezone.utc) + timedelta(minutes=minutes)
                        else:
                            processed[key] = value
                    except (ValueError, IndexError):
                        processed[key] = value
                else:
                    processed[key] = value
            elif isinstance(value, dict):
                # Recursively process nested dicts
                processed[key] = self._process_parameters(value, incident)
            elif isinstance(value, list):
                # Process lists
                processed[key] = [
                    self._process_parameters({'item': item}, incident)['item']
                    if isinstance(item, (dict, str)) else item
                    for item in value
                ]
            else:
                processed[key] = value
        
        return processed
    
    def _convert_to_boto3_method(self, operation: str) -> str:
        """
        Convert AWS API operation name (PascalCase) to boto3 method name (snake_case).
        
        Examples:
            GetFunction -> get_function
            UpdateFunctionConfiguration -> update_function_configuration
            DescribeInstances -> describe_instances
        
        Args:
            operation: AWS API operation name in PascalCase
            
        Returns:
            boto3 method name in snake_case
        """
        import re
        # Insert underscore before uppercase letters (except at start)
        # Then convert to lowercase
        snake_case = re.sub(r'(?<!^)(?=[A-Z])', '_', operation).lower()
        return snake_case
    
    def _fix_service_name(self, service: str, operation: str) -> str:
        """
        Fix common service name mistakes from knowledge base/Bedrock agent.
        
        Some operations are commonly misattributed to the wrong service.
        This method corrects those mistakes based on the operation name.
        
        Args:
            service: Original service name from knowledge base
            operation: Operation name
            
        Returns:
            Corrected service name
        """
        # Map of operation patterns to correct service names
        operation_to_service = {
            # CloudWatch Logs operations (often confused with CloudWatch Metrics)
            'GetLogEvents': 'logs',
            'FilterLogEvents': 'logs',
            'PutLogEvents': 'logs',
            'CreateLogGroup': 'logs',
            'CreateLogStream': 'logs',
            'DescribeLogGroups': 'logs',
            'DescribeLogStreams': 'logs',
            'DeleteLogGroup': 'logs',
            'DeleteLogStream': 'logs',
            
            # CloudWatch Metrics operations
            'GetMetricData': 'cloudwatch',
            'GetMetricStatistics': 'cloudwatch',
            'PutMetricData': 'cloudwatch',
            'ListMetrics': 'cloudwatch',
            'DescribeAlarms': 'cloudwatch',
            'PutMetricAlarm': 'cloudwatch',
            
            # CloudWatch Events/EventBridge operations
            'PutEvents': 'events',
            'PutRule': 'events',
            'PutTargets': 'events',
            'DescribeRule': 'events',
            'ListRules': 'events',
        }
        
        # Check if operation needs service correction
        if operation in operation_to_service:
            correct_service = operation_to_service[operation]
            if service != correct_service:
                logger.info(
                    f"Correcting service name: {service}:{operation} -> "
                    f"{correct_service}:{operation}"
                )
                return correct_service
        
        return service

    def invoke_lambda(
        self,
        step: 'ResolutionStep',
        incident: IncidentEvent
    ) -> Dict[str, Any]:
        """
        Invoke Lambda function for remediation.
        
        Args:
            step: ResolutionStep with Lambda details
            incident: IncidentEvent context
            
        Returns:
            Dict with invocation result
        """
        function_name = step.target
        payload = step.parameters.copy()
        
        try:
            # Add incident context to payload
            payload['incident_id'] = incident.incident_id
            payload['event_type'] = incident.event_type
            
            # Invoke Lambda function
            response = self.lambda_client.invoke(
                FunctionName=function_name,
                InvocationType='RequestResponse',
                Payload=json.dumps(payload)
            )
            
            # Parse response
            response_payload = json.loads(response['Payload'].read())
            
            # Check if Lambda execution was successful
            if response['StatusCode'] == 200:
                return {
                    'success': True,
                    'action': step.action,
                    'result': response_payload,
                    'function_name': function_name
                }
            else:
                return {
                    'success': False,
                    'action': step.action,
                    'error': f"Lambda returned status {response['StatusCode']}",
                    'function_name': function_name
                }
                
        except ClientError as e:
            logger.error(f"Lambda invocation error: {e}")
            return {
                'success': False,
                'action': step.action,
                'error': f"Lambda error: {str(e)}",
                'function_name': function_name
            }
        except Exception as e:
            logger.error(f"Error invoking Lambda: {e}")
            return {
                'success': False,
                'action': step.action,
                'error': str(e)
            }

    def handle_remediation_failure(
        self,
        incident: IncidentEvent,
        agent_response: AgentResponse,
        step_result: Dict[str, Any],
        step_number: int
    ) -> bool:
        """
        Handle remediation failure.
        
        Args:
            incident: IncidentEvent
            agent_response: AgentResponse
            step_result: Failed step result
            step_number: Step number that failed
            
        Returns:
            True if failure was handled and execution can continue
        """
        logger.warning(f"Handling remediation failure at step {step_number}")
        
        # Log failure details
        failure_info = {
            'incident_id': incident.incident_id,
            'step_number': step_number,
            'action': step_result.get('action'),
            'error': step_result.get('error'),
            'agent_confidence': agent_response.confidence
        }
        
        logger.error(f"Remediation failure: {json.dumps(failure_info)}")
        
        # Determine if failure is recoverable
        error_message = step_result.get('error', '').lower()
        
        # Transient errors - can retry
        transient_keywords = ['throttl', 'timeout', 'unavailable', 'capacity']
        if any(keyword in error_message for keyword in transient_keywords):
            logger.info("Transient error detected - could retry")
            return False  # For now, don't continue
        
        # Permission errors - cannot recover
        permission_keywords = ['access denied', 'unauthorized', 'forbidden']
        if any(keyword in error_message for keyword in permission_keywords):
            logger.error("Permission error - cannot recover")
            return False
        
        # Default: don't continue on failure
        return False

    def update_knowledge_base_and_dynamodb(
        self,
        incident: IncidentEvent,
        agent_response: AgentResponse,
        step_results: List[Dict[str, Any]]
    ) -> bool:
        """
        Update Knowledge Base and DynamoDB after successful remediation.
        
        Args:
            incident: IncidentEvent
            agent_response: AgentResponse
            step_results: List of step execution results
            
        Returns:
            True if updates successful
        """
        try:
            # Create incident document for Knowledge Base
            # Note: Skipping knowledge base update for now as it requires HistoricalIncident format
            # In production, convert incident_doc to HistoricalIncident format
            kb_success = True  # Assume success for now
            logger.info("Skipping Knowledge Base update (requires HistoricalIncident conversion)")
            
            # Update DynamoDB incident record
            db_success = self.dynamodb_service.update_incident_status(
                incident_id=incident.incident_id,
                new_status='resolved',
                timestamp=incident.timestamp,
                resolution_steps=[step.description for step in agent_response.resolution_steps],
                confidence=agent_response.confidence
            )
            
            if not db_success:
                logger.warning("Failed to update DynamoDB")
            
            return kb_success and db_success
            
        except Exception as e:
            logger.error(f"Error updating Knowledge Base and DynamoDB: {e}")
            return False

    def _get_current_time(self) -> int:
        """Get current timestamp in seconds"""
        from time import time
        return int(time())

    def _calculate_duration(self, start_time: int) -> int:
        """Calculate duration in seconds"""
        return self._get_current_time() - start_time
